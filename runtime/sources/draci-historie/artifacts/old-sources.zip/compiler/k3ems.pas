{konvertor dfw fajl� do ems form�tu}

unit k3ems;
interface

procedure konverzeemsdfwfajlu(cesta:string);

implementation
uses k3togeth,
     bardfw;

procedure konverzeemsdfwfajlu(cesta:string);
type plongintarray=^tlongintarray;
     tlongintarray=array[1..1000]of longint;
     pbuffer=^tbuffer;
     tbuffer=array[1..65000]of byte;
var pocet:integer;
    i,j:word;
    indexy:plongintarray;
    buf:pbuffer; delkabuf:word;
    pom:pbuffer; zacatek,delka:word;
begin
  cesta:=fsplit2(cesta,3); {vezmeme v�echno krom� p��pony, kter� je DFW}

  pocet:=getarchiveoccupy(cesta+'.dfw'); {na�ten� d�lek v�ech slo�ek}
  getmem(indexy,(pocet+1)*sizeof(longint));
  indexy^[1]:=0;
  for i:=1 to pocet do
    indexy^[i+1]:=indexy^[i]+unpackeditemsize(cesta+'.dfw',i);

  smazsoubor(cesta+'.ems');
  caddfrommemory(cesta+'.ems',indexy,(pocet+1)*sizeof(longint));
    {vytvo�en� nov�ho arch�vu}
  delkabuf:=0;
  getmem(buf,deleniretezcunabloky);

  for i:=1 to pocet do begin {pro v�echny slo�ky}
    zacatek:=1;
    delka:=cloaditem(cesta+'.dfw',pointer(pom),i);
    while longint(delka-zacatek+1)+delkabuf>deleniretezcunabloky do begin
    {vyswapovat a p�ipsat slo�ku}
      for j:=delkabuf+1 to deleniretezcunabloky do
        buf^[j]:=pom^[j-delkabuf+zacatek-1];
      inc(zacatek,deleniretezcunabloky-delkabuf);
      delkabuf:=0;
      caddfrommemory(cesta+'.ems',buf,deleniretezcunabloky);
    end;
    {p�ipsat zbytek do bufferu}
    for j:=zacatek to delka do
      buf^[delkabuf+j-zacatek+1]:=pom^[j];
    inc(delkabuf,delka-zacatek+1);
    {dealokovat na�tenou subslo�ku}
    freemem(pom,delka);
  end;
  if delkabuf<>0 then {zapsat p��p. zbytek}
    caddfrommemory(cesta+'.ems',buf,delkabuf);

{  smazsoubor(cesta+'.dfw');
  prejmenujsoubor(cesta+'.ems',cesta+'.dfw');}
{necha puvodni soubor a stejne tak da i novy do pripony ems}

  freemem(buf,deleniretezcunabloky);
  freemem(indexy,(pocet+1)*sizeof(longint));

  writeln('do EMS-form�tu p�eveden soubor: '+cesta);
end;

end.
