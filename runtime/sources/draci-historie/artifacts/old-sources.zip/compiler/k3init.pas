{inicializace (sezn�men� se se seznamy) kompil�toru her 3. verze}

unit k3init;
interface
uses k3togeth,
     txt2iden,txt2comm,chyby,gpl2,
     bardfw;

procedure seznamovacikancelar(
  var mist:pseznammistnosti;
  var obj:pseznamobjektu;
  var ikon:pseznamikon;
  var pov:pseznampovidacku;
  var init:pinithry;
  var ret,rozh,pal,hud,map:pseznamretezcu;
  var pricistret:integer;
  var pocitret:longint;
  var soubret1:tpracsoubret1;
  var soubret2:tpracsoubret2);
procedure dealokujseznamy(
  var mist:pseznammistnosti;
  var obj:pseznamobjektu;
  var ikon:pseznamikon;
  var pov:pseznampovidacku;
  var init:pinithry;
  var ret,rozh,pal,hud,map:pseznamretezcu);
procedure inicializujgpl2(
  var ident:pident;
  var maxident:byte;
  var prik,talk:pprikaz);
procedure dealokujgpl2(
  var ident:pident;
  var prik:pprikaz);
procedure nastavcesty;

implementation
uses together,
     dos;

procedure nactiinithry(
  obj:pseznamobjektu;
  mist:pseznammistnosti;
  var init:pinithry;
  var r:tseznamident);
var fi:text;
    slov,ret:string;
    promenne:boolean;
    cis:longint;
    ch:integer;
    h:tseznamhodnot;
    hra:record {�teno sem, ne� se naalokuje init}
      start,map,hero:byte;
      gatestart,gatemap:byte;
      imaxx,imaxy:integer;
      maxhud:word;
    end;
begin
  otevrisouborcteni(jmsoubinit,fi);
  r.pocet:=0;
  h.pocet:=0;
  hra.start:=255;
  hra.map:=255;
  hra.hero:=255;
  hra.gatestart:=255;
  hra.gatemap:=255;
  hra.imaxx:=-1;
  hra.imaxy:=-1;
  hra.maxhud:=0;
  promenne:=false;
  while not eof(fi) do begin {na�te seznam m�stnost�}
    readln(fi,ret);
    orizni(ret);
    uppercase(ret); {nikde nejsou title, tak�e to m��u ud�lat}
    if (ret='')or(ret[1]='{') then continue;
    slov:=slovo(ret);
    if slov='VAR' then
      promenne:=true
    else if slov='HERO' then begin {zad�n� jm�na hrdiny}
      slov:=slovo(ret);
      if hra.hero<>255 then
        chyba('dvojn�sobn� zad�n� jm�na hrdiny v initu hry '+slov);
      cis:=1;
      while (cis<=obj^.pocet)and(slov<>obj^.o[cis]^.id) do
        inc(cis);
      if cis>obj^.pocet then
        chyba('�patn� zad�n� jm�na hrdiny '+slov);
      hra.hero:=cis;
      promenne:=false;
    end else if slov='STARTROOM' then begin {startovn� m�stnost}
      slov:=slovo(ret);
      if hra.start<>255 then
        chyba('dvojn�sobn� zad�n� startovn� m�stnosti '+slov);
      cis:=1;
      while (cis<=mist^.pocet)and(slov<>mist^.m[cis].id) do
        inc(cis);
      if cis>mist^.pocet then
        chyba('�patn� zad�n� startovn� m�stnosti '+slov);
      hra.start:=cis;
      val(ret,cis,ch); {na�teme br�nu startovn� m�stnosti}
      if (ch<>0)or(cis<1)or(cis>maxgatesmistnosti) then
        chyba('�patn� zad�n� br�ny startovn� m�stnosti '+ret);
      hra.gatestart:=cis;
      promenne:=false;
    end else if slov='MAPROOM' then begin {m�stnost s mapou}
      slov:=slovo(ret);
      if hra.map<>255 then
        chyba('dvojn�sobn� zad�n� m�stnosti s mapou '+slov);
      if slov='' then begin {zde jedin� je povolena absence}
        hra.map:=0;
        hra.gatemap:=0;
      end else begin
        cis:=1;
        while (cis<=mist^.pocet)and(slov<>mist^.m[cis].id) do
          inc(cis);
        if cis>mist^.pocet then
          chyba('�patn� zad�n� m�stnosti s mapou '+slov);
        hra.map:=cis;
        val(ret,cis,ch); {na�teme br�nu m�stnosti s mapou}
        if (ch<>0)or(cis<1)or(cis>maxgatesmistnosti) then
          chyba('�patn� zad�n� br�ny m�stnosti s mapou '+ret);
        hra.gatemap:=cis;
      end;
      promenne:=false;
    end else if promenne then begin {jinak to m��e b�t jen prom�nn�}
      if r.pocet=maxpocetident then
        chyba('p��li� mnoho prom�nnn�ch v initu hry');
      inc(r.pocet);
      r.i[r.pocet]:=slov;
      inc(h.pocet);
      val(ret,cis,ch);
      if (ch<>0)or(cis<-maxint)or(cis>maxint) then
        chyba('�patn� inicializace prom�nn� '+slov);
      h.h[r.pocet]:=cis;
    end else
      chyba('nezn�m� vlastnosti v initu hry '+slov);
  end;
  close(fi);

  getmem(init,sizeof(hra)+1+r.pocet*sizeof(integer)); {za�ad� na�ten� prom�nn�}
  init^.prom.pocet:=h.pocet;
  for cis:=1 to h.pocet do
    init^.prom.h[cis]:=h.h[cis];
  init^.start:=hra.start;
  init^.map:=hra.map;
  init^.hero:=hra.hero;
  init^.gatestart:=hra.gatestart;
  init^.gatemap:=hra.gatemap;
  init^.imaxx:=hra.imaxx;
  init^.imaxy:=hra.imaxy;
  init^.maxhud:=hra.maxhud;
end;

procedure nacti1jmenaanimaci(
  soub:string;
  var obj:tobjektu);
var x:word;
begin
  obj^.cestaanim:=soub;
  soub:=soub+'.an4';
  x:=getarchiveoccupy(soub);
  if x<>0 then {x=0 ---> chyba v arch�vu ---> ponech� se 0 animac�}
    dec(x); {jinak se sn��� po�et}
  getmem(obj^.anim,2+x*sizeof(pstring));
  getmem(obj^.useanim,2+x*sizeof(integer));
  {1. slo�ka je n�jak� smet�}
  obj^.anim^.pocet:=x;
  obj^.useanim^.pocet:=x;
  for x:=1 to x do begin {na�te do pam�ti v�echna jm�na}
    cloaditem(soub,pointer(obj^.anim^.r[x]),x+1);
    obj^.useanim^.h[x]:=0;
    uppercase(obj^.anim^.r[x]^);
  end;
{!bacha p�i dealokaci, �e to v�dy zabere 13 znak�!
 odebrat p�vodn� p��ponu!}
end;

procedure nactijmenaanimaci(
  soub:string;
  obj:pseznamobjektu);
var fi:text;
    cis:integer;
    ret,slov:string;
begin
  otevrisouborcteni(soub,fi);
  cis:=0;
  while not eof(fi) do begin {na�te seznam m�stnost�}
    readln(fi,ret);
    orizni(ret);
    uppercase(ret); {jak label, tak i samotn� identifik�tor to vy�aduje}
    if (ret='')or(ret[1]='{') then continue;
    slov:=slovo(ret);
    if slov='OBJECT' then begin
      {zda m�l nebo nem�l posledn� objekt animace, se p�edsv�d��me a� na
       konci hromadn�, zat�m jen zv���me ��slo}
      inc(cis);
      obj^.o[cis]^.anim:=nil;
      obj^.o[cis]^.useanim:=nil;
    end else if slov='SEQ' then begin
      if cis=0 then
        chyba('definice SEQ '+ret+' p�ed definic� objektu');
      if obj^.o[cis]^.anim<>nil then
        chyba('dvojn�sobn� definice SEQ '+ret)
      else
        nacti1jmenaanimaci(fsplit2(ret,3),obj^.o[cis]);
    end;
  end;
  if cis<>obj^.pocet then {hrdina byl taky v tomto souboru}
    chyba('(intern�) nesouhlas� po�et objekt� po �ten� anim. sekvecn�');
  for cis:=1 to obj^.pocet do begin
    if obj^.o[cis]^.anim=nil then begin {objekt nem�l animace:}
      getmem(obj^.o[cis]^.anim,1);
      obj^.o[cis]^.anim^.pocet:=0;
    end;
    if obj^.o[cis]^.useanim=nil then begin {pro jistotu dal�� if}
      getmem(obj^.o[cis]^.useanim,1);
      obj^.o[cis]^.useanim^.pocet:=0;
    end;
    if cis=1 then {zap��eme si index animac�}
      obj^.o[cis]^.idxanim:=0
    else
      obj^.o[cis]^.idxanim:=obj^.o[cis-1]^.idxanim+obj^.o[cis-1]^.anim^.pocet;
  end;

  close(fi);
end;

procedure seznamovacikancelar;
var r:tseznamident;
    x:integer;

  procedure vyrobsouboridentifikatoru(var prom:tseznamident);
  var fi,fo:text;
      ret:string;
      x:integer;
  begin
    otevrisouborcteni(jmsoubident1,fi);
    otevrisouborzapis(pracsoubident2,fo);
    while not eof(fi) do begin {p�ekop�ruje p�vodn� obsah}
      readln(fi,ret);
      writeln(fo,ret);
    end;
    close(fi);

    writeln(fo);
    writeln(fo,'class 4'); {m�stnosti}
    for x:=1 to mist^.pocet do
      writeln(fo,mist^.m[x].id,' ',x);

    writeln(fo);
    writeln(fo,'class 2'); {objekty}
    for x:=1 to obj^.pocet do
      writeln(fo,obj^.o[x]^.id,' ',x);

    writeln(fo);
    writeln(fo,'class 3'); {ikony}
    for x:=1 to ikon^.pocet do
      writeln(fo,ikon^.i[x].id,' ',x);

    writeln(fo);
    writeln(fo,'class 8'); {mluv�c� postavy}
    for x:=1 to pov^.pocet do
      writeln(fo,pov^.p[x].id,' ',x);

    writeln(fo);
    writeln(fo,'class 1'); {prom�nn�}
    for x:=1 to r.pocet do
      writeln(fo,r.i[x],' ',x);

    writeln(fo);
    writeln(fo,'class 9'); {bloky rozhovoru}
    close(fo);
  end;

begin
  nactiseznam(jmsoubmist,r,maxpocetmistnosti, 'ROOM','m�stnost�');
  getmem(mist,2+r.pocet*sizeof(tmistnosti));
  mist^.pocet:=r.pocet;
  for x:=1 to r.pocet do
    mist^.m[x].id:=r.i[x];
  write('na�teny jm�na m�stnost�, ');

  nactiseznam(jmsoubobj,r,maxpocetobjektu, 'OBJECT','objekt�');
  getmem(obj,2+r.pocet*sizeof(tobjektu)); {hrdina je zahrnut v tom}
  obj^.pocet:=r.pocet;
  for x:=1 to r.pocet do begin
    new(obj^.o[x]);
    obj^.o[x]^.id:=r.i[x];
  end;
  write('objekt�, ');

  nactiseznam(jmsoubikon,r,maxpocetikon, 'ICON','ikon');
  getmem(ikon,2+r.pocet*sizeof(tikony));
  ikon^.pocet:=r.pocet;
  for x:=1 to r.pocet do
    ikon^.i[x].id:=r.i[x];
  write('ikon, ');

  nactiseznam(jmsoubmluveni,r,maxpocetpovidacku, 'PERSON','mluv�c�ch postav');
  getmem(pov,2+r.pocet*sizeof(tpovidacka));
  pov^.pocet:=r.pocet;
  for x:=1 to r.pocet do
    pov^.p[x].id:=r.i[x];
  writeln('mluv�c�ch postav');
  {nyn� se sezn�mil s m�stnostmi, objekty, ikonami a mluv�c�mi postavami}

  nactiinithry(obj,mist, init,r);
  writeln('byl na na�ten init hry a prom�nn�ch');
  {nyn� na�etl seznam v�ech prom�nn�ch s jejich inicializa�n�mi hodnotami
   jm�na prom�nn�ch jsou ulo�ena v poli r, hodnoty v init^
   rovn�� byly na�teny ostatn� polo�ky initu hry}

  vyrobsouboridentifikatoru(r);
  {te� vyrobil spr�vn� soubor jmsoubident2,
   jm�na promn�nn�ch nejsou ulo�ena natrvalo, tak�e jsou v prac. poli r!}
  writeln('vyroben soubor identifik�tor�');

  nactijmenaanimaci(jmsoubobj,obj);
  {nyn� jsme na�etl, kter� animace m� kter� objekt}
  writeln('na�tena jm�na animac� objekt�');

  getmem(ret,2+maxretezcu*sizeof(pstring)); {alokuj 1000 pozic pro �et�zce}
  ret^.pocet:=0; {vyrovn�vac� pam�t, viz. k3}
  pricistret:=0; {skute�n� po��tadlo index�}
  pocitret:=0;   {skute�n� po��tadlo pozic}
if emsretezce then begin
  otevrifilesouborzapis(pracsoubret1,soubret1); {otev�e 2 pracovn� soubory}
  otevrifilesouborzapis(pracsoubret2,soubret2);
end else begin
  smazsoubor(vysoubretezcu); {sma�e v�stupn� dfw soubor}
end;

  getmem(rozh,2+maxrozhovoru*sizeof(pstring)); {rozhovory}
  rozh^.pocet:=0;

  getmem(pal,2+maxpalet*sizeof(pstring)); {palety}
  pal^.pocet:=0;

  getmem(hud,2+maxhudeb*sizeof(pstring)); {hudby}
  hud^.pocet:=0;

  getmem(map,2+maxmap*sizeof(pstring)); {mapy}
  map^.pocet:=0;

  smazsoubor(pracprogramy);
  writeln('alokov�ny �et�zce, rozhovory a palety');
end;

procedure dealokujseznamy;
var x,y:integer;
begin
{  for x:=1 to mist^.pocet do
    freemem(mist^.m[x].kod,2+maxobjdelkakodu*sizeof(integer));}
  freemem(mist,2+mist^.pocet*sizeof(tmistnosti));
  for x:=1 to obj^.pocet do begin {v�maz odkaz� na animace u objekt�}
    for y:=1 to obj^.o[x]^.anim^.pocet do
      freemem(obj^.o[x]^.anim^.r[y],13);
    freemem(obj^.o[x]^.anim,2+obj^.o[x]^.anim^.pocet*sizeof(pstring));
    freemem(obj^.o[x]^.useanim,2+obj^.o[x]^.useanim^.pocet*sizeof(integer));
{    freemem(obj^.o[x].kod,2+maxobjdelkakodu*sizeof(integer));}
    dispose(obj^.o[x]);
  end;
  freemem(obj,2+obj^.pocet*sizeof(tobjektu));
{  for x:=1 to ikon^.pocet do
    freemem(ikon^.i[x].kod,2+maxobjdelkakodu*sizeof(integer));}
  freemem(ikon,2+ikon^.pocet*sizeof(tikony));
  freemem(pov,2+pov^.pocet*sizeof(tpovidacka));
  freemem(init,12+init^.prom.pocet*sizeof(integer));

  for x:=1 to ret^.pocet do
    freemem(ret^.r[x],length(ret^.r[x]^)+1);
  freemem(ret,2+maxretezcu*sizeof(pstring));

  for x:=1 to rozh^.pocet do
    freemem(rozh^.r[x],length(rozh^.r[x]^)+1);
  freemem(rozh,2+maxrozhovoru*sizeof(pstring));

  for x:=1 to pal^.pocet do
    freemem(pal^.r[x],length(pal^.r[x]^)+1);
  freemem(pal,2+maxpalet*sizeof(pstring));

  for x:=1 to hud^.pocet do
    freemem(hud^.r[x],length(hud^.r[x]^)+1);
  freemem(hud,2+maxhudeb*sizeof(pstring));

  for x:=1 to map^.pocet do
    freemem(map^.r[x],length(map^.r[x]^)+1);
  freemem(map,2+maxmap*sizeof(pstring));
  writeln('dealokov�ny v pam�ti v�echny seznamy vlastnost�');
end;

procedure inicializujgpl2;
var x:byte;
begin
  x:=nactiidentifikatory(pracsoubident2,ident,maxident);
  if x<>0 then chyba(chybhlasky[x]);
  x:=nactiprikazy(jmsoubprikgpl2,prik,talk,maxident);
  if x<>0 then chyba(chybhlasky[x]);
  writeln('na�ten seznam identifik�tor� a p��kaz� gpl2');
end;

procedure dealokujgpl2;
begin
  dealokujidentifikatory(ident);
  dealokujprikazy(prik);
  writeln('dealokov�n seznam identifik�tor� a p��kaz� gpl2');
end;

procedure nastavcesty;
var i,j,pocpar:byte;
    par:array[1..3]of string;
begin
  pocpar:=paramcount;
  for i:=1 to pocpar do
    par[i]:=paramstr(i);

  emsretezce:=false;
  i:=1;
  while i<=pocpar do begin
    uppercase(par[i]);
    if par[i]='/EMS' then begin
      emsretezce:=true;
      dec(pocpar);
      for j:=i to pocpar do
        par[j]:=par[j+1];
    end else
      inc(i);
  end;

  if pocpar>2 then begin
    writeln('syntax: k3 [<vstupn�_adres��>] [<v�stupn�_adres��>] [/ems]');
    writeln;
    writeln('oba parametry jsou nepovinn�, default je aktu�ln� adres��');
    writeln('kdy� je zad�n 1 parametr, je to vstup');
    writeln('pokud chce� zadat jen v�stup, dej `k3 . v�st_cesta''');
    halt(0);
  end;

  jmvstupnicesty:=fexpand(par[1]); {vstupn� adres�� v�. \ na konci}
  if jmvstupnicesty[length(jmvstupnicesty)]<>'\' then
    jmvstupnicesty:=jmvstupnicesty+'\';

  jmsoubident1:=jmvstupnicesty+jmsoubident1;
  jmsoubprikgpl2:=jmvstupnicesty+jmsoubprikgpl2;

  jmsoubinit:=jmvstupnicesty+jmsoubinit;
  jmsoubmist:=jmvstupnicesty+jmsoubmist;
  jmsoubobj:=jmvstupnicesty+jmsoubobj;
  jmsoubikon:=jmvstupnicesty+jmsoubikon;
  jmsoubmluveni:=jmvstupnicesty+jmsoubmluveni;

  if pocpar=2 then begin
    jmvystupnicesty:=fexpand(par[2]); {vstupn� adres�� v�. \ na konci}
    if jmvystupnicesty[length(jmvystupnicesty)]<>'\' then
      jmvystupnicesty:=jmvystupnicesty+'\';

    vysoubretezcu:=jmvystupnicesty+vysoubretezcu;
    vysoubemsretezcu:=jmvystupnicesty+vysoubemsretezcu;
    vysoubrozhovoru:=jmvystupnicesty+vysoubrozhovoru;
    vysoubhudeb:=jmvystupnicesty+vysoubhudeb;
    vysoubmap:=jmvystupnicesty+vysoubmap;
    vysoubpalet:=jmvystupnicesty+vysoubpalet;
    vysoubmasek:=jmvystupnicesty+vysoubmasek;

    vysoubinit:=jmvystupnicesty+vysoubinit;
    vysoubmist:=jmvystupnicesty+vysoubmist;
    vysoubobj:=jmvystupnicesty+vysoubobj;
    vysoubikon:=jmvystupnicesty+vysoubikon;

    vysoubobrikon:=jmvystupnicesty+vysoubobrikon;
    vysoubobranim:=jmvystupnicesty+vysoubobranim;
    vysoubsamanim:=jmvystupnicesty+vysoubsamanim;
    vysoubanim:=jmvystupnicesty+vysoubanim;

    pracsoubident2:=jmvystupnicesty+pracsoubident2;
    pracsoubident3:=jmvystupnicesty+pracsoubident3;
    pracsoubret1:=jmvystupnicesty+pracsoubret1;
    pracsoubret2:=jmvystupnicesty+pracsoubret2;
    pracprogramy:=jmvystupnicesty+pracprogramy;
  end;
end;

end.

{todo: nebylo by lep�� hrdinu z initu p�en�st mezi objekty a v initu
       pouze uv�st, kter� to je? bylo! done!
       184. ��dek (nacti1jmenaanimaci)
       o�et�it t�eba p��pad 0 prom�nn�ch (a� se nevol� getmem)}
{!spravit dfw, aby ned�lalo �patn� se soubory, proto�e p�i z�pisu do
 neexistuj�c�ho adres��e to pak nevyp��e ani chybovou hl��ku, jak se
 to zblbne!}
