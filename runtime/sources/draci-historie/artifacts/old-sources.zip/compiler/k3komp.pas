{kompil�tor ikon pro k3

 pozn. zbytek ��dku se v�dy ignoruje}

unit k3komp;
interface
uses k3togeth,
     together,chyby,txt2iden,txt2comm,gpl2,mat2bin;

procedure kompilujikony(
  var ikon:pseznamikon;
  var obj:pseznamobjektu;
  var seznrozh,seznpal,seznhud,seznmap:pseznamretezcu;
  var seznret:pseznamretezcu;
  var pricistret:integer;
  var pocitret:longint;
  var soubret1:tpracsoubret1;
  var soubret2:tpracsoubret2;
  ident:pident;
  maxident:byte;
  prik,talk:pprikaz);

procedure kompilujobjekty(
  var obj:pseznamobjektu;
  var ikon:pseznamikon;
  var mist:pseznammistnosti;
  inithry:pinithry;
  var seznrozh,seznpal,seznhud,seznmap:pseznamretezcu;
  var seznret:pseznamretezcu;
  var pricistret:integer;
  var pocitret:longint;
  var soubret1:tpracsoubret1;
  var soubret2:tpracsoubret2;
  ident:pident;
  maxident:byte;
  prik,talk:pprikaz);

procedure kompilujmistnosti(
  var mist:pseznammistnosti;
  var ikon:pseznamikon;
  var obj:pseznamobjektu;
  var seznrozh,seznpal,seznhud,seznmap:pseznamretezcu;
  var seznret:pseznamretezcu;
  var pricistret:integer;
  var pocitret:longint;
  var soubret1:tpracsoubret1;
  var soubret2:tpracsoubret2;
  ident:pident;
  maxident:byte;
  prik,talk:pprikaz);

procedure kompilujmluveni(
  var pov:pseznampovidacku);

procedure kompilujrozhovory(
  rozh:pseznamretezcu;
  obj:pseznamobjektu;
  var seznrozh,seznpal,seznhud,seznmap:pseznamretezcu;
  var seznret:pseznamretezcu;
  var pricistret:integer;
  var pocitret:longint;
  var soubret1:tpracsoubret1;
  var soubret2:tpracsoubret2;
  var ident:pident;
  var maxident:byte;
  prik,talk:pprikaz);

implementation
uses dos,
     bardfw;

procedure vyprazdniretezce(
  var seznret:pseznamretezcu;
  var pricistret:integer;
  var pocitret:longint;
  var soubret1:tpracsoubret1;
  var soubret2:tpracsoubret2);
{vyflusne obsah �et�zcov�ho bufferu do 2 pracovn�ch fajl�}
var x:integer;
    pomret:string;
    i:byte;
begin
  if seznret^.pocet<>0 then begin
    for x:=1 to seznret^.pocet do begin
      pomret:=seznret^.r[x]^;
      for i:=1 to length(pomret) do
        if pomret[i]=#13 then
          pomret[i]:='|';
      pomret:=pomret+'|';
if not emsretezce then begin
      if caddfrommemory(vysoubretezcu,@pomret,length(pomret)+1)
         <>pricistret+x then
        chyba('(intern�) nesouhlas� ��sla p�i z�pisu �et�zce '+pomret);
end else begin
      blockwrite(soubret1,pocitret,sizeof(pocitret));
      blockwrite(soubret2,pomret[1],length(pomret));
      inc(pocitret,length(pomret));
      {zap��e pozici �et�zce a �et�zec do pracovn�ch soubor�}
end;
      freemem(seznret^.r[x],length(seznret^.r[x]^)+1);
    end;
    inc(pricistret,seznret^.pocet);
    seznret^.pocet:=0;
    writeln('.zapsal se z�sobn�k �et�zc� na disk');
  end;
end;

procedure prevezmiretezcoveparametry(
  seznpomret:pseznampomretezcu;
  _kod:pkod;
  seznrozh,seznpal,seznhud,seznmap:pseznamretezcu;
  obj:pseznamobjektu);
{parametry v �et�zc�ch typu 2-2 (palety, rozhovory a animace)
 p�ekonvertuje na ��seln� odkazy a zaznamen� je do seznam�
 (pou�ito to stejn� na 4 m�stech programu)}
var x,y:integer;
    ret:string;
begin
  {v seznpomret m��e b�t:
   a) animace
   b) jm�no dialogu: p��kaz ��slo 9
   c) paleta: p��kaz ��slo 11}
  for x:=1 to seznpomret^.pocet do begin
    with seznpomret^.r[x] do
      case cis of {��slo p��kazu}
        9:begin {jm�no dialogu, najde v/p�id� do seznamu}
          y:=najdivseznamuretezcu(seznrozh,true,fexpand(r^));
          _kod^.k[vyskyt]:=y; {p�ep��e to v k�du}
        end;
        11:begin {jm�no palety, najde v/p�id� do seznamu}
          y:=najdivseznamuretezcu(seznpal,true,fexpand(r^));
          _kod^.k[vyskyt]:=y; {p�ep��e to v k�du}
        end;
        18:begin {jmeno hudby}
          y:=najdivseznamuretezcu(seznhud,true,fexpand(r^));
          _kod^.k[vyskyt]:=y; {p�ep��e to v k�du}
        end;
        21:begin {jmeno mapy}
          y:=najdivseznamuretezcu(seznmap,true,fexpand(r^));
          _kod^.k[vyskyt]:=y; {p�ep��e to v k�du}
        end;
        else begin {jm�no soukrom� animace objektu}
          ret:=r^;
          uppercase(ret);
          y:=najdivseznamuretezcu(
            obj^.o[ _kod^.k[vyskyt-1] ]^.anim, {p�ed t�m je ��slo objektu}
            false,ret);
          if y=0 then
            chyba('po��d�no o neexistuj�c� animaci '+ret+' objektu '+
              obj^.o[ _kod^.k[vyskyt-1] ]^.id)
          else begin {jinak to p�ep��e v k�du, vezme abs. ��slo animace}
            _kod^.k[vyskyt]:=y+obj^.o[ _kod^.k[vyskyt-1] ]^.idxanim;
            inc(obj^.o[ _kod^.k[vyskyt-1] ]^.useanim^.h[y]);
          end; {zap��e, �e byla animace pou�it�}
        end;
      end;
    freemem(seznpomret^.r[x].r,length(seznpomret^.r[x].r^)+1);
  end;
  seznpomret^.pocet:=0;
end;

procedure kompilujikony;
var fi:text;
    cis:integer;
    x,y:integer;
    ret,slov:string;
    seznpomret:pseznampomretezcu;
    postfix:tpostfix;
    krokupostfix:integer;
    _kod:pkod;
begin
  otevrisouborcteni(jmsoubikon,fi);
  cis:=0;
  new(seznpomret);
  seznpomret^.pocet:=0;
  while not eof(fi) do begin
    readln(fi,ret);
    orizni(ret);
    if (ret='')or(ret[1]='{') then continue;
    slov:=slovo(ret);
    uppercase(slov);
    if slov='ICON' then begin {strukturu u� jsme p�ed t�m pro�li}
      if cis<>0 then
      with ikon^.i[cis] do begin
        if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
          inc(kod^.delka);
          canuse:=kod^.delka;
          kod^.k[kod^.delka]:=1;
          inc(kod^.delka);
          kod^.k[kod^.delka]:=0;
          inc(kod^.delka);
          kod^.k[kod^.delka]:=0;
        end;
        if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis then
          chyba('(interni) pri MEZIzapisu programu ikony '+id);
        freemem(kod,2+maxobjdelkakodu*sizeof(integer));
      end;
      inc(cis);
      with ikon^.i[cis] do begin
        title:=#0; {kontrola, aby se n�co nedefinovalo dvakr�t}
        init:=-1;
        look:=-1;
        use:=-1;
        canuse:=-1;
        iminit:=255;
        imlook:=255;
        imuse:=255;
        status:=255;
        obr:=#0;
        getmem(kod,2+maxobjdelkakodu*sizeof(integer));
        kod^.delka:=0;
        _kod:=kod;
      end;
    end else if cis=0 then
      chyba('definice t�la ikony p�ed definic� ICON <jm�no_ikony> '+slov+' '+ret)
    else if slov='TITLE' then begin
      if ikon^.i[cis].title=#0 then
        ikon^.i[cis].title:=ret+'|'
      else
        chyba('dvojn�sobn� definice TITLE '+ret+' ikony '+ikon^.i[cis].id)
    end else if (slov='INIT')or(slov='LOOK')or(slov='USE') then begin
      uppercase(ret);
      y:=byte(slovo(ret)='IMMEDIATELY'); {zbytek se ignoruje}
      x:=1; {chyba}
      if slov='INIT' then begin
        if ikon^.i[cis].init=-1 then begin
          x:=0; {bez chyby}
          ikon^.i[cis].init:=_kod^.delka+1;
          ikon^.i[cis].iminit:=y;
        end;
      end else if slov='LOOK' then begin
        if ikon^.i[cis].look=-1 then begin
          x:=0;
          ikon^.i[cis].look:=_kod^.delka+1;
          ikon^.i[cis].imlook:=y;
        end;
      end else if slov='USE' then begin
        if ikon^.i[cis].use=-1 then begin
          x:=0;
          ikon^.i[cis].use:=_kod^.delka+1;
          ikon^.i[cis].imuse:=y;
        end;
      end;
      if x=1 then
        chyba('dvojn�sobn� definice programu '+slov+' u ikony '+
          ikon^.i[cis].id);
      x:=gpl2kompiluj(fi,_kod,seznret,pricistret,seznpomret,ident,maxident,prik,talk);
      if x<>0 then chyba(chybhlasky[x]+' u ikony '+
        ikon^.i[cis].id+' a programu '+slov);
      prevezmiretezcoveparametry(seznpomret,_kod,seznrozh,seznpal,seznhud,seznmap,obj);
      {parametry v �et�zc�ch typu 2-2 (palety, rozhovory a animace)
       p�ekonvertuje na ��seln� odkazy a zaznamen� je do seznam�}
    end else if slov='CANUSE' then begin
      if ikon^.i[cis].canuse<>-1 then
        chyba('dvojn�sobn� definice podm�nky CANUSE u ikony '+
          ikon^.i[cis].id);
      uppercase(ret); {vz�t matematick� v�raz, zkompilovat ho a za�adit do k�du}
      x:=mat2postfix(ret,ident,postfix,krokupostfix);
      if x<>0 then chyba(chybhlasky[x]+' u ikony '+ikon^.i[cis].id+
        ' u podm�nky CANUSE');
      inc(_kod^.delka);
      ikon^.i[cis].canuse:=_kod^.delka;
      move(postfix,_kod^.k[_kod^.delka],krokupostfix*2*sizeof(integer)-2);
      inc(_kod^.delka,krokupostfix*sizeof(integer)-1-1);
    end else if slov='STATUS' then begin
      if ikon^.i[cis].status<>255 then
        chyba('dvojn�sobn� definice STATUS ikony '+ikon^.i[cis].id);
      slov:=slovo(ret);
      uppercase(slov);
      if (slov='ON')or(slov='YES') then
        ikon^.i[cis].status:=1
      else if (slov='OFF')or(slov='NO') then
        ikon^.i[cis].status:=0
      else
        chyba('chyba p�i definici STATUS ikony '+ikon^.i[cis].id);
    end else if slov='PICTURE' then begin
      if ikon^.i[cis].obr=#0 then
        ikon^.i[cis].obr:=fexpand(ret)
      else
        chyba('dvojn�sobn� definice PICTURE '+ret+' ikony '+ikon^.i[cis].id);
    end else
      chyba('definov�na nezn�m� vlastnost '+slov+' ikony '+ikon^.i[cis].id);
  end;
  dispose(seznpomret);
  with ikon^.i[cis] do begin
    if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
      inc(kod^.delka);
      canuse:=kod^.delka;
      kod^.k[kod^.delka]:=1;
      inc(kod^.delka);
      kod^.k[kod^.delka]:=0;
      inc(kod^.delka);
      kod^.k[kod^.delka]:=0;
    end;
    if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis then
      chyba('(interni) pri MEZIzapisu programu ikony '+id);
    freemem(kod,2+maxobjdelkakodu*sizeof(integer));
  end;
  if cis<>ikon^.pocet then
    chyba('(intern�) nesouhlas� po�et ikon po kompilaci');
  for cis:=1 to ikon^.pocet do
    with ikon^.i[cis] do begin {p�ekonvertujeme nezadan� veli�iny}
      if title=#0 then title:={id}'|';
(*      if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
        inc(kod^.delka);
        canuse:=kod^.delka;
        kod^.k[kod^.delka]:=1;
        inc(kod^.delka);
        kod^.k[kod^.delka]:=0;
        inc(kod^.delka);
        kod^.k[kod^.delka]:=0;
      end; *)
      if iminit=255 then iminit:=0;
      if imlook=255 then imlook:=0;
      if imuse=255  then imuse:=0;
      if status=255 then status:=0;
      if obr=#0 then
        chyba('nutno definovat cestu k obr�zku ikony '+ikon^.i[cis].id)
      else if not existujesoubor(obr) then
        chyba('neexistuje soubor '+obr+' s obr�zkem ikony '+ikon^.i[cis].id);
{      if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis then
        chyba('(interni) pri MEZIzapisu programu ikony '+id);
      freemem(kod,2+maxobjdelkakodu*sizeof(integer));}
    end;
  close(fi);
  writeln('zkompilov�ny v�echny vlastnosti ikon');
  vyprazdniretezce(seznret,pricistret,pocitret,soubret1,soubret2);
end;

procedure kompilujobjekty;
var fi:text;
    cis:integer;
    x,y,ch:integer;
    valcis:longint;
    ret,slov:string;
    seznpomret:pseznampomretezcu;
    postfix:tpostfix;
    krokupostfix:integer;
    _kod:pkod;
    _ident:pident;
begin
  otevrisouborcteni(jmsoubobj,fi);
  cis:=0;
  new(seznpomret);
  seznpomret^.pocet:=0;
  while not eof(fi) do begin
    readln(fi,ret);
    orizni(ret);
    if (ret='')or(ret[1]='{') then continue;
    slov:=slovo(ret);
    uppercase(slov);
    if slov='OBJECT' then begin {strukturu u� jsme p�ed t�m pro�li}
      if cis<>0 then
      with obj^.o[cis]^ do begin
        if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
          inc(kod^.delka);
          canuse:=kod^.delka;
          kod^.k[kod^.delka]:=1;
          inc(kod^.delka);
          kod^.k[kod^.delka]:=0;
          inc(kod^.delka);
          kod^.k[kod^.delka]:=0;
        end;
        if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis+ikon^.pocet then
          chyba('(interni) pri MEZIzapisu programu objektu '+id);
        freemem(kod,2+maxobjdelkakodu*sizeof(integer));
      end;
      inc(cis);
      with obj^.o[cis]^ do begin
        title:=#0; {kontrola, aby se n�co nedefinovalo dvakr�t}
        init:=-1;
        look:=-1;
        use:=-1;
        canuse:=-1;
        iminit:=255;
        imlook:=255;
        imuse:=255;
        status:=255;
        mistnost:=0;
        priorita:=255;
        {animace jsou u� na�teny a zkontrolov�ny}
        getmem(kod,2+maxobjdelkakodu*sizeof(integer));
        kod^.delka:=0;
        _kod:=kod;
        xuse:=-1;
        yuse:=-1;
        xlook:=-1;
        ylook:=-1;
        smerlook:=255;
        smeruse:=255;
      end;
      slov:=slovo(ret); {to je jm�no objektu}
      slov:=slovo(ret); {to je p��p. vlastnost objektu}
      uppercase(slov);
      if slov='' then
        obj^.o[cis]^.typ:=1 {nic}
      else if slov='LEFT' then
        obj^.o[cis]^.typ:=2
      else if slov='RIGHT' then
        obj^.o[cis]^.typ:=3
      else if slov='DOWN' then
        obj^.o[cis]^.typ:=4
      else if slov='UP' then
        obj^.o[cis]^.typ:=5
      else
        chyba('nezn�m� typ objektu '+obj^.o[cis]^.id);
    end else if cis=0 then
      chyba('definice t�la objektu p�ed definic� OBJECT <jm�no_objektu> '+slov+' '+ret)
    else if slov='TITLE' then begin
      if obj^.o[cis]^.title=#0 then
        obj^.o[cis]^.title:=ret+'|'
      else
        chyba('dvojn�sobn� definice TITLE '+ret+' objektu '+obj^.o[cis]^.id)
    end else if (slov='INIT')or(slov='LOOK')or(slov='USE') then begin
      uppercase(ret);
      y:=byte(slovo(ret)='IMMEDIATELY'); {zbytek se ignoruje}
      x:=1; {chyba}
      if slov='INIT' then begin
        if obj^.o[cis]^.init=-1 then begin
          x:=0; {bez chyby}
          obj^.o[cis]^.init:=_kod^.delka+1;
          obj^.o[cis]^.iminit:=y;
        end;
      end else if slov='LOOK' then begin
        if obj^.o[cis]^.look=-1 then begin
          x:=0;
          obj^.o[cis]^.look:=_kod^.delka+1;
          obj^.o[cis]^.imlook:=y;
        end;
      end else if slov='USE' then begin
        if obj^.o[cis]^.use=-1 then begin
          x:=0;
          obj^.o[cis]^.use:=_kod^.delka+1;
          obj^.o[cis]^.imuse:=y;
        end;
      end;
      if x=1 then
        chyba('dvojn�sobn� definice programu '+slov+' u objektu '+obj^.o[cis]^.id);
      x:=gpl2kompiluj(fi,_kod,seznret,pricistret,seznpomret,ident,maxident,prik,talk);
      if x<>0 then chyba(chybhlasky[x]+' u programu '+slov+' u objektu '+obj^.o[cis]^.id);
      prevezmiretezcoveparametry(seznpomret,_kod,seznrozh,seznpal,seznhud,seznmap,obj);
      {parametry v �et�zc�ch typu 2-2 (palety, rozhovory a animace)
       p�ekonvertuje na ��seln� odkazy a zaznamen� je do seznam�}
    end else if slov='CANUSE' then begin
      if obj^.o[cis]^.canuse<>-1 then
        chyba('dvojn�sobn� definice podm�nky CANUSE u objektu '+obj^.o[cis]^.id);
      uppercase(ret); {vz�t matematick� v�raz, zkompilovat ho a za�adit do k�du}
      x:=mat2postfix(ret,ident,postfix,krokupostfix);
      if x<>0 then chyba(chybhlasky[x]+' u podm�nky CANUSE objektu '+obj^.o[cis]^.id);
      inc(_kod^.delka);
      obj^.o[cis]^.canuse:=_kod^.delka;
      move(postfix,_kod^.k[_kod^.delka],krokupostfix*2*sizeof(integer)-2);
      inc(_kod^.delka,krokupostfix*sizeof(integer)-1-1);
    end else if slov='STATUS' then begin
      if obj^.o[cis]^.status<>255 then
        chyba('dvojn�sobn� definice STATUS objektu '+obj^.o[cis]^.id);
      slov:=slovo(ret);
      uppercase(slov);
      if (slov='ON')or(slov='YES') then
        obj^.o[cis]^.status:=0
      else if (slov='OFF')or(slov='NO') then
        obj^.o[cis]^.status:=1
      else if slov='AWAY' then
        obj^.o[cis]^.status:=2
      else
        chyba('chyba p�i definici STATUS objektu '+obj^.o[cis]^.id);
    end else if slov='ROOM' then begin {definice domovsk� m�stnosti}
      slov:=slovo(ret); {na�ti jm�no m�stnosti}
      uppercase(slov);
      if obj^.o[cis]^.mistnost<>0 then
        chyba('dvojn�sobn� definice ROOM '+slov+' objektu '+obj^.o[cis]^.id);
      y:=1;
      while (y<=mist^.pocet)and(slov<>mist^.m[y].id) do
        inc(y);
      if y>mist^.pocet then
        chyba('nezn�m� domovsk� m�stnost '+slov+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.mistnost:=y;
    end else if slov='PRIORITY' then begin {definice priority}
      if obj^.o[cis]^.priorita<>255 then
        chyba('dvojn�sobn� definice PRIORITY '+ret+' objektu '+obj^.o[cis]^.id);
      val(ret,valcis,ch);
      if (ch<>0)or(valcis<0)or(valcis>{200}254) then
        chyba('�patn� definice PRIORITY '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.priorita:=valcis;
    end else if slov='LOOKC' then begin {definice look-souradnic}
      if obj^.o[cis]^.smerlook<>255 then
        chyba('dvojn�sobn� definice LOOKC '+ret+' objektu '+obj^.o[cis]^.id);
      slov:=slovo(ret);
      val(slov,valcis,ch); {x}
      if (ch<>0){or(valcis<0)or(valcis>319)} then
        chyba('�patn� definice LOOKC-X '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.xlook:=valcis;
      slov:=slovo(ret);
      val(slov,valcis,ch); {y}
      if (ch<>0){or(valcis<0)or(valcis>319)} then
        chyba('�patn� definice LOOKC-Y '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.ylook:=valcis;
      _ident:=ident^.dalsi;
      uppercase(ret); {smer}
      while (_ident<>nil)and(_ident^.txt<>ret) do
        _ident:=_ident^.dalsi;
      if (_ident=nil)or(_ident^.trida<>6) then
        chyba('�patn� definice LOOKC-SMER '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.smerlook:=_ident^.hodn;
    end else if slov='USEC' then begin {definice use-souradnic}
      if obj^.o[cis]^.smeruse<>255 then
        chyba('dvojn�sobn� definice USEC '+ret+' objektu '+obj^.o[cis]^.id);
      slov:=slovo(ret);
      val(slov,valcis,ch); {x}
      if (ch<>0){or(valcis<0)or(valcis>319)} then
        chyba('�patn� definice USEC-X '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.xuse:=valcis;
      slov:=slovo(ret);
      val(slov,valcis,ch); {y}
      if (ch<>0){or(valcis<0)or(valcis>319)} then
        chyba('�patn� definice USEC-Y '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.yuse:=valcis;
      _ident:=ident^.dalsi;
      uppercase(ret); {smer}
      while (_ident<>nil)and(_ident^.txt<>ret) do
        _ident:=_ident^.dalsi;
      if (_ident=nil)or(_ident^.trida<>6) then
        chyba('�patn� definice USEC-SMER '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.smeruse:=_ident^.hodn;
(*      uppercase(ret); {smer}
      while (_ident<>nil)and(_ident^.txt<>ret) do
        _ident:=_ident^.dalsi;
      if (_ident=nil)or(_ident^.trida<>6) then
        chyba('�patn� definice USEC-SMER '+ret+' objektu '+obj^.o[cis]^.id);
      obj^.o[cis]^.smeruse:=_ident^.hodn;*)
    end else if slov='SEQ' then begin
    {seqence u� byly kontrolov�ny a na�teny v minul�m pr�chodu}
    end else
      chyba('definov�na nezn�m� vlastnost '+slov+' objektu '+obj^.o[cis]^.id);
  end;
  dispose(seznpomret);
  with obj^.o[cis]^ do begin
    if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
      inc(kod^.delka);
      canuse:=kod^.delka;
      kod^.k[kod^.delka]:=1;
      inc(kod^.delka);
      kod^.k[kod^.delka]:=0;
      inc(kod^.delka);
      kod^.k[kod^.delka]:=0;
    end;
    if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis+ikon^.pocet then
      chyba('(interni) pri MEZIzapisu programu objektu '+id);
    freemem(kod,2+maxobjdelkakodu*sizeof(integer));
  end;
  if cis<>obj^.pocet then
    chyba('(intern�) nesouhlas� po�et objekt� po kompilaci');
  for cis:=1 to obj^.pocet do
    with obj^.o[cis]^ do begin {p�ekonvertujeme nezadan� veli�iny}
      if title=#0 then title:={id}'|';
(*      if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
        inc(kod^.delka);
        canuse:=kod^.delka;
        kod^.k[kod^.delka]:=1;
        inc(kod^.delka);
        kod^.k[kod^.delka]:=0;
        inc(kod^.delka);
        kod^.k[kod^.delka]:=0;
      end; *)
      if iminit=255 then iminit:=0;
      if imlook=255 then imlook:=0;
      if imuse=255  then imuse:=0;
      {typ byl napln�n p�i initu}
      if status=255 then status:=1; {off, kv�li away opa�n� ne� u ikonek}
      if mistnost=255 then
        chyba('u objektu '+obj^.o[cis]^.id+' je nutno definovat m�stnost');
        {objekt je bu� ve sv� rodi�ovsk� m�stnosti nebo nikde, proto�e ho
         nelze pokl�dat a i animace jsou �ity p�esn� na m�ru na dan�
         sou�adnice, proto taky ani sou�adnice neexistuj�...}
      if (priorita=255)and(cis<>inithry^.hero) then
        chyba('u objektu '+obj^.o[cis]^.id+', kter� nen� hrdina, je nutno definovat prioritu');
      {cestaanim atd... u� bylo zkontrolov�no}
      if xuse=-1 then begin
        xuse:=0;
        yuse:=0;
        smeruse:=0;
      end;
      if xlook=-1 then begin
        xlook:=0;
        ylook:=0;
        smerlook:=0;
      end;
      {mluvi u� bylo taky na�teno}
{      if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis+ikon^.pocet then
        chyba('(interni) pri MEZIzapisu programu objektu '+id);
      freemem(kod,2+maxobjdelkakodu*sizeof(integer));}
    end;
  close(fi);
  writeln('zkompilov�ny v�echny vlastnosti objekt�');
  vyprazdniretezce(seznret,pricistret,pocitret,soubret1,soubret2);
end;

procedure kompilujmistnosti;
var fi:text;
    cis:integer;
    x,y,ch:integer;
    valcis:longint;
    ret,slov:string;
    seznpomret:pseznampomretezcu;
    postfix:tpostfix;
    krokupostfix:integer;
    _kod:pkod;
begin
  otevrisouborcteni(jmsoubmist,fi);
  cis:=0;
  new(seznpomret);
  seznpomret^.pocet:=0;
  while not eof(fi) do begin
    readln(fi,ret);
    orizni(ret);
    if (ret='')or(ret[1]='{') then continue;
    slov:=slovo(ret);
    uppercase(slov);
    if slov='ROOM' then begin {strukturu u� jsme p�ed t�m pro�li}
      if cis<>0 then
      with mist^.m[cis] do begin
        if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
        if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
          inc(kod^.delka);
          canuse:=kod^.delka;
          kod^.k[kod^.delka]:=1;
          inc(kod^.delka);
          kod^.k[kod^.delka]:=0;
          inc(kod^.delka);
          kod^.k[kod^.delka]:=0;
        end;
        if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis+ikon^.pocet+obj^.pocet then
          chyba('(interni) pri MEZIzapisu programu mistnosti '+id);
        freemem(kod,2+maxobjdelkakodu*sizeof(integer));
      end;
      inc(cis);
      with mist^.m[cis] do begin
        title:=#0; {kontrola, aby se n�co nedefinovalo dvakr�t}
        init:=-1;
        look:=-1;
        use:=-1;
        canuse:=-1;
        iminit:=255;
        imlook:=255;
        imuse:=255;
        obr:=#0;
        mus:=#0;
        mask:=#0;
        map:=#0;
        mouse:=255;
        hero:=255;
        persp0:=-100;
        perspstep:=-100;
        escroom:=255;
        gates:=0;
        for x:=1 to maxgatesmistnosti do
          gate[x]:=0;
        getmem(kod,2+maxobjdelkakodu*sizeof(integer));
        kod^.delka:=0;
        _kod:=kod;
      end;
    end else if cis=0 then
      chyba('definice t�la m�stnosti p�ed definic� ROOM <jm�no_m�stnosti> '+slov+' '+ret)
    else if slov='TITLE' then begin
      if mist^.m[cis].title=#0 then
        mist^.m[cis].title:=ret+'|'
      else
        chyba('dvojn�sobn� definice TITLE '+ret+' m�stnosti '+mist^.m[cis].id)
    end else if (slov='INIT')or(slov='LOOK')or(slov='USE') then begin
      uppercase(ret);
      y:=byte(slovo(ret)='IMMEDIATELY'); {zbytek se ignoruje}
      x:=1; {chyba}
      if slov='INIT' then begin
        if mist^.m[cis].init=-1 then begin
          x:=0; {bez chyby}
          mist^.m[cis].init:=_kod^.delka+1;
          mist^.m[cis].iminit:=y;
        end;
      end else if slov='LOOK' then begin
        if mist^.m[cis].look=-1 then begin
          x:=0;
          mist^.m[cis].look:=_kod^.delka+1;
          mist^.m[cis].imlook:=y;
        end;
      end else if slov='USE' then begin
        if mist^.m[cis].use=-1 then begin
          x:=0;
          mist^.m[cis].use:=_kod^.delka+1;
          mist^.m[cis].imuse:=y;
        end;
      end;
      if x=1 then
        chyba('dvojn�sobn� definice programu '+slov+' m�stnosti '+mist^.m[cis].id);
      x:=gpl2kompiluj(fi,_kod,seznret,pricistret,seznpomret,ident,maxident,prik,talk);
      if x<>0 then chyba(chybhlasky[x]+' u programu '+slov+' m�stnosti '
        +mist^.m[cis].id);
      prevezmiretezcoveparametry(seznpomret,_kod,seznrozh,seznpal,seznhud,seznmap,obj);
      {parametry v �et�zc�ch typu 2-2 (palety, rozhovory a animace)
       p�ekonvertuje na ��seln� odkazy a zaznamen� je do seznam�}
    end else if slov='CANUSE' then begin
      if mist^.m[cis].canuse<>-1 then
        chyba('dvojn�sobn� definice podm�nky CANUSE u m�stnosti '+mist^.m[cis].id);
      uppercase(ret); {vz�t matematick� v�raz, zkompilovat ho a za�adit do k�du}
      x:=mat2postfix(ret,ident,postfix,krokupostfix);
      if x<>0 then chyba(chybhlasky[x]+' u podm�nky CANUSE m�stnosti '
        +mist^.m[cis].id);
      inc(_kod^.delka);
      mist^.m[cis].canuse:=_kod^.delka;
      move(postfix,_kod^.k[_kod^.delka],krokupostfix*2*sizeof(integer)-2);
      inc(_kod^.delka,krokupostfix*sizeof(integer)-1-1);
    end else if slov='BACK' then begin {definice pozad� m�stnosti}
      if mist^.m[cis].obr=#0 then
        mist^.m[cis].obr:=ret
      else
        chyba('dvojn�sobn� definice BACK '+ret+' m�stnosti '+mist^.m[cis].id)
    end else if slov='MUSIC' then begin {definice hudby v m�stnosti}
      if mist^.m[cis].mus=#0 then
        mist^.m[cis].mus:=ret
      else
        chyba('dvojn�sobn� definice MUSIC '+ret+' m�stnosti '+mist^.m[cis].id)
    end else if slov='MASK' then begin {definice masek m�stnosti}
      if mist^.m[cis].mask=#0 then
        mist^.m[cis].mask:=ret
      else
        chyba('dvojn�sobn� definice MASK '+ret+' m�stnosti '+mist^.m[cis].id)
    end else if slov='MAP' then begin {definice mapy m�stnosti}
      if mist^.m[cis].map=#0 then
        mist^.m[cis].map:=ret
      else
        chyba('dvojn�sobn� definice MAP '+ret+' m�stnosti '+mist^.m[cis].id)
    end else if slov='HERO' then begin {je hrdina v m�stnosti?}
      slov:=slovo(ret);
      uppercase(slov);
      if mist^.m[cis].hero<>255 then
        chyba('dvojn�sobn� definice HERO '+slov+' m�stnosti '+mist^.m[cis].id);
      if (slov='ON')or(slov='YES') then
        mist^.m[cis].hero:=1
      else if (slov='OFF')or(slov='NO') then
        mist^.m[cis].hero:=0
      else
        chyba('chyba p�i definici HERO '+slov+' m�stnosti '+mist^.m[cis].id);
    end else if slov='MOUSE' then begin {je my� v m�stnosti?}
      slov:=slovo(ret);
      uppercase(slov);
      if mist^.m[cis].mouse<>255 then
        chyba('dvojn�sobn� definice MOUSE '+slov+' m�stnosti '+mist^.m[cis].id);
      if (slov='ON')or(slov='YES') then
        mist^.m[cis].mouse:=1
      else if (slov='OFF')or(slov='NO') then
        mist^.m[cis].mouse:=0
      else
        chyba('chyba p�i definici MOUSE '+slov+' m�stnosti '+mist^.m[cis].id);
    end else if slov='PERSP0' then begin {prespektiva na 1. ��dku}
      slov:=slovo(ret);
      if mist^.m[cis].persp0<>-100 then
        chyba('dvojn�sobn� definice PERSP0 '+slov+' m�stnosti '+mist^.m[cis].id);
      val(slov,mist^.m[cis].persp0,ch);
{PP:zmena, persp0 muze byt i zaporna! neni taky duvod, proc ma byt <1!}
      if (ch<>0){or(mist^.m[cis].persp0<0)or(mist^.m[cis].persp0>1)} then
        chyba('chyba p�i definici PERSP0 '+slov+' m�stnosti '+mist^.m[cis].id);
    end else if slov='PERSPSTEP' then begin {krok prespektivy}
      slov:=slovo(ret);
      if mist^.m[cis].perspstep<>-100 then
        chyba('dvojn�sobn� definice PERSPSTEP '+slov+' m�stnosti '+mist^.m[cis].id);
      val(slov,mist^.m[cis].perspstep,ch);
      if (ch<>0)or(mist^.m[cis].perspstep<0)or(mist^.m[cis].perspstep>1) then
        chyba('chyba p�i definici PERSPSTEP '+slov+' m�stnosti '+mist^.m[cis].id);
    end else if slov='ESCROOM' then begin {definice escape m�stnosti}
      slov:=slovo(ret); {na�ti jm�no m�stnosti}
      uppercase(slov);
      if mist^.m[cis].escroom<>255 then
        chyba('dvojn�sobn� definice ESCROOM '+slov+' m�stnosti '+mist^.m[cis].id);
      if slov='' then
        mist^.m[cis].escroom:=0
      else begin
        y:=1;
        while (y<=mist^.pocet)and(slov<>mist^.m[y].id) do
          inc(y);
        if y>mist^.pocet then
          chyba('nezn�m� ESCROOM '+slov+' m�stnosti '+mist^.m[cis].id);
        mist^.m[cis].escroom:=y;
      end;
    end else if slov='GATE' then begin {definice gate ��slo X m�stnosti}
      slov:=slovo(ret); {na�ti jm�no m�stnosti}
      val(slov,valcis,ch);
      if (ch<>0)or(valcis<1)or(valcis>maxgatesmistnosti) then
        chyba('�patn� definice GATE '+slov+' m�stnosti '+mist^.m[cis].id);
      if valcis>mist^.m[cis].gates then
        mist^.m[cis].gates:=valcis;
      if mist^.m[cis].gate[valcis]<>0 then
        chyba('dvojn�sobn� definice GATE '+slov+' m�stnosti '+mist^.m[cis].id);
      mist^.m[cis].gate[valcis]:=_kod^.delka+1;
      x:=gpl2kompiluj(fi,_kod,seznret,pricistret,seznpomret,ident,maxident,prik,talk);
      if x<>0 then chyba(chybhlasky[x]+' u GATE '+slov+' m�stnosti '
        +mist^.m[cis].id);
      prevezmiretezcoveparametry(seznpomret,_kod,seznrozh,seznpal,seznhud,seznmap,obj);
      {parametry v �et�zc�ch typu 2-2 (palety, rozhovory a animace)
       p�ekonvertuje na ��seln� odkazy a zaznamen� je do seznam�}
    end else
      chyba('definov�na nezn�m� vlastnost '+slov+' m�stnosti '+mist^.m[cis].id);
  end;
  dispose(seznpomret);
  with mist^.m[cis] do begin
    if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
    if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
      inc(kod^.delka);
      canuse:=kod^.delka;
      kod^.k[kod^.delka]:=1;
      inc(kod^.delka);
      kod^.k[kod^.delka]:=0;
      inc(kod^.delka);
      kod^.k[kod^.delka]:=0;
    end;
    if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis+ikon^.pocet+obj^.pocet then
      chyba('(interni) pri MEZIzapisu programu mistnosti '+id);
    freemem(kod,2+maxobjdelkakodu*sizeof(integer));
  end;
  if cis<>mist^.pocet then
    chyba('(intern�) nesouhlas� po�et m�stnost� po kompilaci');
  for cis:=1 to mist^.pocet do
    with mist^.m[cis] do begin {p�ekonvertujeme nezadan� veli�iny}
      if gates=0 then
        chyba('m�stnost '+mist^.m[cis].id+' mus� m�t aspo� 1 GATE');
      for x:=1 to gates do
        if gate[x]=0 then
          chyba('GATEs m�stnosti '+mist^.m[cis].id+' netvo�� �adu 1..N');
      if title=#0 then title:={id}'|';
(*      if init=-1 then begin inc(kod^.delka); init:=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if look=-1 then begin inc(kod^.delka); look:=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if use=-1  then begin inc(kod^.delka); use :=kod^.delka; kod^.k[kod^.delka]:=0; end;
      if canuse=-1 then {canuse:=0;}{begin inc(kod^.delka); canuse:=kod^.delka; kod^.k[kod^.delka]:=0; end;} begin
        inc(kod^.delka);
        canuse:=kod^.delka;
        kod^.k[kod^.delka]:=1;
        inc(kod^.delka);
        kod^.k[kod^.delka]:=0;
        inc(kod^.delka);
        kod^.k[kod^.delka]:=0;
      end; *)
      if iminit=255 then iminit:=0;
      if imlook=255 then imlook:=0;
      if imuse=255  then imuse:=0;
      if obr=#0 then
        chyba('nedefinovan� pozad� m�stnosti '+mist^.m[cis].id+', pot�eba aspo� pro paletu')
      else if not existujesoubor(obr) then
        chyba('nenalezeno pozad� '+obr+' m�stnosti '+mist^.m[cis].id);
      if (mus<>#0)and(not existujesoubor(mus)) then
        chyba('nenalezena hudba '+mus+' m�stnosti '+mist^.m[cis].id);
      if (mask<>#0)and(not existujesoubor(mask)) then
        chyba('nenalezeny masky '+mask+' m�stnosti '+mist^.m[cis].id);
      if (map<>#0)and(not existujesoubor(map)) then
        chyba('nenalezena mapa '+map+' m�stnosti '+mist^.m[cis].id);
      if mouse=255 then mouse:=1;
      if hero=255  then hero:=1;
      if (persp0=-100)and(perspstep=-100) then begin
        persp0:=1;
        perspstep:=0;
      end;
      if (persp0=-100)or(perspstep=-100) then
        chyba('perspektiva m�stnosti '+mist^.m[cis].id+' se mus� definovat bu� cel� nebo v�bec');
      if escroom=255 then escroom:=0;
      {(bill) gates je nutno vyplnit}
{      if CADdfrommemory(pracprogramy,kod,2+kod^.delka*sizeof(integer))<>cis+ikon^.pocet+obj^.pocet then
        chyba('(interni) pri MEZIzapisu programu mistnosti '+id);
      freemem(kod,2+maxobjdelkakodu*sizeof(integer));}
    end;
  close(fi);
  writeln('zkompilov�ny v�echny vlastnosti m�stnost�');
  vyprazdniretezce(seznret,pricistret,pocitret,soubret1,soubret2);
end;

procedure kompilujmluveni;
var fi:text;
    akt:integer; {zrovna se kompiluje postava}
    ret,slov:string;
    cis:longint;
    ch:integer;
begin
  otevrisouborcteni(jmsoubmluveni,fi);
  akt:=0; {zat�m nikdo nen� definov�n}
  while not eof(fi) do begin
    readln(fi,ret);
    orizni(ret);
    uppercase(ret);
    if (ret='')or(ret[1]='{') then continue;
    slov:=slovo(ret);
    if slov='PERSON' then begin {dal�� mluv�c� postava}
      inc(akt);
      with pov^.p[akt] do begin {inicializujeme prom�nn� postavy}
        x:=-1;
        y:=-1;
        barva:=-1;
      end;
    end else if akt=0 then {definice vlastnosti, ani� byla definov�na postava}
      chyba('definice t�la mluven� p�ed definic� PERSON <jm�no_postavy> '+slov+' '+ret)
    else if slov='X' then begin {X}
      if pov^.p[akt].x<>-1 then
        chyba('dvojn�sobn� definice X-pozice '+ret+' mluv�c� postavy '+pov^.p[akt].id);
      val(ret,cis,ch);
      if (ch<>0)or(cis<0)or(cis>320) then
        chyba('�patn� definice X-pozice '+ret+' mluv�c� postavy '+pov^.p[akt].id);
      pov^.p[akt].x:=cis;
    end else if slov='Y' then begin {Y}
      if pov^.p[akt].y<>-1 then
        chyba('dvojn�sobn� definice Y-pozice '+ret+' mluv�c� postavy '+pov^.p[akt].id);
      val(ret,cis,ch);
      if (ch<>0)or(cis<0)or(cis>200) then
        chyba('�patn� definice Y-pozice '+ret+' mluv�c� postavy '+pov^.p[akt].id);
      pov^.p[akt].y:=cis;
    end else if slov='FONCOLOR' then begin {barva p�sma}
      if pov^.p[akt].barva<>-1 then
        chyba('dvojn�sobn� definice barvy '+ret+' mluv�c� postavy '+pov^.p[akt].id);
      val(ret,cis,ch);
      if (ch<>0)or(cis<0)or(cis>255) then
        chyba('�patn� definice barvy '+ret+' mluv�c� postavy '+pov^.p[akt].id);
      pov^.p[akt].barva:=cis;
    end else
      chyba('nezn�m� vlastnost '+slov+' mluv�c� postavy '+pov^.p[akt].id);
  end;
  for akt:=1 to pov^.pocet do begin {zkontrolujeme ka�dou postavu}
    if (pov^.p[akt].x=-1)or(pov^.p[akt].y=-1) then
      chyba('nebyly definov�ny pozice mluven� postavy '+pov^.p[akt].id);
    if pov^.p[akt].barva=-1 then
      chyba('nebyla definov�na barva mluven� postavy '+pov^.p[akt].id);
  end; {na�teme ��slo dal�� postavy}
  close(fi);
  writeln('zkompilov�ny v�echny vlastnosti mluv�c�ch postav');
end;

procedure kompilujrozhovory;
var x:integer;
    akt:integer;

 procedure kompilujrozhovor(soubor:string; cislo:integer; var akt:integer);
 {vraci pocet TITLU rozhovoru}
 var fi,fo:text;
     r:tseznamident;
     slov,ret,jm:string;
     x,y:integer;
     kod:pkod;
     postfix:tpostfix;
     delkapostfix:integer;
     seznpomret:pseznampomretezcu;
 begin
   nactiseznam(soubor,r,maxblokurozhovoru,'BLOCK','blok� rozhovoru');
   otevrisouborcteni(pracsoubident2,fi);
   otevrisouborzapis(pracsoubident3,fo);
   while not eof(fi) do begin
     readln(fi,ret);
     writeln(fo,ret);
   end;
   close(fi);
{   writeln(fo);
   writeln(fo,'class 9'); } {to u� tam je}
   for x:=1 to r.pocet do
     writeln(fo,r.i[x],' ',x);
   close(fo);
   dealokujidentifikatory(ident);
   x:=nactiidentifikatory(pracsoubident3,ident,maxident);
   if x<>0 then chyba(chybhlasky[x]+' u rozhovoru '+soubor);
   {nyn� m�me p�id�ny k identifik�tor�m i tyto nov�}
   str(cislo,ret);
   jm:=vysoubrozhovoru+ret+'.dfw';
   smazsoubor(jm); {v�stupn� dfw soubor}
   otevrisouborcteni(soubor,fi);
   getmem(kod,2+maxdelkakodu*sizeof(integer));
   kod^.delka:=0;
   new(seznpomret);
   seznpomret^.pocet:=0;
   akt:=0;
   while not eof(fi) do begin
     readln(fi,ret);
     orizni(ret);
     uppercase(ret);
     if (ret='')or(ret[1]='{') then continue;
     slov:=slovo(ret);
     if slov='BLOCK' then begin {nov� blok rozhovoru}
       slov:=slovo(ret); {slov=jm�no bloku, zn�me, nez�jem}
       x:=mat2postfix(ret,ident,postfix,delkapostfix);
       if x<>0 then chyba(chybhlasky[x]+' p�i zpracov�n� podm�nky '+
         ret+' rozhovoru '+soubor);
       caddfrommemory(jm,@postfix,delkapostfix*2*sizeof(integer));
       {zap��e se podm�nka do dfw-fajlu}
       inc(akt);
     end else
       chyba('o�ek�v� se definice bloku rozhovoru (BLOCK) '+soubor+
         ', ne '+slov+' '+ret);

     if eof(fi) then
       chyba('o�ek�v� se TITLE bloku rozhovoru '+soubor+', ne konec souboru');
     readln(fi,ret);
     orizni(ret);
     slov:=slovo(ret);
     uppercase(slov);
     if slov<>'TITLE' then
       chyba('o�ek�v� se TITLE bloku rozhovoru '+soubor+', ne '+slov+' '+ret);
     ret:=ret+'|';
     caddfrommemory(jm,@ret,length(ret)+1); {zap��e se title do dfw-fajlu}

     x:=gpl2kompiluj(fi,kod,seznret,pricistret,seznpomret,ident,maxident,prik,talk);
     if x<>0 then chyba(chybhlasky[x]+' p�i kompilaci bloku '+r.i[akt]+
       ' rozhovoru '+soubor);
     prevezmiretezcoveparametry(seznpomret,kod,seznrozh,seznpal,seznhud,seznmap,obj);
     {parametry v �et�zc�ch typu 2-2 (palety, rozhovory a animace)
      p�ekonvertuje na ��seln� odkazy a zaznamen� je do seznam�}

     if kod^.delka<>0
       then caddfrommemory(jm,@kod^.k[1],kod^.delka*sizeof(integer))
       else caddfrommemory(jm,@kod^.delka,1);
     {zapi� zkompilovan� k�d do dfw-fajlu}
     kod^.delka:=0;
   end;
   dispose(seznpomret);
   freemem(kod,2+maxdelkakodu*sizeof(integer));
   close(fi);
   writeln('zkompilovan rozhovor '+fsplit2(soubor,6));
   vyprazdniretezce(seznret,pricistret,pocitret,soubret1,soubret2);
 end;

begin
  x:=1;
  while x<=rozh^.pocet do begin {mohou postupn� p�ib�vat}
    kompilujrozhovor(rozh^.r[x]^,x,akt);
    freemem(rozh^.r[x],length(rozh^.r[x]^)+1); {zapiseme pocet TITLU}
    getmem(rozh^.r[x],2);
    rozh^.r[x]^[0]:=#1;
    rozh^.r[x]^[1]:=char(akt);
    inc(x);
  end;
  {nedealokovat �et�zce
   misto jmen souboru v nich ted budou pocty jejich TITLU}
  dealokujidentifikatory(ident);
  x:=nactiidentifikatory(pracsoubident2,ident,maxident);
  if x<>0 then chyba(chybhlasky[x]+' po rozhovorech');
  {obnovit identifik�tory}
end;

end.

{todo: mo�n� ikony a objekty skladovat v pam�ti �pln� stejn�, kdy� jsou
         stejn� (ne, nejsou)
       v p��kazech, kde je par. ��slo, d�t mo�nost i mat. v�raz (nap�.
         m�st sou�adnic v�raz podle akt. pozice, nebo t�eba i ident. m�st
         umo�nit zadat jako v�raz, tam toti� jde ident. m�st taky pou��t)
       + ve v�razech budou v�ci jako PosledniBod a HrdinaX zavedeny, ale
         nebudou jako prom�nn�, ale jako ident. (� la on...) a mat.
         vyhodnocova� (on jedin� se s nimi setk�) je rozezn� a dopln�
       kontrola persp0 a perspstep je empirick� (pod/nadte�en�)
       gm4 a� p�i odvozen� cesty ka masce a map� p�ep��e nejenom p��ponu,
         ale i cestu

TODO!: brat v uvahu Pavlovy `kidy': pridat | na konec titlu (done),
         mazat mezety v �et�zc�ch (todo), nen�-li maska, tak br�t
         z obr�zku pozad� pouze paletu (todo), hudby povolit nova (cislo)
         nebo zustat stara (0)
       a v�bec! d�vat #13 a ne |, kdy� u� to um� gpl2 (t��k�), pro� by to
         nem�la um�t animace4 (lehk�)?
       zpracovat polo�ky, kter� nebyly def., ud�lat tu reakci na nedefinici
         obr�zku m�stnosti (nebo definici pr�zdn�ho) --- �e to pak nem�
         ani ��dn� masky...
       zkompilovat 2-pr�chodov� rozhovory
       bacha na p�ete�en� u rozhovor� a palet
- cht�lo by to Linux, kter� ka�d� vyte�en� z pam�ti striktn� ohl�s�}
