{!!!!!!!!!!pavle: v initu hry je po�et objekt� u� integer!!!!!!!!!!!!!!}

{definice v�stupn�ch record�}

unit k3vystup;
interface
uses k3togeth;

type tvystikony=record
       init,look,use,canuse:integer;
       iminit,imlook,imuse:byte;
{       status:byte;
       obr:byte;}
       {od��znut id, obr--->byte,
        title a kod je jinde}
     end;

     tvystobjektu=record
       init,look,use,canuse:integer;
       iminit,imlook,imuse:byte;
       typ:byte; {walkdir}
{       status:byte;
       mistnost:byte;}
       priorita: byte;
       idxanim, pocanim: integer;
       {o��znut id, anim--->2 indexy,
        title a kod je jinde}
       xlook,ylook,xuse,yuse:integer;
       smerlook,smeruse:byte;
     end;

     tvystmistnosti=record
{       GateProg: pointer;}
       Prog: pointer;
       ProgLen: word;
       Title: pointer;
       {***}
       mus,map,pal:byte;
       {startmasek,}pocmasek:integer;
       init,look,use,canuse:integer;
       iminit,imlook,imuse:byte;
       mouse,hero:byte;
       persp0,perspstep:real;
       escroom:byte;
       gates:byte;
       gate:array[1..maxgatesmistnosti]of integer;
       {priormasek:array[1..maxpocetmasek]of byte;}
       {o��znut je id, mus/map--->2 indexy, obr/mas--->obr�zky,
        title a kod je jinde}
     end;

     tvystinithry=record
{PP:}  ActualRoom: byte; {pro kompilator: startovni mistnost}
       map: byte;
       pocetobj, pocetikon{, pocetmist}: {byte!!!}integer;
       pocetprom: byte;
       pocetpostav,pocetrozh:byte;
       {odd�l�no stary, hero, gatestart, gatemap
        p�id�n pocetobj a pocetmist}
       imaxx,imaxy:integer;
       maxhud:word;
       crc:array[1..4]of word;
     end;

     tvystpovidacka=record
       x,y:integer;
       barva:byte;
       {o��znut je id}
     end;

     {used from Pavel}
     PAnimation= ^TAnimation;
     {popis animacnich sekvenci; pracuje s tim hlavne anmplay...}
     {takhle vypadajici animacni sekvence lezou z aomakera:}
     TAnmPhase= record
       Picture      : word;        {cislo obrazku ze skladu}
       X            : integer;     {souradnice x}
       Y            : integer;     {souradnice y}
       ZoomX        : word;        {zoom na ose x}
       ZoomY        : word;        {zoom na ose y}
       Mirror       : byte;        {0=normal, 1=zrcadlit obrazek}
       Sample       : word;        {cislo samplu ze skladu}
       Frequency    : word;        {frekvence samplu}
       Delay        : word;        {zdrzeni pred dalsi fazi}
     end;
     TAnmHeader= record
       NumOfPhases    : byte;      {pocet fazi animace}
       MemoryLogic    : byte;      {0=vsechny sprajty jsou v pameti (napr. chuze hlavniho hrdiny)
                                    1=v pameti vyhrazeno misto pro nejvetsi
                                      sprajt a vsechny sprajty se nacitaji
                                      prave do tohoto mista (napr. okno, ktere je nejdriv cele,
                                      pak se rozbiji a nakonec je rozbite)
                                    2=sprajty se pricitaji z disku (napr. jak se hl. hrdina
                                      pro neco shyba, neco pouziva...)}
       DisableErasing : byte;      {0=maze se pod, 1=nemaze se}
       Cyclic         : byte;      {0=zacit a skoncit, 1=cyklicka furt dokola}
       Relative       : byte;      {0=absolutni souradnice, 1=relativni}
     end;
     TAnmPhasesArray= array[1..255] of TAnmPhase;
     TAnimation= record
       Header         : TAnmHeader;
       Phase          : TAnmPhasesArray;
     end;

implementation

end.

{todo:
  title dat k programum; NE, kdy� u� je to d�len�, tak na 3 slo�ky!
mo�n�:
  pov<>obj, ale mo�nost d�t stejn� jm�na
  slo�ky animac� neuv�d�t v ""}
