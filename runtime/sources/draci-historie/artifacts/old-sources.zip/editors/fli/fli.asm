.286c

model small,pascal

public initgraph, closegraph
public fce_clear
public fce_putimage
public fce_putcompimage
public fce_changeimage
public fce_palette

.code

initgraph proc far
          mov ax,0013h
          int 10h
          ret
initgraph endp

closegraph proc far
          mov ax,0003h
          int 10h
          ret
closegraph endp

fce_clear proc far
          arg s,v

          push es di ax cx dx

          mov ax,0a000h
          mov es,ax
          xor di,di
          cld

          mov cx,ss:word ptr v
clear1radek:
          mov dx,cx
          mov cx,ss:word ptr s
          rep stosb
          sub di,ss:word ptr s       ;posu� se na dal�� ��dek
          add di,320d
          mov cx,dx
          loop clear1radek

          pop dx cx ax di es

          ret
fce_clear endp

fce_putimage proc far
             arg s,v,obr:word:2

             push ds es si di ax cx dx

             mov si,ss:word ptr obr
             mov ds,ss:word ptr obr+2
             mov ax,0a000h
             mov es,ax
             xor di,di
             cld

             mov cx,ss:word ptr v
put1radek:
             mov dx,cx
             mov cx,ss:word ptr s
             rep movsb
             sub di,ss:word ptr s       ;posu� se na dal�� ��dek
             add di,320d
             mov cx,dx
             loop put1radek

             pop dx cx ax di si es ds

             ret
fce_putimage endp

fce_putcompimage proc far
             arg s,v,obr:word:2

             push ds es si di ax bx cx

             mov si,ss:word ptr obr
             mov ds,ss:word ptr obr+2
             mov ax,0a000h
             mov es,ax
             xor di,di
             cld

             mov bx,320d                ;nastav� parametry putov�n�
             sub bx,ss:word ptr s
             mov cx,ss:word ptr v       ;��dky

             ;ka�d� ��dek je komprimov�n zvl���!
             xor ah,ah
putc1radek:
             lodsb
             push cx                    ;ulo� ��dky, dej pakety
             mov cx,ax
putc1paket:
             push cx                    ;ulo� pakety, dej body
             lodsb
             mov cx,ax
             test al,80h
             jz putc_opakovane
             mov ch,0ffh
             neg cx
;             and cl,7fh
             rep movsb                  ;ulo� �et�zec
             jmp short putc_popaketu
putc_opakovane:
             lodsb
             rep stosb                  ;ulo� 1 hodnotu
putc_popaketu:
             pop cx                     ;obnov paket
             loop putc1paket
             pop cx                     ;obnov ��dky
             add di,bx                  ;p�esu� se na dal�� ��dek
             loop putc1radek

             pop cx bx ax di si es ds

             ret
fce_putcompimage endp

fce_changeimage proc far
                arg s,v,obr:word:2

                push ds es si di ax bx cx dx

                mov si,ss:word ptr obr
                mov ds,ss:word ptr obr+2
                mov ax,0a000h
                mov es,ax
                cld

                lodsw                           ;prvn� ��dek
                mov bx,320
                mul bx
                mov di,ax                       ;adresa za��tku
                lodsw                           ;po�et ��dk�
                mov cx,ax

                xor ah,ah
chg1radek:
                push di                         ;ulo� za��tek
                lodsb
                push cx                         ;ulo� ��dky, dej pakety
                mov cx,ax
chg1paket:
                or cx,cx                        ;m��e b�t i 0 paket�...
                jz chg_konecradku
                dec cx
                lodsb                           ;x-posunut�
                add di,ax
                push cx                         ;ulo� pakety, dej body
                lodsb
                mov cx,ax
                test al,80h
                jnz chg_opakovane               ;zde je to opa�n�!
                rep movsb                       ;ulo� �et�zec
                jmp short chg_popaketu
chg_opakovane:
                mov ch,0ffh
                neg cx
;                and cl,7fh
                lodsb
                rep stosb                  ;ulo� 1 hodnotu
chg_popaketu:
                pop cx                     ;obnov paket
                jmp short chg1paket
chg_konecradku:
                pop cx                     ;obnov ��dky
                pop di                     ;posu� se na dal�� ��dek
                add di,320
                loop chg1radek

                pop dx cx bx ax di si es ds

                ret
fce_changeimage endp

fce_palette proc far                    ;nastav� paletu obr�zku
            arg pal:word:2

            push ds si ax cx dx

            mov si,ss:word ptr pal
            mov ds,ss:word ptr pal+2
            cld

            xor ah,ah
            lodsb                       ;po�et paket�
            mov cx,ax
pal1paket:
            push cx                     ;ulo� paket, dej po�et barev
            lodsb              ;za��tek
            mov dx,3c8h        ;adresov�n� data registru
            out dx,al
            inc dx
            lodsb
            mov cx,ax           ;po�et bajt�
            add cx,ax
            add cx,ax
            or al,al            ;0?
            jnz pal_ne_256
            mov cx,3*256        ;256!
pal_ne_256:
            rep outsb           ;posl�n� v�ech dat
            pop cx
            loop pal1paket

            pop dx cx ax si ds

            ret
fce_palette endp

end
