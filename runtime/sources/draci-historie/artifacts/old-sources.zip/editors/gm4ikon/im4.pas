{game maker4 --- pouze editor m�stnost�}
program GameMaker4;
uses graph256,
     im4toget,im4cti,im4vyber,
     dos;

var mem,max:longint;
    x:integer;

    idx,akce:integer;
    mist:tseznammistnosti;

procedure chyba(text:string);
begin
  writeln(text,#7);
  halt(1);
end;

procedure initgrafiky;
var
    ret:string;
    fi:text;
begin
  ret:=jencesta(fexpand(paramstr(0)));

  assign(fi,{ret+}'im4.cfg');
  {$i-} reset(fi); {$i+}
  if ioresult=0 then begin
    readln(fi,adresarikon);
    readln(fi,adresarobrazku);
    adresarikon:=fexpand(adresarikon);
    adresarobrazku:=fexpand(adresarobrazku);
    close(fi);
  end; {jinak se nech� default hodnota}


  if not sti(ret+'mouse.gcf',
             ret+'stand2.pal',
             ret+'stand2.fon') then
    chyba('nelze inicializovat grafiku');
  mouseon(0,0,mouseimage);

  mouseswitchoff;
  setactivepage(0);
  barvapozadi:=255;
  clearscr(barvapozadi);
  obrpal:=nil;
end;

procedure help;
begin
  writeln('syntax: im4 [<soubor_s_ikonami>, jinak `ikon.''] nebo /?');
  writeln;
  writeln('Soubory s grafikou hled� v adres��i, kde je im4');
  writeln('Soubor s m�stnost� hled� v akt. adres��i, nen�-li zad�n');
  writeln('Soubor s konfigurac� (cesty ikon...) hled� v akt. adres��i');
  halt(0);
end;

begin
  mem:=memavail;
  max:=maxavail;

  if paramcount>1 then
    chyba('syntax: im4 [<soubor_s_ikonami>, jinak `mist.''] nebo /?');
  if paramcount=1 then
    if paramstr(1)='/?' then
      help
    else begin
      jmsoubmist:=fexpand(paramstr(1));
      jmpomsoubmist:=jencesta(jmsoubmist)+jmpomsoubmist;
    end;

  x:=ctiseznammistnosti(jmsoubmist,mist);
  if x<>0 then
    chyba('chyba v souboru se seznamem ikon');

  initgrafiky;

  editujseznammistnosti(mist);

  {obr�zky se SAVuj� pr�b��n�}

  dealokujseznammistnosti(mist);

  ste;
  if obrpal<>nil then
    freemem(obrpal,768);

  if (mem<>memavail)or(max<>maxavail) then
    write(#7);
end.
