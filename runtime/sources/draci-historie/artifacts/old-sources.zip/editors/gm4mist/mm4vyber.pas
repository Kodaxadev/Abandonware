{procedura vych�zej�c� z ListBoxu, kter� umo�n� listovat po seznamu
 m�stnost� a �ekat na vyvol�n� n�kter� akce

 je ve videostr�nce ��slo 2 (tedy 3. v po�ad�), na za��tku se tedy vykresl�
 a pak u� se beze �kody jen edituje (p��p. dialog o parametrech m�stnosti
 bude ve videostr�nce ��slo 1), editace masky a mapy bude ve videostr�nce
 ��slo 0, maska bude ulo�ena ve videostr�nce ��slo 3 a obr�zek samotn� bude
 v pam�ti, nebo� tak to po�aduje MakeObj}

unit mm4vyber;
interface
uses mm4cti,graph256;

procedure editujseznammistnosti(var m:tseznammistnosti);

implementation
uses crt,dialog,users,
     mm4akce,mm4toget;

type TOffsetu=array[1..3]of integer; {pozice jednotl. sloupc�}
     {tak jako v listboxu, a� na to, �e se nevezmou podle z�znam�, ale
      natvrdo a ve v�pisu je kontrola na p�es�hnut�}

const x:integer=0;
      y:integer=0;
      dx=310; {podle n�j se vezmou sloupce; doladit!}
      pocet:integer=16; {dy se vypo��t� norm�ln�}
      hlavicka='Vyber si m�stnost a provedenou akci';
      paticka='n�pov�da k akc�m je dole';
      nap1='    Esc=konec; Ent=editace; Ins=nov�; Del=smaz�n�';
      nap2='        Tab=prohl�dni pozad�; S=masky; P=mapy';
      {font=font; ale to nen� konstanta}
{      Popr=15;
      Poz=7;
      Podtr=12;
      Ram=10;
      Okr=8;}

procedure editujseznammistnosti(var m:tseznammistnosti);
var {Obsah:PObsahu;                {obsah prohl��en�ho adres��e}
    {PocetPol:integer;             {po�et polo�ek}
    Offsety:TOffsetu;             {kde za��naj� jednotl. polo�ky}
    {uchovpozadi:pointer;          {p�vodn� pozad� pod dialogem}
    akce:byte;                    {po�adovan� akce podle my�i nebo kl�vesnice}
      {0=Escape
       1=Enter, kliknut� my��
           kam, to se nastav� do Akt1 a Zac1
       2=pouze pohyb zv�razn�n�,
           kam, to se tak� nastav� do Akt1 a Zac1

       3=insert;
       4=delete;
       5=maSky
       6=maPy
       7=view}
    Zac,Akt,Zac1,Akt1:integer;    {star� a nov� pozice r�me�ku}

procedure vypistext(idx:integer);
{vyp��e na obrazovku zadan� ��dek od vrchu obrazovky}
var py,i:integer;
    ret:string;
begin
  FonColor1:=dcolor[1];                       {vypis zadanou barvou}
  OverFontColor:=255;                    {barva pozadi je 255}

  py:=y+idx*heigthoffont(font)+1;
  if (Zac+Idx-1)<=m.pocet then begin         {vyp��e v�echny polo�ky}
(*    for i:=1 to pocetpol do
      if obsah^[zac+idx-1]^[i]<>'' then begin
        ret:=copy(obsah^[Zac+Idx-1]^[i],1,
          charstowidth(font,obsah^[Zac+Idx-1]^[i],1,offsety[i+1]-offsety[i],
          false)); {aby to nep�es�hlo r�me�ek}
        printtext(x+1+offsety[i],py,ret,font);
      end; *)
    if m.m[zac+idx-1]^.symb<>'' then begin
      ret:=copy(m.m[Zac+Idx-1]^.symb,1,
        charstowidth(font,m.m[Zac+Idx-1]^.symb,1,offsety[2]-offsety[1],
        false)); {aby to nep�es�hlo r�me�ek}
      printtext(x+1+offsety[1],py,ret,font);
    end;
    if m.m[zac+idx-1]^.jm<>'' then begin
      ret:=copy(m.m[Zac+Idx-1]^.jm,1,
        charstowidth(font,m.m[Zac+Idx-1]^.jm,1,offsety[3]-offsety[2],
        false)); {aby to nep�es�hlo r�me�ek}
      printtext(x+1+offsety[2],py,ret,font);
    end;
  end;
  {bez ifu --- bude to i na neexistuj�c�ch polo�k�ch --- odd�lovac� ��ry}
{  for i:=2 to pocetpol do
    liney(x-1+offsety[i],py,heigthoffont(font),okr);}
  liney(x-1+offsety[2],py,heigthoffont(font),dcolor[5]);
end;

procedure zvyraznitext(idx:integer);
{zv�razn� dan� ��dek p�ebarven�m pozad� na jinou barvu}
begin
  replacecolor(x+1,y+idx*heigthoffont(font)+1,
               offsety[3],heigthoffont(font),
               dcolor[2],dcolor[4])
  {zm�n� barvu pozad� na barvu zv�razn�n�}
end;

procedure zruszvyrazneni(idx:integer);
{p�etiskne dan� ��dek barvou pozad�}
begin
  bar(x+1,y+idx*heigthoffont(font)+1,
      offsety[3],heigthoffont(font),
      dcolor[2])
  {vypln� barvou pozad�}
end;

procedure posuvnik(vidit:boolean);
{vyp��e/sma�e vpravo od seznamu soubor� posuvn�k relativn� pozice obrazovky}
var del,             {relativn� velikost posuvn�ku k celku}
    mis,             {relativn� po��tek posuvn�ku k celku}
    pom:longint;     {ud�vaj� velikost cel�ho sloupku v bodech}
      {je to LongInt proto, �e v�raz pom*(zac-1) div adresar^.pocet
       p�ekra�uje v m�m adres��i Windows velikost integer a nev�m, zda by se
       vlezl do Wordu
       proto mus�m je�t� p�edt�m ne� to poDIVuji to p�ev�st na LongInt
       a touto definic� se vyhnu nespolehliv�mu (v BP) p�etypov�ni
       poDIVovat to d��v (jin� po�ad� operac�) to nechci kv�li p��padn�
       ztr�t� p�esnosti}
    barva:byte;      {barva vypisovan�ho posuvn�ku}
begin
  if m.pocet=0 then {nebude se d�lat posuvn�k}
    exit;
  pom:=pocet*heigthoffont(font);
  if m.pocet-Zac+1<=Pocet then begin
    del:=pom* (m.pocet-Zac+1) div m.pocet;
    mis:=pom- del
  end else begin
    del:=pom* pocet div m.pocet;
    mis:=pom* (zac-1) div m.pocet
  end;
  {vypiplan� 2 varianty pro nezapln�n� a zapln�n� panel, mysl�m, �e je to
   dokonal� a ukazuje to v�dy p�esn�}
  if vidit
    then barva:=dcolor[1]
    else barva:=dcolor[2];
  if del<>0 then
    bar(x+offsety[3]+2,
        y+heigthoffont(font)+mis,
        widthoffont(font),
        del,
        barva)
  else
    linex(x+offsety[3]+2,
          y+heigthoffont(font)+mis,
          widthoffont(font),
          barva)
  {ten if tam mus�m d�t proto, �e procedura Bar p�i v��ce 0 ud�l�
   obd�ln�k o ���ce 0 - tedy ��dn� a j� to mus�m vid�t}
end;

procedure kontrolujmeze(var akt,zac:integer);
{zkoriguje 2 parametry tak, aby to byly spr�vn� �daje o pozici}
begin
  if akt>m.pocet then             {p�ete�en� Akt}
    akt:=m.pocet;
  if akt<1 then                    {podte�en� Akt}
    akt:=1;

  if akt<zac then                  {rolov�n� nahoru}
    zac:=akt-pocet div 3{+1};
{!!!!! ta +1 tam nesmi byt, viz. nahore !!!!!}
  if akt>zac+pocet-1 then          {rolov�n� dolu}
    zac:=akt-2*pocet div 3;
  {tento zp�sob rolov�n� v p��pad� vyjet� posune okraj tak, aby byl r�me�ek
   pr�v� v 1/3 okna
   mo�n�, �e to nevypad� ta efektn�, ale je to p�i dr�en� �ipky nahoru nebo
   dol� to nejrychlej��}

  if zac>m.pocet-pocet+1 then     {p�ete�en� Zac}
    zac:=m.pocet-pocet+1;
  if zac<1 then                    {podte�en� Zac}
    zac:=1
end;

procedure KresliPanel;
  forward;
procedure SmazPanel;
  forward;
procedure VypisSeznam(i1,i2:integer);
  forward;
procedure mistoproposuvnik;
  forward;

procedure cekejnaudalost;
{�ek� na ud�lost z kl�vesnice a my�i, analyzuje ji a p�ed� ji d�l}
label PageUp,PageDown;
var j,mkey,mx,my:integer;
    znak:char;

(*
procedure posundialogu;
{posouv� panel ListBoxu po obrazovce}
var mys:pointer;
    i:byte;
begin
  pushmouse;
  mouseswitchoff;
  newimage(offsety[3]+widthoffont(font)+3,
    (pocet+2)*heigthoffont(font),mys);
  getimage(x,y,offsety[3]+widthoffont(font)+3,
    (pocet+2)*heigthoffont(font),mys);
  putimage(x,y,uchovpozadi);
  {obnov� pozad� a zapamatuje si dialog a my�}

  mouseon(mx-x,my-y,mys);
  newmousearea(mx-x,my-y,320-(offsety[3]+widthoffont(font)+3),
    200-(pocet+2)*heigthoffont(font));
  repeat
  until mousekey<>0;
  {nyn� dialogem pohybuje jako my��}

  inc(x,mousex-mx);
  inc(y,mousey-my);
  {zm�n� sou�adnice dialogu}

  mouseswitchoff;
  getimage(x,y,offsety[3]+widthoffont(font)+3,
    (pocet+2)*heigthoffont(font),uchovpozadi);
  putimage(x,y,mys);
  disposeimage(mys);
  {obnov� na obrazovce dialog na nov�m m�st� v�etn� zapamatov�n�
   nov�ho pozad�}

  repeat
  until mousekey=0;
  newmousearea(0,0,320,200);
  popmouse
  {obnov� stav my�i}
end;

procedure zoomdialogu;
{zoomuje panel ListBoxu}
var novypocet:integer;
begin
  pushmouse;
  repeat
    novypocet:=maxinteger((mousey-y{-1}) div heigthoffont(font)-2,1);
    {zoomuj podle my�i, ale mus� b�t na panelu aspo� 1 ��dek}
{myslim, �e podle logiky by tam to -1 m�lo byt, ale podle zku�enost� ne
 a bez n�j mohu stand2 nazoomovat na 20 radku, tj. 18 ��dk� pro soubory}
    if novypocet<>pocet then begin
      mouseswitchoff;
      smazpanel;
      pocet:=novypocet;
      kreslipanel;
      kontrolujmeze(akt,zac);
      vypisseznam(1,pocet);
      zvyraznitext(akt-zac+1);
      akt1:=akt;
      zac1:=zac;
      mistoproposuvnik;
      posuvnik(true);
      mouseswitchon
    end
  until mousekey<>0;
  repeat
  until mousekey=0;
  popmouse
end;
*)

begin
  {vypne a zapne my� na za��tku a na konci procedura, kter� n�s vol�}
  zac1:=zac;
  akt1:=akt;
    {nastav nejpravd�podobn�j�� zv�razn�n� po �ekani na ud�lost}
  repeat
    while not keypressed do       {�ekej na stisk kl�vesy nebo my�i}
      if mousekey<>0 then begin
        mkey:=mousekey;
        {vezmeme si tla��tka my�i}
        repeat
        until mousekey<>mkey;
        {po�k�me, a� u�ivatel odm��kne tla��tko, nebo zm��kne n�co
         jin�ho atp.}
        mx:=mousex;
        my:=mousey;
        {nyn� si vezmeme pozici my�i, abychom odm��kli to, kde skon��}
        if mkey<>$01 then begin       {jin� ne� lev� tla��tko ===> Escape}
          akce:=0;
          exit

        end else                      {jinak je to lev� tla��tko :}

        if not inbar(mx,my,x+1,y,     {�pln� mimo dialogov� panel ===> nic}
                 offsety[3]+widthoffont(font)+1, {o�ez�v�m vlevo o 1 bod}
                 (pocet+2)*heigthoffont(font)) then
          continue

        else begin
          j:=(my-y-1) div heigthoffont(font); {pod�v�me se, kam padl}

          if inbar(mx,my,x+1,y+1,  {je v prostoru pro soubory ?}
                   offsety[3],
                   (pocet+2)*heigthoffont(font)-2) then
{ud�lat, a� to nebere klik, pokud se klikne p�esn� mezi ��dky !!!!!}
            {zde to m�me kr�sn� jednozna�n�, proto�e se mi nic nep�ekr�v�}
            if j=0 then begin         {naho�e=posun dialogu}
              {posundialogu;}
              continue
            end else if j>pocet then begin {dole=zoom dialogu}
              {zoomdialogu;}
              continue
            end else begin            {jinak je to skok na n�jak� soubor}
              if j+zac1-1>m.pocet then
                Continue;
                {pokud jsme se trefili sice do dialogov�ho a panelu a do
                 prostoru pro soubory, ale soubor� je m�lo a zb�v� tam
                 voln� m�sto, pak jsme se nikam netrefili a testujeme ud�lost
                 znovu, jako by se nic nestalo}
              akt1:=j+zac1-1;
              akce:=1;
              exit
            end

          else                {jinak je to v prostoru pro posuvn�k}
            if j=0 then               {naho�e=pageup}
              goto PageUp
            else if j>pocet then      {dole=pagedown}
              goto pagedown
            else begin                {jinak je to klik do posuvn�ku}
              {p�esun na nov� soubor}
              akt1:=integer( {p�etypov�ni je nutn� (viz. \windows\system)}
                longint((my-y-heigthoffont(font)-1))
                        *(m.pocet+1) {a� to m��e i na ten posledn�...}
                        div (pocet*heigthoffont(font)));
{mysl�m, �e na prvn� to sk��e po dost dlouh� dr�ze (2* v�c ne� ostatn�)!}
              kontrolujmeze(akt1,zac1);
              akce:=2;
              exit
            end
        end
      end;

    {jinak nastalo zm��knut� kl�vesy}
    znak:=readkey;
    if znak=#27 then begin     {Esc, p�ed�me Esc}
      akce:=0;
      exit
    end else

    if znak=#13 then begin     {Enter, p�ed�me ��zen� aktu�ln�mu objektu}
      akce:=1;
      exit
    end else

    if znak=#9 then begin {tab, view}
      akce:=7;
      exit;
    end else

    if (znak='s')or(znak='S') then begin {masky}
      akce:=5;
      exit;
    end else

    if (znak='p')or(znak='P') then begin {mapy}
      akce:=6;
      exit;
    end else

    if (znak=#0)and(KeyPressed) then begin {#0, �teme dal�� kl�vesu}
      znak:=readkey;
      case znak of
        #72:begin              {�ipka nahoru, pouze posun}
          dec(akt1);
          kontrolujmeze(akt1,zac1);
          akce:=2;
          exit
        end;
        #80:begin              {�ipka dol�, pouze posun}
          inc(akt1);
          kontrolujmeze(akt1,zac1);
          akce:=2;
          exit
        end;
        #73:PageUp:begin       {PageUp sko�� o str�nku nahoru}
              Dec(akt1,Pocet);
              kontrolujmeze(akt1,zac1);
              akce:=2;
              exit
            end;
        #81:PageDown:begin     {PageDown sko�� o str�nku dol�}
              Inc(akt1,Pocet);
              kontrolujmeze(akt1,zac1);
              akce:=2;
              exit
            end;
        #71:begin              {Home sko�� na za��tek seznamu}
              Akt1:=1;
              Zac1:=1;
              akce:=2;
              exit
            end;
        #79:begin              {End sko�� na konec seznamu}
              Akt1:=m.pocet;
              Zac1:=Akt1;
              kontrolujmeze(akt1,zac1);
              akce:=2;
              exit
            end;
        #82:begin {insert}
          akce:=3;
          exit;
        end;
        #83:begin {delete}
          akce:=4;
          exit;
        end;
      end
    end else                   {jin� kl�vesa, pokus�me se zjisit, kam ukazuje}
      {tady mo�n� ud�lat zv�razn�n� kl�vesy, mo�n� to zav�st u� sem}

    {jestli�e se ud�lost nikde "nezachyt�", testujeme znovu}
  until false;
  {nekone�n� cyklus, vyskakuje se z n�j p�i nalezen� vhodn� ud�losti
   p��kazem Exit
   procedura v�dy vr�t�, co bylo zm��knuto, p��padn� to zm��knut� trochu
   o�id� (emulace p�i ud�losti my�i), t�m je p�ad�no ��zen� n�kter�mu
   objektu a my m��eme pokra�ovat d�l}
end;

{!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!}

procedure KresliPanel;
var ret:string;
begin
{nebude se nic m�nit, kdy� to je podle dx, proto�e podle toho d�m i offsety
 neuchov�v� se pozad�!}
  rectangle(X,Y,offsety[3]+widthoffont(font)+3,
    (pocet+2)*heigthoffont(font),dcolor[5]);
  bar(X+1,Y+1,offsety[3]+widthoffont(font)+1,
    (pocet+2)*heigthoffont(font)-2,dcolor[2]);
  {p�iprav� obrazovku a my� k v�b�ru z�znamu}
  Bar(x+offsety[3]+2,y+1,
      widthoffont(font),
      heigthoffont(font)-1,
      dcolor[3]);
  Bar(x+offsety[3]+2,y+(pocet+1)*heigthoffont(font),
      widthoffont(font),
      heigthoffont(font)-1,
      dcolor[3]);
  LineY(x+offsety[3]+1,y,
      (pocet+2)*heigthoffont(font),
      dcolor[5]);
  {ud�l� naho�e a dole u posuvn�ku 2 mal� zna�ky - vypln�n� �tvere�ky}

  Ret:=Hlavicka;
  while widthoftext(font,Ret)>offsety[3] do
    dec(ret[0]);
  FonColor1:=dcolor[3];
  OverFontColor:=255;
  if ret<>'' then
    Printtext(X+(offsety[3]-widthoftext(font,Ret)) div 2+1,
              Y+1,Ret,font);
  {vyp��e na horn� ��dek dialogu hlavi�ku}

  Ret:=Paticka;
  while widthoftext(font,Ret)>offsety[3] do
    dec(ret[0]);
  if ret<>'' then
    Printtext(X+(offsety[3]-widthoftext(font,Ret)) div 2+1,
              Y+(pocet+1)*heigthoffont(font),Ret,font);
  {vyp��e na doln� ��dek dialogu pati�ku}

  foncolor1:=dcolor[1];
  PrintText(0,200-2*heigthoffont(font),nap1,font);
  PrintText(0,200-heigthoffont(font),nap2,font);
end;

procedure SmazPanel;
begin
{  putimage(X,Y,uchovpozadi);
  disposeimage(uchovpozadi)}
end;

procedure mistoproposuvnik;
begin
  Bar(x+offsety[3]+2,y+heigthoffont(font),
      widthoffont(font)-3,pocet*heigthoffont(font),
      dcolor[2])
  {vykresl� pozad� pro posuvn�k, aby tam nebyly ��dn� ru�iv� zbytky z minula
   (p�i zoomu)}
end;

procedure Inicializace;
var i,j,k:integer;
    ret,subret:string;
begin
  offsety[1]:=0;
  offsety[2]:=dx div 3;
  offsety[3]:=dx;

  zac:=1;
  akt:=1;

  pushmouse;
  mouseswitchoff;
  setactivepage(2);
  setvisualpage(2);
  KresliPanel;
end;

procedure Finalizace;
var i:integer;
begin
  SmazPanel;
  popmouse;
  {vr�t� v�e do p�vodn�ho stavu}
end;

procedure VypisSeznam(i1,i2:integer);
{vyp��e natvrdo seznam z�znam� v okn� od pozice i1 do pozice i2}
var Idx:integer;
begin
  bar(x+1,y+i1*heigthoffont(font)+1,
      offsety[3],(i2-i1+1)*heigthoffont(font),
      dcolor[2]);
  {nejprve sma�eme obd�ln�k, kter� budeme p�ekreslovat
   je to rychlej�� a elegantn�j�� ne� to d�lat po ��dc�ch a zvl���}

  for Idx:=i1 to i2 do
    vypistext(idx);
  {nyn� do toho pouze vep��eme samotn� texty}
end;

procedure Rolovani;
{pokud se zm�nil po��tek vykreslov�ni seznamu soubor�, pokus� se tato
 procedura p�ekreslit obrazovku tak �ikovn�, aby se nemusel moc vypisovat
 seznam text� (pou�ije k tomu efekt rolov�n�, kter�m posune ty z�znamy,
 kter� se na obrazovce pouze posunou a zbyl� z�znamy u� bohuzel mus�
 natvrdo vypsat)}
var Buf:pointer;
    Del:integer;
begin
  if Zac1=Zac then                      {pokud nemus�m rolovat, neroluji}
    Exit;

  Posuvnik(false);                      {nejprve sma�eme posuvn�k}

  if Abs(Zac1-Zac)>=Pocet then begin    {pokud to nelze jen odrolovat (je to}
    Zac:=Zac1;                            {p��li� daleko), uprav za��tek}
    VypisSeznam(1,Pocet)                  {a p�ekresli to rovnou}
  end else begin                        {pokud se to pouze posunulo, m��eme}
    Del:=Pocet-Abs(Zac1-Zac);             {vyu��t v�hod rolov�n� :}
    {kolik ��dk� se bude rolovat}
    NewImage(offsety[3],Del*heigthoffont(font),Buf);
    {vytvo��me si pro to prostor}

    if Zac1<Zac then begin              {odrolovalo-li to dol�}
      GetImage(X+1,Y+heigthoffont(font)+1,
               offsety[3],Del*heigthoffont(font),Buf);
      PutImage(X+1,Y+(Zac-Zac1+1)*heigthoffont(font)+1,Buf);
      {posu� obraz}

      Zac:=Zac1;
      {posuneme za��tek na spr�vn� m�sto}
      VypisSeznam(1,Pocet-Del)
      {dopi� ru�n� text}
    end else begin                      {odrolovalo-li to nahoru}
      GetImage(X+1,Y+(zac1-zac+1)*heigthoffont(font)+1,
               offsety[3],Del*heigthoffont(font),Buf);
      PutImage(X+1,Y+heigthoffont(font)+1,Buf);
      {posu� obraz}

      Zac:=Zac1;
      {posuneme za��tek na spr�vn� m�sto}
      VypisSeznam(Del+1,Pocet)
      {dopi� ru�n� text}
    end;

    DisposeImage(Buf)
    {zru��me si p�enosn� buffer a to je v�e}
  end;

  Posuvnik(true)
  {na konci pat�i�n� op�t vykresl�me posuvn�k}
end;

begin
  Inicializace;
  {inicializuje pam�t a obrazovku}
  VypisSeznam(1,Pocet);
  Posuvnik(true);
  {na po��tku vypiseme v�echny polo�ky a vykresl�me posuvn�k}
  repeat
    zvyraznitext(akt-zac+1);
    {zv�razn� aktu�ln� objekt}

    mouseswitchon;
    repeat
      cekejnaudalost;
    until (akce<>2)or(akt<>akt1);
    mouseswitchoff;
    {�ekej na ud�lost tak dlouho, dokud se n�co nestane
     pokud se pouze dostane p��kaz na pohyb na sebe samotn�ho, tak testujeme
     znovu, abychom zbyte�n� neh�bali r�me�kem}

    zruszvyrazneni(akt-zac+1);
    vypistext(akt-zac+1);
    {vr�t�me aktu�ln� objekt do p�vodn�ho stavu,
     ��m� m�me seznam soubor� op�t cel� "�ist�"}

    rolovani;
    {vyvol�me speci�ln� rolovac� proceduru, kter� v p��pad� nutnosti
     odroluje obrazovku s pou�it�m co nejmen��ho po�tu �kon�}

    akt:=akt1;
    {uprav�me si aktu�ln� pozici}

    case akce of
      1:if akt<=m.pocet then if editujmistnost(m,akt) then begin
        zruszvyrazneni(akt-zac+1);
        vypistext(akt-zac+1);
      end;
      3:if pridejmistnost(m) then begin
        vypisseznam(1,pocet);
      end;
      4:if akt<=m.pocet then if smazmistnost(m,akt) then begin
        vypisseznam(1,pocet);
        kontrolujmeze(akt,zac);
      end;
      7:if akt<=m.pocet then viewmistnost(m,akt);
      5:if akt<=m.pocet then editujmasku(m,akt);
      6:if akt<=m.pocet then editujmapu(m,akt);
    end;

  until (akce=0)and(standardnidialog('Chce� opravdu skon�it?',
    dcolor[1],dcolor[2],dcolor[3],dcolor[4],dcolor[5],font,ano_ne)=1);
  {konec na escape}

  Finalizace;
  {uklid� pam�t a obrazovku}
end;

end.
