{Problem: pokud je mapa chuze pres celou obrazovku, i na uplne prvnim
          radku a chci jit bud na prvni, nebo z prniho opet na prvni,
          bud: to dojde spravne
          nebo: to nikam nedojde a zustane stat
          anebo: se to zblbne, co vim, tak u ObliqueRoad
 Duvod: buh vi...
 Reseni: mapa chuze na prvnim radku je extremni situace a ve skutecnosti
         takova mapa nikde nebude}
{pavel: chyba: drak nejde, kdyz se klikne na posledni radek
               drak nechodi presne, ale o neco nahoru
        duvod: nekde u VAS! Mapa, uz kdyz ji ja dostanu, je
               posunuta o bod vlevo a o radek nahoru, tudiz
               chodi o radek vys, nez by se vam zdalo a na poslednim
               radku jsou nahodna data, takze to tam hapruje!
        oprava: POMOZTE SI SAMI, to bude asi nekde u nacitani mapy
                nebo kompilace!}

{pridal jsem pomennou typu proc. "OnDestination" (=na cili),
 ktera je volana pote, co drak dojde na misto.
 Je volana pouze z proc. GoBeforeFinal, ktera spousti animaci
 stani na miste. Vyvola se po spusteni sekvence stani na miste.
 OnDestination je hned na zacatku bloku "var" interface tohoto unitu
 Pri provadeni programku pri prihlasovani unitu (begin end uplne
 na konci unitu) se priradi do OnDestination hodnota FreeUserProc}

{Pridal jsem dve nasledujici kraticke funkce; kdyby se ti nehodil
 trebas typ boolean, ale chtel to v bytech, snad si to prepises...
function AskSeqPhase(SeqNum: byte): byte;
function AskSeqInProcess(SeqNum: byte): boolean;
}

{Pokud chces neco delat, prave, kdyz skonci urcita sekvence, neni
nic snazsiho, nez vyplnit polozku UserProc v Seq_ExtHead... te
sekvence. UserProc se vykona, prave kdyz se sekvence ukonci.
Cili je jasne, ze se to nejde pouzit u sekvence cyklicke, ktera se
nikdy neukonci...}

{ $define ladeni}
unit anmplay4; {tato verze obsahuje i procedurky na chuzi z byvaleho unitu go}

interface

uses dma, bardfw, vars, graph256, midi01, animace4{, pl_memor};




  function  PhaseSeq(SeqNum: byte): byte;{sdeli nam v jake fazi je sekvence}
  function  IsSeqInProcess(SeqNum: byte): boolean;{sdeli nam, jestli sekvence probiha}
  procedure InitFirstPhase(SeqNum: byte); {Init sekvence na zacatku screenu}
  procedure StartPhase(SeqNum: byte);  {Spusteni sekvence}
  procedure NextPhase(SeqNum: byte); {Prechod na dalsi fazi}
  procedure UpdatePhase(SeqNum: byte);
  procedure Body;
  procedure BodyWait;
  function  LoadAnimationSeq(Item: word): word;
  procedure ReleaseLastAnimationSeq;

  procedure InitHero(HeroX, HeroY: integer);{inicializace hrdiny}
  procedure DisposeMap(var map : pointer);
  procedure InitWay(x1, y1, x2, y2: integer);
  procedure GoAfterCurve;
  procedure GoBeforeFinal;
  procedure GoByWay;

implementation
const
  A_HeroContinue: boolean= False; {takova pekna promenna. Pote, co se zavola
                     UserProc, testuje se tato promenna. Pokud True, nevyskoci
                     se z NextPhase a faze pokracuje. O nastaveni tehle promenne
                     se musi postarat prave UserProc. NextPhase si ji bezprostredne
                     po otestovani nastavi opet na False}
var
{v nasledujich polich jsou ulozeny ty adresy, jak je nize popsano. Vicemene
 je to takhle reseno proto, aby v pameti nebylo nic zbytecnyho (samozrejme
 prave krome tech poli...)
 Jak to bude fungovat:
 Adresa kazdyho obrazku, samplu, co je natrvalo v pameti se ulozi do tohoto
 pole. Kdyz se budou nacitat dalsi natrvalo v pameti ulozene sekvence, pri
 nacitani se overi, jsetli uz obr. v pameti neni. Jestli ne, nahraje se;
 jestlize uz tam je, jenom se priradi adresa- vice viz. LoadAnimationSeq...}
  Sprites: array[1..A_MaxSprites] of pointer;
  {pole adres sprajtu pouzitych v sekvencich, co jsou cele psany nastalo pro pamet}
  StoreSprNum: array[1..A_MaxSprites] of word;
  {pole skladovych cisel sprajtu pouzitych v sekvencich, co jsou cele psany nastalo pro pamet}
  SpritesUses: array[1..A_MaxSprites] of byte;
  {ke kazdemu ulozenemu sprajtu je zde, kolikrat je pouzit. Pri odinstalovani se toto
   stale zmensuje, a az dojde k 0, teprve se odinstaluje}
  Samples: array[1..A_MaxSamples] of pointer;
  {pole adres samplu pouzitych v sekvencich, co jsou cele psany nastalo pro pamet}
  StoreSamNum: array[1..A_MaxSamples] of word;
  {pole sklad. cisel  samplu pouzitych v sekvencich, co jsou cele psany nastalo pro pamet}
  SamplesUses: array[1..A_MaxSprites] of byte;
  {ke kazdemu ulozenemu samplu je zde, kolikrat je pouzit. Pri odinstalovani se toto
   stale zmensuje, a az dojde k 0, teprve se odinstaluje}
  SamSizs: array[1..A_MaxSamples] of word;
  {pole delek samplu pouzitych v sekvencich, co jsou cele psany nastalo pro pamet}

{old}
{  NextPhaseSound: TOneChannel;}
  {hodnoty, ktere se zapisou do promennych 0-teho kanalu po prehozeni stranek}


{xxx{
{procedure InitLocalVariables;
begin
  ANMPath:= Anim^.DFW;
  SamPath:= Samply^.DFW;
  PictPath:= Obrazky^.DFW;
end;}

function PhaseSeq(SeqNum: byte): byte;
begin
   PhaseSeq:= A_SeqExtHead[SeqNum]^.ActPhase;
end;

function IsSeqInProcess(SeqNum: byte): boolean;
begin
   IsSeqInProcess:= (SeqNum>0)and(A_SeqExtHead[SeqNum]^.InProcess=1);
end;

procedure InitFirstPhase(SeqNum: byte);
{Na zacatku screebu se musi kazda sekvence nejdriv takto inicializovat}
{Hlavne: predpoklada, ze anim. objekt neni viditelny, tedy zviditelni ho}
{Nastavi to: obrazek, sampl, velikots, souradnice- aby se obrazovka
 mohla hned na zacatku vykreslit}
begin
  with A_SeqExtHead[SeqNum]^ do begin
    if InProcess= 0 then Exit;
    {Pokud neni aktivni, samozrejme se neinicializuje}
    {Inicializovat se musi tesne pred tim, nez chceme, aby byla aktivni}
{    CountDelay:= Time08^.TimerBody- 1000;}
{toto se udelalo jiz v start phase}
    ActPhase:= 0{bob:1};
    with A_Sequences[SeqNum]^.Phase[1] do begin
      if Picture> 0 then begin
        {pokud je rozumne cislo obrazku, zmenim sprajt, a to nasledovne:}
        if A_Sequences[SeqNum]^.Header.MemoryLogic= 0 then begin
           {pokud je sekvence typu "pamet" jenom dam novou adresu}
           AddSpriteToObj(AnimObj, Sprites[Picture]);
        end else begin
          {jinak nactu sprajt do vyhrazeneho mista}
          CReadItem(PictPath, A_SeqExtHead[SeqNum]^.BigPict, Picture);
          AddSpriteToObj(AnimObj, A_SeqExtHead[SeqNum]^.BigPict);
        end;
        VisibleAObj(AnimObj);
        {predpoklada to, ze je neviditelny - prioritu u sebe ma jakoukoliv,
         prioritu v tabulce ma NULU}
      end;
      if A_Sequences[SeqNum]^.Header.Relative= 0 then begin
        StartPosAObj(AnimObj, X, Y);
      {Pokud ma objekt absolutni souradnice, placne to na ne}
      end else if MainHero> 0 then begin
        {Pokud jde o hrdinu, provede se takto:}
        StartPosAObj(AnimObj,
          H_.FeetX-
          {H_.FeetX je vprostred, takze od ni odecteme pulku aktualni sirky draka}
            round(
            (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
            {toto je faktor zvetseni pro radek, kde drak stoji}
            (PWordArray(Sprites[Picture])^[0] / 2)
            {faktorem vynasobime originalni sirku sprajtu a dostaneme}
            {sirku draka na souradnicich, kde je}
            ),
          H_.FeetY-
          {Protoze H_.FeetY je spodek nohou, souradnice hlavy budou nad}
          {nim, cili odecitame - aktualni vysku draka- ale ted jak:}
            round(
            (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
            {toto je faktor zvetseni pro radek, kde drak stoji}
            PWordArray(Sprites[Picture])^[1]
            {faktorem vynasobime originalni vysku sprajtu a dostaneme}
            {vysku draka na souradnicich, kde je}
            )
          );
       {Ted by mel stat tam, kde ma}
      {Pokud jsou souradnice jenom obycejne relativni, musi se uz predem
       zadat pomoci NewPos...}
      end;
      if MainHero> 0 then begin
        NewPriorityAObj(AnimObj, H_.FeetY+1);
        {NewPriority nastavi jak prioritu u objektu, tak prioritu do
         tabulky, coz nyni muzu provest, protoze objekt uz byl zviditelneny}
        {Hrdina je velky podle perspektivy}
        ZoomX:= round(  (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
          PWordArray(Sprites[Picture])^[0] );
        ZoomY:= round(  (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
          PWordArray(Sprites[Picture])^[1] );
      end;
      NewZoomAObj(AnimObj, ZoomX, ZoomY);
      NewMirrorAObj(AnimObj, Mirror);
    end;
    StartDisableErasingAObj(AnimObj, A_Sequences[SeqNum]^.Header.DisableErasing);
  end; {with A_SeqExtHead[SeqNum] }
end;

procedure UpdatePhase(SeqNum: byte);
{volam zatim pouze pri loadu. Muze se stat, zejm. u draka (nikde jinde
 to neni prakticky mozne), ze prave menim smer chuze a menim ho prikazem
 StartPhase. Tento prikaz nastavi ActPhase na 0. Pokud jeste pri tomtez
 pruchodu Body nedojde k inicializovani ActPhase spustene sekvence z 0 na 1
 (k inicializovani nedojde tehdy, kdyz menim sekvenci s vyssim porad.
 cislem na sekvenci s nizsim porad. cislem), dojde k nemu az pri pruchodu
 dalsim. Mezi tim ale muze dojit k sejvnuti->sejvne se ActPhase:= 0.
 Aby pri loudnuti rutinka UpdatePhase nehodila nesmyslnou adresu obrazku
 otestuju to tak, jak to testuju...}
{potom tam ale muze byt mala esteticka nehoraznost: drak se neobjevi na
 obrazovce hned, ale az hned pri prvnim pruchodem Body. Cili prakticky
 hned, ale presto to bude trosku videt.
 NEBUDEME to povazovat za chybu, a vyfakujeme se ne to.}
begin
  {nejdrive upravim aktualni fazi- ono se totiz muze stat, ze je nastavena
   na 0 (kdyz animaci startuju), a pokud dam update sprite aktualni faze
   0, tak...}
  if A_SeqExtHead[SeqNum]^.ActPhase>0 then
  with A_Sequences[SeqNum]^.Phase[A_SeqExtHead[SeqNum]^.ActPhase] do begin
    {pracuji se zaznamem aktualni faze}
    if Picture> 0 then begin
      {pokud je rozumne cislo obrazku, zmenim sprajt, a to nasledovne:}
      if A_Sequences[SeqNum]^.Header.MemoryLogic= 0 then
        AddSpriteToObj(A_SeqExtHead[SeqNum]^.AnimObj, Sprites[Picture])
         {Kdyz je typu "memory", jenom hodim z pamete adresu dalsiho sprajtu}
      else begin{jinak ale obslouzim typ "memory/disk"}
        CReadItem(PictPath, A_SeqExtHead[SeqNum]^.BigPict, Picture);
        AddSpriteToObj(A_SeqExtHead[SeqNum]^.AnimObj, A_SeqExtHead[SeqNum]^.BigPict);
      end;
      VisibleAObj(A_SeqExtHead[SeqNum]^.AnimObj);
    end;

  end;
end;

procedure StartPhase(SeqNum: byte);
{Spusteni sekvence}
{Predpoklada, ze anim. objekt je jiz viditelny, nezviditelni ho}
{Pouze nastavi, ze bezime, nastavi spravne zdrzeni, spravnou fazi}
begin
  with A_SeqExtHead[SeqNum]^ do begin
    StartDisableErasingAObj(AnimObj, A_Sequences[SeqNum]^.Header.DisableErasing);
    {Do jednoho objektu se muze promitat stridave vic sekvenci, takze to nastavim
     u objektu znovu podle hlavicky sekvence}
    InProcess:= 1; {nyni je aktivni}
    CountDelay:= TimerBody- A_Sequences[SeqNum]^.Phase[1].Delay -1;
    ActPhase:= 0;
    {aby to hned pri prvnim volani NextPhase preslo na fazi 1}
  end;
end;

procedure NextPhase(SeqNum: byte);
var
  _FeetX, _FeetY: integer;
begin
  with A_SeqExtHead[SeqNum]^ do begin
    if InProcess= 0 then Exit;
    {Pokud animacni sekvence neni aktivni, nepracuje se s ni}
    if(ActPhase=0)or((TimerBody- CountDelay)>= A_Sequences[SeqNum]^.Phase[ActPhase].Delay)
    or((MainHero>0)and(G_EnableQuickHero)and(G_QuickHero)and(SeqNum<Ord(MluvPravo)))
    then begin
      {OK, uz muzeme prejit na dalsi fazi}
      CountDelay:= TimerBody;
      {Nastavime cas, kdy jsme presli na dalsi fazi, kvuli testovani Delay}
      if(MainHero>0)and(A_Sequences[SeqNum]^.Header.Cyclic= 1)and
      {V pripade, ze jde o cyklickou animaci hlavniho hrdiny, overim,
      jestli se uz hrdina nenachazi v predepsanem miste}
      ( (H_.WalkSide=0)and(H_.FeetY< (H_.FinalY+
         ( (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*2)    )
          )or
        (H_.WalkSide=1)and(H_.FeetY>(H_.FinalY-
         ( (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*2) )
          )or
        (H_.WalkSide=2)and(H_.FeetX> (H_.FinalX-
         ( (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*5) )
          )or
        (H_.WalkSide=3)and(H_.FeetX< (H_.FinalX+
         ( (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*5) )
      ) )then begin
      {zjistili jsme, ze hrdina je tam, kde mel byt...}
      {ty cisla, ktere nasobim faktorem perspektivy, jsou
       o neco mensi nez prumerne X a Y relat. souradnice u animace draka}

  {          InProcess:= 0;}
  {Nebudu to vypinat, to si obslouzi procedurka nad nami...}
        H_.FeetX:= H_.FinalX;
        H_.FeetY:= H_.FinalY;
        UserProc;
        if not A_HeroContinue then Exit;
        {pokud nebyl vydan prikaz, aby i dale pokracovala, skoncili jsme}
        A_HeroContinue:= False;
        {Pristi animace zacina opet s timto indikatorem na False.
         Pokud chce byt True, cili pokud se chce, aby i po zavolani
         UserProc animace pokracovala, musi si tento indikator nastavit
         na True prave UserProc.}
      end;

      if ActPhase= A_Sequences[SeqNum]^.Header.NumOfPhases then begin
      {obslouzim, kdyz jsme na konci sekvence}
        if A_Sequences[SeqNum]^.Header.Cyclic= 1 then begin
          ActPhase:= 1;
          {pokud je cyklicka, zacnu znovu od zacatku}
        end else begin
          InProcess:= 0;
          {vypne se, aby sem porad zbytecne neskakala}
{          UnvisibleAObj(AnimObj);}
          A_ActSeq:= SeqNum;
          UserProc;
          Exit;
          {pokud neni cyklicka, skoncili jsme}
        end;
      end else begin
        Inc(ActPhase);
        {pokud nejsme na konci, prejdu na dalsi fazi}
      end;

      with A_Sequences[SeqNum]^.Phase[ActPhase] do begin
        {pracuji se zaznamem aktualni faze}
        if Picture> 0 then begin
          {pokud je rozumne cislo obrazku, zmenim sprajt, a to nasledovne:}
          if A_Sequences[SeqNum]^.Header.MemoryLogic= 0 then begin
             AddSpriteToObj(AnimObj, Sprites[Picture]);
             {Kdyz je typu "memory", jenom hodim z pamete adresu dalsiho sprajtu}
          end else begin
            {jinak ale obslouzim typ "memory/disk"}
            CReadItem(PictPath, BigPict, Picture);
            AddSpriteToObj(AnimObj, BigPict);
            {nacetl jsem sprajt do vyhrazeneho mista}
          end;
          RepaintAObj(AnimObj);
          {zmenil se sprajt, vydam prikaz k prekresleni animacniho objektu}
        end;
        if Sample> 0 then begin
         PlayDMAString(sample,13000,false);
        end;
        if A_Sequences[SeqNum]^.Header.Relative= 0 then begin
          NewPosAObj(AnimObj, X, Y);
          {Pokud jsou absolutni souradnice, neci co resit,}
          {ale co kdyz jsou relativni: ?}
        end else if MainHero> 0 then begin
          {Pokud jsou relativni a jedna se o animaci hlavniho hrdiny,
           pracujeme s H_.Feet.. , kde jsou ulozeny jeho souradnice}
          begin
            _FeetX:= round( (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*X*H_.XStrOblRatio);
            {Ve _FeetX je velikost relat. kroku nasobena faktory perspektivy
             a zesikmeni}
            if(H_.XOblStep=0)then H_.FeetX:= H_.FeetX+ _FeetX
            {Pokud je "hlavni smer" v ose X, jenom prictu relat. krok
             k dosavadni souradnici}
            else H_.FeetX:= H_.StartX+ _FeetX+ round(H_.XOblStep*Abs(H_.FeetY- H_.StartY));
            {Jinak se podivam, kolik bodu jsme uz usli od zacatku tohoto useku
             a tuto delkou vynasobim poctem bodu v teto ose pripadajicim na jeden
             bod useku v "hlavnim smeru"}

            _FeetY:= round( (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*Y*H_.YStrOblRatio);
            if(H_.YOblStep=0)then H_.FeetY:= H_.FeetY+ _FeetY
            else H_.FeetY:= H_.StartY+ _FeetY+ round(H_.YOblStep*Abs(H_.FeetX- H_.StartX));
            {tady jsme dostali nove souradnice nohou}
            {a zadame podle nich souradnice leveho horniho rohu draka}
            NewPosAObj(AnimObj,
              H_.FeetX-
              {H_.FeetX je vprostred, takze k ni pricteme pulku aktualni sirky draka}
                round(
                (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
                {toto je faktor zvetseni pro radek, kde drak stoji}
                (PWordArray(Sprites[Picture])^[0] / 2)
                {faktorem vynasobime originalni vysku sprajtu a dostaneme}
                {vysku draka na souradnicich, kde je}
                ),
              H_.FeetY-
              {Protoze H_.FeetY je spodek nohou, souradnice hlavy budou nad}
              {nim, cili odecitame - aktualni vysku draka- ale ted jak:}
                round(
                (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
                {toto je faktor zvetseni pro radek, kde drak stoji}
                PWordArray(Sprites[Picture])^[1]
                {faktorem vynasobime originalni vysku sprajtu a dostaneme}
                {vysku draka na souradnicich, kde je}
                )
              );
           {Ted by mel stat tam, kde ma}
          end;
          {A pokud jsou definovany kecajici postavicky, podle souradnic draka}
          {uoravim i souradnice jeho bubliny}
          if G_Hd.PerNum>0 then begin
            G_Persons^[1].X:= H_.FeetX;
            G_Persons^[1].Y:= H_.FeetY-round((R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
                      PWordArray(Sprites[Picture])^[1]);
          end;
        end else begin
          {A pokud jsou souradnice jenom obycejne relativni, jednoduse
           se prictou rozdily X, Y}
          NewPosAObj(AnimObj,
            X+GetNewXAObj(AnimObj),
            Y+GetNewYAObj(AnimObj));
        end;
        if MainHero> 0 then begin
          NewPriorityAObj(AnimObj, H_.FeetY+1);
          {Hlavni hrdina se zmensuje podle perspektivy}
          ZoomX:= round(  (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
            PWordArray(Sprites[Picture])^[0] );
          ZoomY:= round(  (R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*
            PWordArray(Sprites[Picture])^[1] );
        end;
        NewZoomAObj(AnimObj, ZoomX, ZoomY);
        NewMirrorAObj(AnimObj, Mirror);
      end;
    end;
  end; {with A_SeqExtHead[SeqNum]^}
end;

procedure Body;
{toto je jakesi "telo", ktere je volano vzdy po urcitem case(nyni 1/10 sec),
 a ktere samo vola vsechno, co je potreba k prechodu na dalsi fazi a
 prehozeni stranek}
var
  f: byte;
begin
  TimerBody:= TimerDW;
  for f:= 1 to A_LastAnmSeq do begin
    NextPhase(f);
  end;
  {projel jsem vsechny sekvence}
{}  WaitDisplay; {nen� p�ehozena str�nka}
  SmartPutAObjs;
  {placnu to do neviditelne stranky}
{readkey;}
  WaitVRetrace;
  SwapAnimPages;
  {ted prepnu stranky}
{}  WaitDisplay; {nen� p�ehozena str�nka}
{readkey;}

  if(A_NextPhaseNewSound=1) then begin
    {pokud mam nastavit zvuk, nastavim ho}
    A_NextPhaseNewSound:= 0;
{old}
(*    Sound_Channels^.i[0].ChSeg:=   0;
    {behem nastavovani radeji vypneme kanal s efekty}
    Sound_Channels^.i[0].ChVolume:= NextPhaseSound.ChVolume;
    Sound_Channels^.i[0].SizeCh:= NextPhaseSound.SizeCh;
    Sound_Channels^.i[0].ChLoop:= NextPhaseSound.ChLoop;
    Sound_Channels^.i[0].ChLooped:= NextPhaseSound.ChLooped;
    Sound_Channels^.i[0].ChLenLp:= NextPhaseSound.ChLenLp;
    Sound_Channels^.i[0].Krok:=  NextPhaseSound.Krok;
    Sound_Channels^.i[0].OvrLd:= NextPhaseSound.OvrLd;
    Sound_Channels^.i[0].ChOfs:= NextPhaseSound.ChOfs;
    Sound_Channels^.i[0].ChActPos:= NextPhaseSound.ChActPos;
    Sound_Channels^.i[0].ChSeg:=   NextPhaseSound.ChSeg;*)
    {az teprve ted muzu naladovat hodnoty primo do promennych 0. kanalu,}
    {aby to zaclo hrat zaroven s prepnutim faze}
  end;
{old}
(*  G_SumLoopTimes:= G_SumLoopTimes+ Time08^.TimerWord1;*)
  Inc(G_SumLoopPasses);
  {Tady prubezne pocitam, jak dlouho mi trva nakresleni jedne faze}
end;

procedure BodyWait;
begin
{old}
(* if (Time08^.TimerWord1 )<= G_ShortestAnimDelay then begin
   repeat until (Time08^.TimerWord1 = G_ShortestAnimDelay);
 end; { Pavle, proc to nemuze byt v proc. BODY?}
 {No to nevim. Pavel.}
 Time08^.TimerWord1:= 0;*)
end;

function LoadAnimationSeq(Item: word): word;
{natahne do pameti animacni sekvenci}
var
  f, g, h: byte;
  BigSize, ActSize: word;
  SeqNum: byte;
begin

  Inc(A_LastAnmSeq);
  SeqNum:= A_LastAnmSeq;
  CLoadItem(ANMPath, pointer(A_Sequences[SeqNum]), Item);
  GetMem(A_SeqExtHead[SeqNum], SizeOf(TAnmExtHeader));
  A_SeqExtHead[SeqNum]^.InProcess:= 0;
  A_SeqExtHead[SeqNum]^.MainHero:= 0;

  if A_Sequences[SeqNum]^.Header.MemoryLogic=0 then begin
    {vsechny obrazky v pameti}
    for h:= 1 to A_Sequences[SeqNum]^.Header.NumOfPhases do with A_Sequences[SeqNum]^.Phase[h] do begin
      {projdu vsechny faze}
      if Picture>0 then begin
        {v uvahu beru jenom platne cislo obrazku, kdyz je neplatne, fazi ignoruji}
        g:= 1;
        while(Picture<> StoreSprNum[g])and(g<=A_LastLoadedPicture) do Inc(g);
        {proberu uz nactene obrazky, jestli mezi nimi tento neni}
        if(g> A_LastLoadedPicture)or(g= A_LastLoadedPicture)and(Picture<> StoreSprNum[g])then begin
          {nactu obrazek, jeste v pameti neni}
          Inc(A_LastLoadedPicture);
          CLoadItem(PictPath, Sprites[A_LastLoadedPicture], Picture);
          {nacetl jsem sprajt}
          StoreSprNum[A_LastLoadedPicture]:= Picture;
          Picture:= A_LastLoadedPicture;
          SpritesUses[A_LastLoadedPicture]:= 1;
          {pocet pouziti obrazku nastavim zatim na 1}
        end else begin
          Picture:= g;
          {obrazek uz v pameti je, jenom zapisu jeho cislo}
          Inc(SpritesUses[g]);
          {a zvysim pocet pouziti obrazku}
        end;

      end else Picture:= 0;
    end;
(*    for h:= 1 to A_Sequences[SeqNum]^.Header.NumOfPhases do with A_Sequences[SeqNum]^.Phase[h] do begin
      {projdu vsechny faze}
      if Sample>0 then begin

        g:= 1;
        while(Sample<> StoreSamNum[g])and(g<=A_LastLoadedSample) do Inc(g);
        {proberu uz nactene samply, jestli mezi nimi tento neni}
        if(g> A_LastLoadedSample)or(g= A_LastLoadedSample)and(Sample<> StoreSamNum[g])then begin

          {nactu sampl, jeste v pameti neni}
          Inc(A_LastLoadedSample);
          CLoadItem(SamPath, Samples[A_LastLoadedSample], Sample);
          {nacetl jsem sampl}
          SamSizs[A_LastLoadedSample]:= UnpackedItemSize(SamPath, Sample);
          StoreSamNum[A_LastLoadedSample]:= Sample;
          Sample:= A_LastLoadedSample;
          SamplesUses[A_LastLoadedSample]:= 1;
          {pocet pouziti samplu nastavim zatim na 1}
        end else begin
          Sample:= g;
          {sampl uz v pameti je, jenom zapisu jeho cislo}
          Inc(SamplesUses[g]);
          {a zvysim pocet pouziti samplu}
        end;
      end else begin
        Sample:= 0;
      end;
    end;*)

  end else begin
    {kdyz to pouze v pameti vyhradi misto a taha to do neho}
    BigSize:= 0;
    for f:= 1 to A_Sequences[SeqNum]^.Header.NumOfPhases do with A_Sequences[SeqNum]^.Phase[f] do begin
      if Picture>0 then begin
        g:= 0;
        repeat Inc(g) until Picture=A_Sequences[SeqNum]^.Phase[g].Picture;
        if g=f then begin
          ActSize:= UnpackedItemSize(PictPath, Picture);
          if ActSize>BigSize then BigSize:= ActSize;
        end;
      end else Picture:= 0;
    end;
    A_SeqExtHead[SeqNum]^.BigPictSize:= BigSize;
    GetMem(A_SeqExtHead[SeqNum]^.BigPict, A_SeqExtHead[SeqNum]^.BigPictSize);
(*copak tim chtel asi autor rict? tim autorem jsem byl ja sam a stydim se
  za to !!!! *)
(*    BiggestPict:= 0;
    for f:= 1 to A_Sequences[SeqNum]^.Header.NumOfPhases do with A_Sequences[SeqNum]^.Phase[f] do begin
      if Picture>0 then begin
        g:= 0;
        repeat Inc(g) until Picture=A_Sequences[SeqNum]^.Phase[g].Picture;
        if g=f then if UnpackedItemSize(PictPath, Picture)>BiggestPict then
          BiggestPict:= Picture;
      end else Picture:= 0;
    end;
    if BiggestPict>0 then A_SeqExtHead[SeqNum]^.BigPictSize:= UnpackedItemSize(PictPath, BiggestPict)
    else A_SeqExtHead[SeqNum]^.BigPictSize:= 0;
    GetMem(A_SeqExtHead[SeqNum]^.BigPict, A_SeqExtHead[SeqNum]^.BigPictSize);*)
(*    BigSize:= 0;
    for f:= 1 to A_Sequences[SeqNum]^.Header.NumOfPhases do with A_Sequences[SeqNum]^.Phase[f] do begin
      if Sample>0 then begin
        g:= 0;
        repeat Inc(g) until Sample=A_Sequences[SeqNum]^.Phase[g].Sample;
        if g=f then begin
          ActSize:= UnpackedItemSize(SamPath, Sample);
          if ActSize>BigSize then BigSize:= ActSize;
        end;
      end else Sample:= 0;
    end;
    A_SeqExtHead[SeqNum]^.BigSamSize:= BigSize;
    GetMem(A_SeqExtHead[SeqNum]^.BigSam, A_SeqExtHead[SeqNum]^.BigSamSize);
    {alokuju pamet pro nejvetsi ze vsech sprajtu}
    {nacetl jsem sprajt}*)
  end;
  LoadAnimationSeq:= A_LastAnmSeq;
end;

procedure ReleaseLastAnimationSeq;
var
  f, g, h: byte;
  BiggestPict, BiggestSam: word;
begin
{Zneviditelnim objekt- nemuzu tim nic pokazit, leda tak vylepsit...}
{Ale, ale- muzu pokazit, ovsem ted uz snad ne:}
  if A_SeqExtHead[A_LastAnmSeq]^.InProcess=1 then
    UnvisibleAObj(A_SeqExtHead[A_LastAnmSeq]^.AnimObj);

  if A_Sequences[A_LastAnmSeq]^.Header.MemoryLogic=0 then begin
    {vsechny obrazky v pameti}
    for h:= A_Sequences[A_LastAnmSeq]^.Header.NumOfPhases downto 1 do
    with A_Sequences[A_LastAnmSeq]^.Phase[h] do begin
      {projdu vsechny faze}
      if Picture>0 then begin
        {v uvahu beru jenom platne cislo obrazku, kdyz je neplatne, fazi ignoruji}
        Dec(SpritesUses[Picture]);
        if (SpritesUses[Picture])= 0 then begin
          StoreSprNum[Picture]:= 0;
          DisposeImage(Sprites[Picture]);
          Dec(A_LastLoadedPicture);
        end;
      end;
    end;
(*    for h:= 1 to A_Sequences[A_LastAnmSeq]^.Header.NumOfPhases do with A_Sequences[A_LastAnmSeq]^.Phase[h] do begin
      {projdu vsechny faze}
      if Sample>0 then begin
        Dec(SamplesUses[Sample]);
        if (SamplesUses[Sample])= 0 then begin
          StoreSamNum[Picture]:= 0;
          FreeMem(Samples[Sample], SamSizs[Sample]);
          Dec(A_LastLoadedSample);
        end;
      end;
    end;*)

  end else with A_SeqExtHead[A_LastAnmSeq]^ do begin
    {kdyz to pouze v pameti vyhradi misto a taha to do neho}
    if BigPictSize>0 then FreeMem(BigPict, BigPictSize);
    {alokuju pamet pro nejvetsi ze vsech sprajtu}
(*    if BigSamSize>0 then FreeMem(BigSam, BigSamSize);*)
    {alokuju pamet pro nejvetsi ze vsech sprajtu}
    {nacetl jsem sprajt}
  end;
  FreeMem(A_Sequences[A_LastAnmSeq],
    SizeOf(TAnmPhase)*A_Sequences[A_LastAnmSeq]^.Header.NumOfPhases+SizeOf(TAnmHeader));
  FreeMem(A_SeqExtHead[A_LastAnmSeq], SizeOf(TAnmExtHeader));
  Dec(A_LastAnmSeq);
end;



(*******************************************************************)

(*                       GO                                        *)

(*******************************************************************)

const
  delta= 4; {roztec mapy u chuze}

procedure InitHero(HeroX, HeroY: integer);
{inicializuje vnitrni promenne hrdiny tak, aby stal na miste}
begin
  H_.OnDest:= Do_Nothing;

  H_.FeetX:= HeroX;
  H_.FeetY:= HeroY;

  H_.FinalX:= H_.FeetX;
  H_.FinalY:= H_.FeetY;
  H_.StartX:= H_.FeetX;
  H_.StartY:= H_.FeetY;

  H_.XOblStep:= 0;
  H_.YOblStep:= 0;
  H_.XStrOblRatio:= 1;
  H_.YStrOblRatio:= 1;
  H_.WalkSide:=255;

  if G_Hd.PerNum>0 then begin
   G_Persons^[1].X:= H_.FeetX;
{!!! dana napevno sirka draka= 50!!}
   G_Persons^[1].Y:= H_.FeetY-round((R_Hd.Persp0+ H_.FeetY*R_Hd.PerspStep)*50);
  end;
end;

procedure DisposeMap(var map : pointer);
{Uvolni mapu z pameti, NO COMMENT}
begin
  FreeMem(map,PWordArray(map)^[6]*PWordArray(map)^[5]+14)
end;

function  GetPixelMap(X,Y : word;map:pbytearray):boolean; assembler;
{lezou do toho souradnice uz vydeleny deltou mapy}
asm
  push ds
  lds bx, map         {pavel: existuje takova hezka instrunkce na naladovani
                       ofsetu aji segmentu!}
  mov ax,ds:[bx+12]   {sirka 1 zaznamu}
  mul y               {vynasobit cislem radku, mame offset zacatku radku}
  add bx,14           {preskoceni hlavicky}
  add bx,ax           {najdeme pozici kliknuteho bodu}

  mov ax,x            {vezmeme pozici x}
  mov cl,al
  and cl,7            {vypocet x modulo 8 pro urceni cisla bitu}
  shr ax,3
  add bx,ax           {pricteme vyDIVenou 8 k offsetu}

  mov al,1
  shl al,cl

  and al,byte ptr ds:[bx]    {vyANDovani daneho bitu podle obsahu pameti}
  jz  @nulove                {0..nic se nedeje, konec, vysl je v al=0}
  mov al,1                   {else..konec, ve vysledku v al=1}
@nulove:
  pop ds                     {obnovime registry ds, konec}
end;

procedure PutPixelMap(X,Y:integer;co:boolean;map:pbytearray); assembler;
{predpokl. se x=<1..rx> stejne tak y a procedura si sama odecte 1}
asm
  push ds                    {vypocet indexu map^}
  lds bx, map
  mov ax,ds:[bx+12]   {sirka 1 zaznamu}
  mul y               {vynasobit cislem radku, mame offset zacatku radku}
  add bx,14           {preskoceni hlavicky}
  add bx,ax           {presuneme se na tento zacatek radku}

  mov ax,x            {vezmeme pozici x}
  mov cl,al
  and cl,7            {vypocet x modulo 8 pro urceni cisla bitu}
  shr ax,3
  add bx,ax           {pricteme vyDIVenou 8 k offsetu}

  mov al,1
  shl al,cl
  mov cl,byte ptr ds:[bx] {nacteni zadaneho bajtu}

  cmp co,0
  je  @nulovat
  or cl,al                   {nastavovani bitu}
  jmp @zapis
@nulovat:
  not al                     {nulovani bitu}
  and cl,al
@zapis:
  mov byte ptr ds:[bx],cl    {vraceni zpet}
@konec:
  pop ds
end;


procedure AdjustXYByCircle (var x_stred, y_stred: integer; barva:byte);
  var
    f: byte;
    polomer: word;
    predikce, dx, dy, x, y: integer;
    TestX, TestY: integer;

  function TestXYOnScr: boolean;
  begin
    TestXYOnScr:= false;
    if TestX> 319 then exit;
    if TestX< 0 then exit;
    if TestY> 199 then exit;
    if TestY< 0 then exit;
    TestXYOnScr:= true;
  end;

  procedure xoruj_symetricke_body;
    begin
      TestX:= x_stred + x;
      TestY:= y_stred + y;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
      if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
      if x<>0 then begin
        TestX:= x_stred - x;
        TestY:= y_stred + y;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
        if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
      end;
      if y<>0 then begin
        TestX:= x_stred + x;
        TestY:= y_stred - y;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
        if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
        if x<>0 then begin
          TestX:= x_stred - x;
          TestY:= y_stred - y;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
          if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
        end;
      end;
      if (x=y)then exit;
      TestX:= x_stred + y;
      TestY:= y_stred + x;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
      if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
      if y<>0 then begin
        TestX:= x_stred - y;
        TestY:= y_stred + x;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
        if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
      end;
      if x<>0 then begin
        TestX:= x_stred + y;
        TestY:= y_stred - x;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
        if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
        if y<>0 then begin
          TestX:= x_stred - y;
          TestY:= y_stred - x;
{if TestXYOnScr then XorPixel (TestX, TestY, barva);}
          if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then exit;
        end;
      end;
      {aby se to 2* nexorovalo}
    end; {kresli_symetrick�_body}

  begin {Kru�nice}
    polomer:= 0;
    repeat
      Inc(polomer, delta);
      x := 0;
      y := polomer;
      predikce := 1 - polomer;
      dx := 3;
      dy := 2*polomer - 2;
      repeat
        xoruj_symetricke_body;
        if TestXYOnScr and GetPixelMap(TestX div delta,TestY div delta,R_WalkMap) then begin
          x_stred:= TestX;
          y_stred:= TestY;
          exit;
        end;

        if predikce >= 0
          then { pokles sou�adnice y }
            begin
              predikce := predikce - dy;
              dy := dy - 2*delta;
              y := y - delta;
            end;
          predikce := predikce + dx;
          dx := dx + 2*delta;
          x := x + delta;
      until x > y;
    until False;
  end; {Kru�nice}



procedure FindRoad(x1, y1, x2, y2 : integer; vysl: ppole);
type
  pbuf=^tbuf;
  tbuf=array[0..200*4-1]of record
    x,y:integer;
    smer:byte
    {dodelal jsem tam ten test smeru- Robertova poznamka, ja k tomu
     nemuzu nic dodat. Pavel}
   end;
   {nacpak asi muze byt tohle? no ano, je to preci buffer (jakysi)}
   PResult= ^TResult;
   TResult= array[1..10000] of record
     x,y,min:integer
   end;
   {do teto datove struktury to bude pro sebe ukladat cestu, kudy jit}

var
  BufferMap: pointer;
  {do tohlenctoho bafru si bude znacit prohledavani mapy- nepocmara si
   prece samotnou mapu!}
  Buf:pbuf;
  {kruhovy buffer o rozmeru 2*mensi z rozmeru mapy o slozkach 0..1
   jako pole rozmeru X a Y - todle semka napsal Lukas, zkusim mu verit}
  Result: PResult;
  Cist, Zapisovat: integer;
  {ukazatele v kruhovem bufferu}
  konec, akt, x, y: integer;
  {ukazatel konce a aktualniho prvku v poli a aktivni pmocne x a y bodu}
  sm, aktsm: shortint;
  {uchovani from-smeru pro zapis noveho bodu a aktivni smer, kdetym jsme
   dojeli na tento bod}

  function  NewMap(oldmap : pointer; var map : pointer) : word;
  {Do toho, jaky ma mapa format, nevidim, ovsem tadle procedurka
   by mela asi alokovat pamet pro mapu obrazovky  map  stejne velkou,
   jako je  oldmap.}
  var velikost : word;
      f: file;
  begin
    velikost:=PWordArray(oldmap)^[6]*PWordArray(oldmap)^[5]+14;
{?!?}
{    Assign(f, 'e:\gm3\play\mapa.txt');
    Rewrite(f, 1);
    BlockWrite(f, PByteArray(oldmap)^[0], velikost);
    Close(f);}

    GetMem(map,velikost);
    fillchar(map^,velikost,0);
    PWordArray(map)^[0]:=PWordArray(oldmap)^[0];
    PWordArray(map)^[1]:=PWordArray(oldmap)^[1];
    PWordArray(map)^[2]:=PWordArray(oldmap)^[2];
    PWordArray(map)^[3]:=PWordArray(oldmap)^[3];
    PWordArray(map)^[4]:=PWordArray(oldmap)^[4];
    PWordArray(map)^[5]:=PWordArray(oldmap)^[5];
    PWordArray(map)^[6]:=PWordArray(oldmap)^[6];
    NewMap:=Velikost
  end;


  procedure ZkusBod(nX,nY:integer);
  {cosi to ozkoosi}
  begin
{      if (nX>=1)and(nX<319) and
       (nY>=1)and(nY<199) and}
    if (nX>=0)and(nX<=319) and
       (nY>=0)and(nY<=199) and
{Tadyk se na to kouka, esli je to na obrazovce, akorat ty hodnoty trochu upravim...}
     ( not (not (getpixelmap(nx div delta,ny div delta,R_WalkMap))
     or(getpixelmap(nx div delta,ny div delta,BufferMap))) )
    then begin
      Buf^[Zapisovat].x:=nX;
      Buf^[Zapisovat].y:=nY;
      Buf^[Zapisovat].smer:=sm;
      Zapisovat:=succ(Zapisovat) mod (400*2);

{$ifdef ladeni}
SetActivePage(ActivePage xor 1);
PutPixel(nX,nY,20);
SetActivePage(ActivePage xor 1);
{$endif}

      PutPixelMap(nx div delta,ny div delta,true,BufferMap);
      Inc(konec);
      Result^[konec].x:=nx;
      Result^[konec].y:=ny;
      Result^[konec].min:=akt;
    end
  end;

{!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!}
{teprv tady nam zacina procedurka FindRoad}
{!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!}
begin
{  if (x1=x2)and(y1=y2)then begin}
  if (x2>(x1-delta))and(x2<(x1+delta))and(y2>(y1-delta))and(y2<(y1+delta))
  then begin
   {odchytim situaci, ze vychozi bod je stejny jako cilovy}
    G_WaySteps:=1;
    vysl^[G_WaySteps].x:=x1;
    vysl^[G_WaySteps].y:=y1;
{    write(#7);}
{    H_OnDestination; {!!!Bob}
{?!?}
    exit;
  end;
  NewMap(R_WalkMap, pointer(BufferMap));
{Tady se alokuje navic 8000 byte}
  New(Buf);
{tady 4000}
  New(Result);
{a tady 10000*6}
{tedy celkem dynamickych 72000 byte???}
  Cist:=0;
  Zapisovat:=1;
  Buf^[0].x:=x1;
  Buf^[0].y:=y1;
  buf^[0].smer:=1;
  akt:=1;
  konec:=1;
  Result^[1].x:=x1;
  Result^[1].y:=x2;
  Result^[1].min:=0;
  PutPixelMap(x1,y1,true,BufferMap);
  {v bufferu je uveden seznam uz vyplnenych bodu, pri prochazeni uz se
   nezobrazuji, ale pouze se k nim vyhledaji sousede}

  while (Cist<>Zapisovat)and(not((Buf^[Cist].x=x2)and(Buf^[Cist].y=y2))) do begin
  {dokud nevyprazdnime buffer nebo nenajdeme cestu}
  {and(Cist<804)and(Zapisovat<803) }
    x:=Buf^[Cist].x;
    y:=Buf^[Cist].y;
    aktsm:=buf^[cist].smer;
    case aktsm of
      1{4}:begin
        sm:=1; ZkusBod(x,y-delta);    {horni bod}
        sm:=2; ZkusBod(x,y+delta);    {dolni bod}
        sm:=3; ZkusBod(x-delta,y);    {levy bod}
        sm:=4; ZkusBod(x+delta,y)     {pravy bod}
      end;
      2{1}:begin
        sm:=2; ZkusBod(x,y+delta);    {dolni bod}
        sm:=3; ZkusBod(x-delta,y);    {levy bod}
        sm:=4; ZkusBod(x+delta,y);    {pravy bod}
        sm:=1; ZkusBod(x,y-delta)     {horni bod}
      end;
      3{2}:begin
        sm:=3; ZkusBod(x-delta,y);    {levy bod}
        sm:=4; ZkusBod(x+delta,y);    {pravy bod}
        sm:=1; ZkusBod(x,y-delta);    {horni bod}
        sm:=2; ZkusBod(x,y+delta)     {dolni bod}
      end;
      4{3}:begin
        sm:=4; ZkusBod(x+delta,y);    {pravy bod}
        sm:=1; ZkusBod(x,y-delta);    {horni bod}
        sm:=2; ZkusBod(x,y+delta);    {dolni bod}
        sm:=3; ZkusBod(x-delta,y)     {levy bod}
      end
    end;
    Cist:=succ(Cist) mod (400*2);
    Inc(akt);
  end;
  if cist=zapisovat then begin
    G_WaySteps:=1;
    vysl^[G_WaySteps].x:=x1;
    vysl^[G_WaySteps].y:=y1;
{    write(#7);}
  {neexistuje cesta !!!!}
  end else begin
  {cesta existuje, vrat vhodne polozky z bufferu}
    G_WaySteps:=0;
    repeat
      inc(G_WaySteps);
      vysl^[G_WaySteps].x:=Result^[akt].x;
      vysl^[G_WaySteps].y:=Result^[akt].y;
      akt:=Result^[akt].min;
    until Result^[akt].min=0;
    inc(G_WaySteps);
    vysl^[G_WaySteps].x:=x1;
    vysl^[G_WaySteps].y:=y1;
    {no a zapisu jeste uplne posledni bod cesty- tedy vlastne ten,
     na kterem drak prave stoji}

{tak jsem uz na cosi prisel- pruser je, kdyz bod, kam se ma dojit je
shodny s bodem, ze ktereho se vychazi; zkusim to odchytit uz pred
volanim FindRoad.. alebo coho vlastne...}

{tady se mi jednou stalo, ze se to nekonecne zacyklilo- jak to je mozny??}
{teda spis preteklo!!!!}
{ve chvili, kdy to bylo nekonecne zacykleny se mi stalo, ze mys mela
najednou nejake divne MouseImage - velikej nahodnej obdelnik???!!!}

{podruhe se to zblblo- tentokrat pri tisku mysi. Zajimalo by me, jestli
to vsude dodrzuje rozmery tech poli, jestli treba nezapisuje nekam jinam}

{Ono- je fakt, ze to zacalo delat blbosti teprve potom, co jsem zacal
pouzivat AdjustXYOnMap- ale!!! tam nic nikam neukladam, takze to nemuzu
ulozit ani mimo!! Jediny, co AdjustXYOnMap dela je, ze upravi X,Y -
a podle toho by se snad toto uz melo umet zaridit?}
  end;
  Dispose(Result);
  Dispose(buf);
  DisposeMap(pointer(BufferMap));
end;

procedure ObliqueRoad;{=zkos, zesikmi cestu}
var
  KonvPole: ppole;
  konvpoc: word;
  i, i1: word;
  BetwOne, BetwTwo, BetwHelp: integer;
  StepX, StepY: real;
  FirstX, FirstY: integer;
begin
  New(KonvPole);
  {Nejdrive zjednodusime cestu tak, aby se v ni nachazely jenom "uzly",
   kde se meni smer}
  konvpoc:= 0;
  while G_WaySteps> 1 do begin
    i:=G_WaySteps;
    i1 := i;
    while (G_FoundWay^[i1].X=G_FoundWay^[i1-1].X)and(i1>1) do dec(i1);
    if i<>i1 then begin
      G_WaySteps:=i1;
      Inc(konvpoc);
      KonvPole^[konvpoc].x:= G_FoundWay^[i].X;
      KonvPole^[konvpoc].y:= G_FoundWay^[i].Y;
    end else begin
      i:=G_WaySteps;
      i1 := i;
      while (G_FoundWay^[i1].Y=G_FoundWay^[i1-1].Y)and(i1>1) do dec(i1);
      if i=i1 then Dec(i1);
      G_WaySteps:=i1;
      Inc(konvpoc);
      KonvPole^[konvpoc].x:= G_FoundWay^[i].X;
      KonvPole^[konvpoc].y:= G_FoundWay^[i].Y;
    end;
  end;
  Inc(konvpoc);
  KonvPole^[konvpoc].x:= G_FoundWay^[1].X;
  KonvPole^[konvpoc].y:= G_FoundWay^[1].Y;

  {Samotne zesikmeni se muze provest, pouze ma-li cesta alespon 3(tri) uzly:}
  {vezmeme delku mezi 1. a 2. uzlem a porovname ji s delkou mezi 2. a 3. uzlem;
   pote mensi delkou vydelime vetsi delku a zjistime, jestli se pro tento
   pomer (asi nanejvys 1:3) jeste muze zesikmovat.
   Pokud ano, zkusime vest z 1. do 3. uzlu primku a budeme zjistovat, jestli
   se pod primkou nachazi cesta.
   Pokud ano, vynechame 2. uzel a zkusime novou cestu z 1. do 3.
   Pokud ne, prejdeme na 2. a testujeme ho s 3. a 4.}
{LS}
  i:= 3;
  while i<= konvpoc do begin
    BetwOne:= (KonvPole^[i].x- KonvPole^[i-1].x)+( KonvPole^[i].y-  KonvPole^[i-1].y);
    BetwTwo:= (KonvPole^[i-1].x- KonvPole^[i-2].x)+( KonvPole^[i-1].y-  KonvPole^[i-2].y);
    if Abs(BetwTwo)> Abs(BetwOne) then begin
      BetwHelp:= BetwOne;
      BetwOne:= BetwTwo;
      BetwTwo:= BetwHelp;
    end;
    {Nyni je v BetwOne vetsi z delek, v BetwTwo mensi}
    {if (Abs(BetwTwo / BetwOne)< (1/2))or(Abs(BetwOne)<= 3*delta)or(Abs(BetwTwo)<= 3*delta) then }begin
      {Pokud je pomer spravne velky (nebo spis "maly"), muzeme pokracovat}
      StepX:= (KonvPole^[i].x- KonvPole^[i-2].x);
      {V StepX prozatim x-ova vzdalenost mezi 1. a 3. uzlem}
      if Abs(StepX)= Abs(BetwOne) then begin
        {pokud se x- ova vzdal. mezi 1. a 3. uzlem rovna vetsi z delek,
         znamena to, ze prave x-ova delka je ta delsi, to znamena, ze
         pojedme bod po bodu po x a k y budeme pricitat krok}
        StepY:= (KonvPole^[i].y- KonvPole^[i-2].y);
        StepY:= StepY/Abs(StepX);
        FirstY:= KonvPole^[i-2].y;
        FirstX:= KonvPole^[i-2].x;
        if KonvPole^[i].x< KonvPole^[i-2].x then begin
          StepX:= -1;
        end else begin
          StepX:= 1;
        end;
      end else begin
        {jinak to znamena, ze y-ova delka je delsi, to znamena, ze
         pojedme bod po bodu po y a k x budeme pricitat krok}
        StepX:= StepX/(Abs( (KonvPole^[i].y- KonvPole^[i-2].y) )+0.000001);
        FirstX:= KonvPole^[i-2].x;
        FirstY:= KonvPole^[i-2].y;
        if KonvPole^[i].y< KonvPole^[i-2].y then begin
          StepY:= -1;
        end else begin
          StepY:= 1;
        end;
      end;
{SetActivePage(ActivePage xor 1);}
      for i1:= 1 to (Abs(BetwOne)-1)div delta do begin
{PutPixel(FirstX+trunc(i1*delta* StepX), FirstY+trunc(i1*delta* StepY), 5);
PutPixel(FirstX+trunc(i1*delta* StepX)+1, FirstY+trunc(i1*delta* StepY), 5);
PutPixel(FirstX+trunc(i1*delta* StepX)+2, FirstY+trunc(i1*delta* StepY), 5);}
        if not GetPixelMap((FirstX+trunc(i1*delta* StepX))div delta, (FirstY+trunc(i1*delta* StepY))div delta, R_WalkMap)
        then break;
        {Testuju, esli se vsude pod zesikmenou cestou da jit. Pokud objevim
         bod, kam se neda jit, hned z testovaciho cyklu vyskocim, jinak odtud
         vyskocim, az prohlednu celou cestu}
      end;
{SetActivePage(ActivePage xor 1);}
      if (GetPixelMap((FirstX+trunc(i1*delta* StepX))div delta, (FirstY+trunc(i1*delta* StepY))div delta, R_WalkMap))
         or( (Abs(BetwOne)div delta)< 4)
      then begin
        {Pokud se sikmo opravdu da jit, vynuluju uzel}
        KonvPole^[i-1].x:= 0;
        KonvPole^[i-1].y:= 0;
        for i1:= i to konvpoc do begin
          KonvPole^[i1-1].x:= KonvPole^[i1].x;
          KonvPole^[i1-1].y:= KonvPole^[i1].y;
        end;
        Dec(konvpoc);
        Dec(i);
        {a preskocim tento vynulovany uzel}
      end;
    end;
{repeat until KeyPressed;
readkey;}
    Inc(i);
  end;
{LS}
  {A nakonec ulozim prevedena data do pole, ze ktereho se budou cist}
  G_WaySteps:= 0;
  for i1:= konvpoc downto 1 do begin
    if not((KonvPole^[i1].x=0)and(KonvPole^[i1].y=0))then begin
      Inc(G_WaySteps);
      G_FoundWay^[G_WaySteps].X:= KonvPole^[i1].x;
      G_FoundWay^[G_WaySteps].Y:= KonvPole^[i1].y;
    end;
  end;

  Dispose(KonvPole);
end;


procedure InitWay(x1, y1, x2, y2 : integer);
var
  f, g: word;
begin
  if X1>319 then X1:= 319;
  if X1<0 then X1:= 0;
  if X2>319 then X2:= 319;
  if X2<0 then X2:= 0;
  if Y1>199 then Y1:= 199;
  if Y1<0 then Y1:= 0;
  if Y2>199 then Y2:= 199;
  if Y2<0 then Y2:= 0;
{Upravil jsem vsechny hodnoty tak, aby se nachazely na obrazovce}
  X1:= (X1 div delta)*delta;
  Y1:= (Y1 div delta)*delta;
  X2:= (X2 div delta)*delta;
  Y2:= (Y2 div delta)*delta;

  H_.BeforeWayX:= X1;
  H_.MouseX:= X2;
  H_.LastHorMove:= Nedefinovano;

{$ifdef ladeni}
SetActivePage(ActivePage xor 1);
for f:= 0 to (319 div delta )do for g:= 0 to (199 div delta )do begin
  if GetPixelMap(f, g, R_WalkMap)then PutPixel(f*delta+1,g*delta+1,254);
end;
{$endif}

  {upravime souradnice KAM:}
  if not GetPixelMap(X2 div delta, Y2 div delta, R_WalkMap)then begin
    AdjustXYByCircle(x2,y2,6);
    {pokial zme klikoi mimo a je nastaven "inteligentni" pohled, tak..}
    if H_.SightOnMouse=5 then H_.SightOnMouse:= 1;
  end else if H_.SightOnMouse=5 then H_.SightOnMouse:= 0;
  if not GetPixelMap(X1 div delta, Y1 div delta, R_WalkMap)then AdjustXYByCircle(x1,y1,6);

{$ifdef ladeni}
PutPixel(x2,y2,255);
PutPixel(x2+1,y2,255);
PutPixel(x1,y1,255);
PutPixel(x1+1,y1,255);
SetActivePage(ActivePage xor 1);
{$endif}

  FindRoad(x1, y1, x2 ,y2, G_FoundWay);

{$ifdef ladeni}
SetActivePage(ActivePage xor 1);
for f:=G_WaySteps downto 2 do line(G_FoundWay^[f-1].x,G_FoundWay^[f-1].y,G_FoundWay^[f].x,G_FoundWay^[f].y,128);
SetActivePage(ActivePage xor 1);
{$endif}

  ObliqueRoad;

{$ifdef ladeni}
SetActivePage(ActivePage xor 1);
for f:=G_WaySteps downto 2 do line(G_FoundWay^[f-1].x,G_FoundWay^[f-1].y,G_FoundWay^[f].x,G_FoundWay^[f].y,40);
SetActivePage(ActivePage xor 1);
{$endif}
end;

procedure GoAfterCurve;
begin
  H_.FeetX:= H_.StartX;
  H_.FeetY:= H_.StartY;
  with A_SeqExtHead[H_.AfterCurve]^ do begin
    UserProc:= GoByWay;
  end;
{  H_.WalkSide:= 0;}
  StartPhase(H_.AfterCurve);
{  write(#7);}
end;

procedure GoBeforeFinal;
begin
  H_.FeetX:= H_.FinalX;
  H_.FeetY:= H_.FinalY;
  with A_SeqExtHead[Ord(H_.FinSight)]^ do begin
    UserProc:= FreeUserProc;
  end;
  StartPhase(Ord(H_.FinSight));

  H_OnDestination;
end;

procedure GoByWay;
var
  i: word;
  PrevAnim: byte; {cislo animace, ktera prave bezela}
begin
  for PrevAnim:= 1 to A_LastAnmSeq do begin
    if(A_SeqExtHead[PrevAnim]^.MainHero> 0)and(A_SeqExtHead[PrevAnim]^.InProcess=1)then break;
  end;
  {hledal jsem predchozi probihajici animaci hrdiny}
  H_.StartX:= H_.FeetX;
  H_.StartY:= H_.FeetY;

  if (PrevAnim= Ord(Vlevo))or(PrevAnim= Ord(Vpravo)) then H_.LastHorMove:= TPohybyDraka(PrevAnim);
  {zaznamenavam, jakym horizontalnim smerem sel naposledy}

  if G_WaySteps>1 then begin
    i:= G_WaySteps;
    Dec(G_WaySteps);
    A_HeroContinue:= True;
    H_.YStrOblRatio:= Abs(sqr( (G_FoundWay^[i].Y-G_FoundWay^[G_WaySteps].Y) *1.2/delta) );
    H_.YStrOblRatio:= H_.YStrOblRatio+Abs(sqr( (G_FoundWay^[i].X-G_FoundWay^[G_WaySteps].X) /delta));
    H_.YStrOblRatio:= sqrt(H_.YStrOblRatio);
    {protoze je Pascal blbec, musim to pocitat prave takto...}
    {v H_.YStrOblRatio je nyni delka uhlopricky}
    if round(Abs(G_FoundWay^[i].Y-G_FoundWay^[G_WaySteps].Y)*1.2)>=Abs(G_FoundWay^[i].X-G_FoundWay^[G_WaySteps].X) then begin
      {Testuju, jestli je vetsi vzadlenost ve smeru pravo-levem nebo hore-dolnim}
      H_.XOblStep:= (G_FoundWay^[G_WaySteps].X-G_FoundWay^[i].X)/Abs(G_FoundWay^[G_WaySteps].Y-G_FoundWay^[i].Y);
      {V H_.XOblStep je o kolik bodu v x se ma posunout za 1 bod v y}
      H_.YOblStep:= 0;
      H_.YStrOblRatio:= Abs(G_FoundWay^[G_WaySteps].Y-G_FoundWay^[i].Y)/ H_.YStrOblRatio/ delta;
      H_.XStrOblRatio:= 1;
      {H_.YStrOblRatio je pomer mezi delkou y a sikmou delkou. Sikma delka je
       odmocnina z delky x na 2 plus delky y na 2 }
      if G_FoundWay^[i].Y>G_FoundWay^[G_WaySteps].Y then with A_SeqExtHead[Ord(Nahoru)]^ do begin
      {nahoru}
        H_.FinalX:=G_FoundWay^[G_WaySteps].x;
        H_.FinalY:=G_FoundWay^[G_WaySteps].y;
        if PrevAnim<> Ord(Nahoru) then begin
          A_SeqExtHead[PrevAnim]^.InProcess:=0;
          {zastavil jsem animaci hl. hrdiny, ktera prave doprobihala}
          H_.AfterCurve:= Ord(Nahoru);
          H_.WalkSide:= 0;
          A_HeroContinue:= False;
          if (PrevAnim= Ord(Vlevo))or(PrevAnim= Ord(StujLevo))  then begin
            {byla levo, spustim levo-hore}
            StartPhase( Ord(LevoHore) );
            A_SeqExtHead[Ord(LevoHore) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          if (PrevAnim= Ord(Vpravo))or(PrevAnim= Ord(StujPravo))  then begin
            StartPhase( Ord(PravoHore) );
            A_SeqExtHead[ Ord(PravoHore) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          StartPhase(Ord(Nahoru));
        end;
        UserProc:= GoByWay;
        exit;
      end else with A_SeqExtHead[ Ord(Dolu) ]^ do begin
      {dolu}
        H_.FinalX:=G_FoundWay^[G_WaySteps].x;
        H_.FinalY:=G_FoundWay^[G_WaySteps].y;
        if PrevAnim<>Ord(Dolu) then begin
          A_SeqExtHead[PrevAnim]^.InProcess:=0;
          H_.AfterCurve:= Ord(Dolu);
          H_.WalkSide:=1;
          A_HeroContinue:= False;
          if (PrevAnim= Ord(Vlevo))or(PrevAnim= Ord(StujLevo))  then begin
            StartPhase( Ord(LevoDolu) );
            A_SeqExtHead[ Ord(LevoDolu) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          if (PrevAnim= Ord(Vpravo))or(PrevAnim= Ord(StujPravo)) then begin
            StartPhase( Ord(PravoDolu) );
            A_SeqExtHead[ Ord(PravoDolu) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          StartPhase(Ord(Dolu));
        end;
        UserProc:= GoByWay;
        exit;
      end;
    end else begin
      H_.YOblStep:= (G_FoundWay^[G_WaySteps].Y-G_FoundWay^[i].y)/Abs(G_FoundWay^[G_WaySteps].X-G_FoundWay^[i].x);
      {V H_.YOblStep je o kolik bodu v y se ma posunout za 1 bod v x}
      H_.XOblStep:= 0;
      H_.XStrOblRatio:= Abs(G_FoundWay^[G_WaySteps].X-G_FoundWay^[i].X)/ H_.YStrOblRatio/ delta;
      H_.YStrOblRatio:= 1;
      if G_FoundWay^[i].X<G_FoundWay^[G_WaySteps].X then with A_SeqExtHead[Ord(Vpravo)]^ do begin
      {vpravo}
        H_.FinalX:=G_FoundWay^[G_WaySteps].x;
        H_.FinalY:=G_FoundWay^[G_WaySteps].y;
        if PrevAnim<>Ord(Vpravo) then begin
          A_SeqExtHead[PrevAnim]^.InProcess:=0;
          H_.AfterCurve:= Ord(Vpravo);
          H_.WalkSide:=2;
          A_HeroContinue:= False;
          if PrevAnim= Ord(Dolu) then begin
            StartPhase( Ord(DolePravo) );
            A_SeqExtHead[ Ord(DolePravo) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          if PrevAnim= Ord(Nahoru) then begin
            StartPhase( Ord(HorePravo) );
            A_SeqExtHead[ Ord(HorePravo) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          if PrevAnim= Ord(StujLevo)  then begin
            StartPhase( Ord(LevoPravo) );
            A_SeqExtHead[ Ord(LevoPravo) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          StartPhase(Ord(Vpravo));
        end;
        UserProc:= GoByWay;
        exit;
      end else with A_SeqExtHead[Ord(Vlevo)]^ do begin
      {vlevo}
        H_.FinalX:=G_FoundWay^[G_WaySteps].x;
        H_.FinalY:=G_FoundWay^[G_WaySteps].y;
        if PrevAnim<> Ord(Vlevo) then begin
          A_SeqExtHead[PrevAnim]^.InProcess:=0;
          H_.AfterCurve:= Ord(Vlevo);
          H_.WalkSide:=3;
          A_HeroContinue:= False;
          if PrevAnim= Ord(Dolu) then begin
            StartPhase( Ord(DoleLevo) );
            A_SeqExtHead[ Ord(DoleLevo) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          if PrevAnim= Ord(Nahoru) then begin
            StartPhase( Ord(HoreLevo) );
            A_SeqExtHead[ Ord(HoreLevo) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          if PrevAnim= Ord(StujPravo)  then begin
            StartPhase( Ord(PravoLevo) );
            A_SeqExtHead[ Ord(PravoLevo) ]^.UserProc:= GoAfterCurve;
            exit;
          end;
          StartPhase(Ord(Vlevo));
        end;
        UserProc:= GoByWay;
        exit;
      end;
    end;
  end;

{  InitHero(H_.FeetX, H_.FeetY);}
  H_.XOblStep:= 0;
  H_.YOblStep:= 0;
  H_.XStrOblRatio:= 1;
  H_.YStrOblRatio:= 1;
  H_.WalkSide:=255;
  H_.FeetX:= H_.FinalX;
  H_.FeetY:= H_.FinalY;

(*    H_.SightOnMouse    : byte;      {kam se ma drak divat po dojiti na misto:
                                 0- neurceno: podle toho, odkud prisel
                                 1- na mysku: tam, kde puvodne klikla
                                 3- vpravo
                                 4- vlevo}*)

  {tady vlastne urcim, kamze se to ma hrdina nyni koukat:}
  case H_.SightOnMouse of
    1: begin
         if (H_.FeetX>H_.MouseX) then H_.FinSight:= Ord(StujLevo) else H_.FinSight:= Ord(StujPravo);
         {kouka se na mysku}
       end;
    3: begin
         H_.FinSight:= Ord(StujPravo);
       end;
    4: begin
         H_.FinSight:= Ord(StujLevo);
       end;
    else begin
      if H_.LastHorMove=Vlevo then H_.FinSight:= Ord(StujLevo)
      {posledni horiz. presun byl doleva}
      else if H_.LastHorMove=Vpravo then H_.FinSight:= Ord(StujPravo)
      {posledni horiz. presun byl doprava}
      else if(H_.FeetX<H_.BeforeWayX) then H_.FinSight:= Ord(StujLevo) else H_.FinSight:= Ord(StujPravo);
      {Nepohyboval se ani vpravo, ani vlevo}
    end;
  end;

  if (PrevAnim<>Ord(StujPravo))and(PrevAnim<>Ord(StujLevo)) then begin
  {pokracuji jenom v pripade, ze jsem opravdu odnekud dosel. Pokud uz stojim}
  {a koukam, nema cenu to koukani zapinat znovu, kdyz uz bezi}
    A_SeqExtHead[PrevAnim]^.InProcess:=0;
    {zastavim animaci, ktera probihala}
    {To, jaka se pripadne provede otocka, zavisi nejprve na tom, kam ta}
    {otocka vlastne bude}
    if H_.FinSight= Ord(StujPravo)then begin
      {Otocka buda do praveho stoje..., ale odkud}
      if PrevAnim=Ord(Vlevo) then begin
        with A_SeqExtHead[Ord(LevoPravo)]^ do begin
          UserProc:= GoBeforeFinal;
        end;
        StartPhase(Ord(LevoPravo));
        exit;
      end;
      if PrevAnim=Ord(Nahoru) then begin
        with A_SeqExtHead[Ord(HoreStojPravo)]^ do begin
          UserProc:= GoBeforeFinal;
        end;
        StartPhase(Ord(HoreStojPravo));
        exit;
      end;
    end else begin
      if PrevAnim=Ord(Vpravo) then begin
        with A_SeqExtHead[Ord(PravoLevo)]^ do begin
          UserProc:= GoBeforeFinal;
        end;
        StartPhase(Ord(PravoLevo));
        exit;
      end;
      if PrevAnim=Ord(Nahoru) then begin
        with A_SeqExtHead[Ord(HoreStojLevo)]^ do begin
          UserProc:= GoBeforeFinal;
        end;
        StartPhase(Ord(HoreStojLevo));
        exit;
      end;
    end;
    GoBeforeFinal;
  end else H_OnDestination;
  {!!!LS -Pavle toto skontroluj tady ti chyblel jeden END
         - neslo to zkompilovat nevim jestil jesm ho sem napsal zpravne
   !!!Pavel presunuto zhora sem}
end;

begin
  H_OnDestination:= FreeUserProc;
end.
