{podpora huf komprese pro BARch�v}

unit bar_huf;
interface
uses bar_tog;

function komprese_huf(
  odkud:pbytearray; dekompdelka:word;
  kam:pbytearray; var kompdelka:word):word; {65535=chyba}
function dekomprese_huf(
  odkud:pbytearray; kompdelka:word;
  kam:pbytearray; var dekompdelka:word):word; {65535=chyba}

implementation

type pznak=^tznak;
     tznak=record
       cetnost:word;
       znak:integer; {-1 je vytvoreny znak}
       vyska:byte;
       levy,pravy:pznak;
     end;

     tcetnost=array[byte]of word;

     tposlbitu=array[1..maxhloubkastromu]of byte;
     p1obraz=^t1obraz;
     t1obraz=record
       bitu,bajtu,hloub:byte;
       b:tposlbitu;
     end;
     tobrazy=array[byte]of p1obraz;

     pbytearray=^tbytearray;
     tbytearray=array[1..maxdelkaslozky]of byte;

procedure dealokujstrom(var strom:pznak);
begin
  if strom^.znak=-1 then begin
    dealokujstrom(strom^.levy);
    dealokujstrom(strom^.pravy);
  end;
  dispose(strom);
end;

procedure dealokujobrazy(var obr:tobrazy);
var i:byte;
begin
  for i:=0 to 255 do
    if obr[i]<>nil then
      freemem(obr[i],3+obr[i]^.bajtu);
end;

function komprese_huf; {65535=chyba}
{komprimuje do naalokovan�ho v�stupu, ale pokud se tam komprim�t nevleze,
 ohl�s� chybu, jinak vr�t� zkomprimovanou d�lku}
label navchyba;
var poco,delkao:word; {indexy}
    chyba:word; {chybov� prom�nn�}
    cetn:tcetnost; {kompresn� prom�nn�}
    strom:pznak;
    obr:tobrazy;

 procedure nacticetnost(var cetn:tcetnost);
 {projde cel� vstupn� soubor a vypo��t� �etnost v�ech jeho znak�}
 var x:word;
 begin
   fillchar(cetn,sizeof(cetn),0);
   for x:=1 to dekompdelka do
     inc(cetn[odkud^[x]]);
 end;

 procedure cetnost2strom(
   var puvcetn:tcetnost; {vstup}
   var strom:pznak; {2 v�stupy}
   var obr:tobrazy);
 {postavi strom stylem 2 nejridsi znaky propoji a povazuje za castejsi znak
  pocita vysku stromu a savne to taky k cetnosti
  d�le zap��e tento strom do hlavi�ky zkomprimovan�ho souboru
  a spo��t� hloubku a bitov� obrazy v�ech znak�}
 var hloubka:byte; {hloubka stromu}
     bity:tposlbitu; {jednotliv� bity znak�}
     delkabajtu,cislobitu:byte; {po��tadlo bit�}

  procedure zapispocetbitu(strom:pznak);
  {zapise rekurzivne hloubku a bitov� obrazy vsech znaku
   pr�b��n� to ukl�d� do hlavi�ky zkomprimovan�ho souboru}
  var i:byte; {pomocn� po��tadlo}
  begin
    if (poco>kompdelka-1{2 znaky kontrola pro oba p��pady}) or
       (chyba<>0) then begin
      chyba:=65535;
      exit;
    end;

    if strom^.znak=-1 then begin {zapise rozvetveni}
      kam^[poco]:=0; {zap��eme do v�stupu rozv�tven�}
      inc(poco);
      inc(hloubka); {zv�t��me hloubku stromu}
      inc(cislobitu); {posuneme se na dal�� bit}
      if cislobitu=8 then begin
        inc(delkabajtu);
        cislobitu:=0;
      end;

      {zavol�me rekurzivn� sami sebe s 0. bitem (vlevo)}
      zapispocetbitu(strom^.levy);
      bity[delkabajtu]:=bity[delkabajtu] xor (1 shl cislobitu);
      {zavol�me rekurzivn� sami sebe s 1. bitem (vpravo)}
      zapispocetbitu(strom^.pravy);

      {obnov�me bit, hloubku stromu a po��tadlo bit�}
      bity[delkabajtu]:=bity[delkabajtu] xor (1 shl cislobitu);
      dec(hloubka);
      if cislobitu=0 then begin
        dec(delkabajtu);
        cislobitu:=7;
      end else
        dec(cislobitu);
    end else begin {zapise znak}
      kam^[poco]:=1; {zap��e do hlavi�ky}
      inc(poco);
      kam^[poco]:=strom^.znak;
      inc(poco);

      getmem(obr[byte(strom^.znak)],3+delkabajtu); {zap��e jeho bitov� obraz}
      with obr[byte(strom^.znak)]^ do begin
        bitu:=cislobitu+1;
        bajtu:=delkabajtu;
        hloub:=hloubka;
        for i:=1 to delkabajtu do
          b[i]:=bity[i];
      end;
    end;
  end;

 var cetn:array[byte] of pznak; {pomocn� strom}
     i,j,pocet:integer; {po��tadla}
     pom1znak:pznak; {pomocn� v�tev}
 begin
   if kompdelka<2 then begin
     chyba:=65535;
     exit;
   end;
   pwordarray(kam)^[1]:=dekompdelka; {zap��eme d�lku vstupn�ho souboru}
   poco:=3; {po��tadlo z�pisu do bufferu}

   pocet:=256;
   for i:=0 to pocet-1 do begin {alokuje listy stromu}
     new(cetn[i]);
     cetn[i]^.cetnost:=puvcetn[i];
     cetn[i]^.znak:=i;
     cetn[i]^.vyska:=0;
     cetn[i]^.levy:=nil;
     cetn[i]^.pravy:=nil;
   end;
   for i:=1 to pocet-1 do {set��dit tento seznam podle �etnosti znak�}
     for j:=pocet-1 downto i do
       if cetn[j]^.cetnost<cetn[j-1]^.cetnost then begin
         pom1znak:=cetn[j];
         cetn[j]:=cetn[j-1];
         cetn[j-1]:=pom1znak;
       end;
   {pro men�� strom ignorujeme znaky s v�skytem 0
    a to i v p��pad�, �e by strom obsahoval pouze jedin� znak}
   j:=0;
   while (j<pocet)and(cetn[j]^.cetnost=0) do
     inc(j);
   dec(pocet,j);
   if pocet=0 then inc(pocet); {pokud byl pr�zdn� soubor, zanech�me jedin� znak}
   if j<>0 then begin {dealokuje zbyte�n� uzly a p�esune ostatn�}
     for i:=0 to j-1 do
       dispose(cetn[i]);
     for i:=0 to pocet-1 do
       cetn[i]:=cetn[i+j];
   end;
   {nyn� budeme kombinovat strom, dokud nez�stane jedin� vrchol}
   while pocet>1 do begin
     new(pom1znak); {vezmeme 2 nejridsi znaky, vytvorime z nich novy znak}
     pom1znak^.cetnost:=cetn[0]^.cetnost+cetn[1]^.cetnost;
     pom1znak^.znak:=-1;
     if cetn[0]^.vyska>cetn[1]^.vyska {vezmeme vetsi vysku stromu}
       then pom1znak^.vyska:=cetn[0]^.vyska+1
       else pom1znak^.vyska:=cetn[1]^.vyska+1;
     pom1znak^.levy:=cetn[0];
     pom1znak^.pravy:=cetn[1];
     i:=1; {vyhledame, ZA co to mame vlozit}
     while (i<pocet-1)and(cetn[i+1]^.cetnost<=pom1znak^.cetnost) do
       inc(i);
     for j:=0 to i-2 do {posuneme ridsi znaky}
       cetn[j]:=cetn[j+2];
     cetn[i-1]:=pom1znak; {vlozime znak}
     dec(pocet);
     for j:=i to pocet-1 do {posuneme hustejsi znaky}
       cetn[j]:=cetn[j+1];
   end;
   strom:=cetn[0];

   hloubka:=0; {zat�m je nulov� hloubka}
   fillchar(obr,sizeof(obr),0); {nil ke v�em zapisovan�m znak�m}
   fillchar(bity,sizeof(bity),0); {nulov� bity}
   delkabajtu:=0; {kam se bude zapisovat}
   cislobitu:=7;
   zapispocetbitu(strom); {vypo��t�me hlavi�ku a vytvo��me obrazy}
   if chyba<>0 then
     exit;

   delkao:=0;
   for j:=0 to 255 do
     inc(delkao,puvcetn[j]*obr[j]^.hloub);
   delkao:=trunc(delkao/8+0.99);
{   writeln('nekomprimovano: ',dekompdelka:16,'b');
   writeln('hlavicka huffm: ',poco+4:16,'b');
   writeln('huffmanuv  kod: ',delkao:16,'b');
   writeln('uspora       o: ',(dekompdelka-delkao-(poco+4))/dekompdelka*100:16:2,'%');}

   inc(delkao,poco-1);
   if delkao>kompdelka then begin {nevleze-li se to do bufferu}
     chyba:=65535;
     exit;
   end;
 end;

 procedure komprese(var obr:tobrazy);
 var poci:word; {index vstupu}
     zas:integer; {zde se budou provadet ty rotace}
     zasbitu,i:byte; {kolik je v zasobniku bitu, temp}
 begin
   zas:=0; {inicializace z�pisu}
   zasbitu:=0;
   if obr[odkud^[1]]^.bajtu=0 then begin
   {n�jak� znak m� nula bajt� ---> v�echno m� nula bajt�
    nic se nezapisuje}
   end else
   {jinak v�echno poctiv� zap��eme}
     for poci:=1 to dekompdelka do {p�e�teme cel� vstupn� soubor}
       with obr[odkud^[poci]]^ do begin{zapiseme BITOVE jednotlivy znak}
         for i:=1 to bajtu-1 do begin {vsechny PLNE bajty}
           zas:=zas or (b[i] shl zasbitu); {pridej 1. znak}
           kam^[poco]:=zas and $ff; {zapis ho a posun buffer}
           inc(poco);
           zas:=zas shr 8;
         end;
         zas:=zas or (b[bajtu] shl zasbitu); {pridej posledni znak}
         {za jeho koncem jsou jist� sam� nuly}
         inc(zasbitu,bitu);
         if zasbitu>=8 then begin
           kam^[poco]:=zas and $ff;
           inc(poco);
           zas:=zas shr 8;
           dec(zasbitu,8);
         end;
       end;
     {kontrolu p�ete�en� v�stupu prov�d�t nebudu, bylo by to pomalej��
      a u� je to ur�it� (snad) odlad�no :-) }
   if zasbitu<>0 then begin
     kam^[poco]:=zas and $ff;
     inc(poco);
   end;
   if poco-1<>delkao then begin {ale to by m�lo souhlasit}
     chyba:=65535;
     exit;
   end;
 end;

begin
  chyba:=0;
  komprese_huf:=65535;

  nacticetnost(cetn); {v�po�et komprese}
  if chyba<>0 then exit;
  cetnost2strom(cetn,strom,obr);
  if chyba<>0 then goto navchyba;
  {i v p��pad� chyby se to spr�vn� odalokuje}

  komprese(obr);
  if chyba<>0 then goto navchyba;

  komprese_huf:=0;
  kompdelka:=delkao;
navchyba:
  dealokujstrom(strom);
  dealokujobrazy(obr);
end;

function dekomprese_huf; {65535=chyba}
{komprimuje do naalokovan�ho v�stupu, pokud nejsou v�sledn� d�lky shodn�,
 ohl�s� chybu, jinak vr�t� zkomprimovanou d�lku (tzn. nic nav�c se nestane)}
label navchyba;
var poci:word; {index komprimace}
    chyba:word; {chybov� prom�nn�}
    strom:pznak; {kompresn� prom�nn�}

 function nactihlavicku:pznak;
 var strom:pznak;
     i:byte;
 begin
   if poci>kompdelka-1 then begin
   {v obou p��padech jsou z bufferu po�adov�ny aspo� 2b}
     chyba:=65535;
     exit;
   end;
   new(strom);
   strom^.cetnost:=0;
   strom^.vyska:=0;
   strom^.znak:=0; {horni bit}
   i:=odkud^[poci];
   inc(poci);
   if i=1 then begin {znak}
     strom^.znak:=odkud^[poci];
     inc(poci);
     strom^.levy:=nil;
     strom^.pravy:=nil;
   end else begin {rozvetveni}
     strom^.znak:=-1;
     strom^.levy:=nactihlavicku;
     strom^.pravy:=nactihlavicku;
   end;
   nactihlavicku:=strom;
 end;

 procedure dekomprese(strom:pznak);
 var aktbit:byte;
     poco:word;
     test:pznak;
 begin
   aktbit:=1; {nutnost na��st 1. blok}
   {poci u� je nastaveno}
   for poco:=1 to dekompdelka do begin {zap��eme v�echny v�stupn� znaky}
     test:=strom; {hled�me od ko�enu stromu}
     while test^.znak=-1 do begin {dokud nenalezneme list}
       if odkud^[poci] and aktbit=0 {hled�me ve stromu}
         then test:=test^.levy
         else test:=test^.pravy;
       {$r-}
       aktbit:=aktbit shl 1; {najedeme na dal�� bit}
       {$r+}
       if aktbit=0 then begin {konec bajtu?}
         inc(poci);
         aktbit:=1;
       end;
     end;
     kam^[poco]:=test^.znak;
   end;
   if aktbit=1 then
     dec(poci);
   if poci<>kompdelka then begin {kontrola p�e�ten� cel�ho vstupn�ho fajlu}
     chyba:=65535;
     exit;
   end;
end;

begin
  chyba:=0;
  dekomprese_huf:=65535;

  if pwordarray(odkud)^[1]<>dekompdelka then exit; {�patn� d�lka}
  poci:=3; {�ten� z bufferu}
  strom:=nactihlavicku; {na�teme hlavi�ku komprim�tu}
  if chyba<>0 then goto navchyba;

  dekomprese(strom);
  if chyba<>0 then goto navchyba;

  dekomprese_huf:=0;
navchyba:
  dealokujstrom(strom);
end;

end.
