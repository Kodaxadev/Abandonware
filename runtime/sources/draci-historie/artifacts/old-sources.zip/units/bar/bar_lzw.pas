{podpora lzw komprese pro BARch�v}

unit bar_lzw;
interface
uses bar_tog;

function komprese_lzw(
  odkud:pbytearray; dekompdelka:word;
  kam:pbytearray; var kompdelka:word):word; {65535=chyba}
function dekomprese_lzw(
  odkud:pbytearray; kompdelka:word;
  kam:pbytearray; var dekompdelka:word):word; {65535=chyba}

implementation

const VelikostBufferu = 4096;
      Nula            = VelikostBufferu;
      MaxDelkaKroku   = 18;
      MinDelkaKroku   = 2;

type pbuffer=^tbuffer;
     tbuffer=array [0..VelikostBufferu+MaxDelkaKroku-1] of byte;
     plevysyn=^tlevysyn;
     tlevysyn=array [0..VelikostBufferu] of word;
     ppravysyn=^tpravysyn;
     tpravysyn=array [0..VelikostBufferu+256] of word;

function komprese_lzw(
  odkud:pbytearray; dekompdelka:word;
  kam:pbytearray; var kompdelka:word):word; {65535=chyba}
{komprimuje do naalokovan�ho v�stupu, ale pokud se tam komprim�t nevleze,
 ohl�s� chybu, jinak vr�t� zkomprimovanou d�lku}
var poci,poco:word; {indexy komprimace}
    chyba:word;

    {cel� tato komprese je ops�na z BAJTu:}
    buffer:pbuffer;
    PoziceVKroku,DelkaKroku:word;
    levysyn, Otec:plevysyn;
    PravySyn:ppravysyn;

 procedure InicializujStrom;
 var Pom:word;
 begin
   for Pom:=VelikostBufferu+1 to VelikostBufferu+256 do
     PravySyn^[Pom]:=Nula;
   for Pom:=0 to VelikostBufferu-1 do
     Otec^[Pom]:=Nula
 end;

 procedure VlozUkazatel (R:word);
 label NalezenRozdil,VelmiDlouhaShoda;
 var I,P:word;
     Cmp:integer;
     Key:byte;
 begin
   Cmp:=1;
   DelkaKroku:=0;
   Key:=buffer^[R];
   P:=VelikostBufferu+Key+1;
   PravySyn^[R]:=Nula;
   levysyn^[R]:=Nula;
   repeat
     if Cmp>=0 then
       if PravySyn^[P]<>Nula then P:=PravySyn^[P]
                            else begin
                                   PravySyn^[P]:=R;
                                   Otec^[R]:=P;
                                   Exit
                                 end
       else if levysyn^[P]<>Nula then P:=levysyn^[P]
                                else begin
                                       levysyn^[P]:=R;
                                       Otec^[R]:=P;
                                       Exit
                                     end;
     I:=1;
     while I<MaxDelkaKroku do
       begin
         Cmp:=buffer^[R+I]-buffer^[P+I];
         if Cmp<>0 then
           GoTo NalezenRozdil;
         Inc(I)
       end;
 NalezenRozdil:
     if I>DelkaKroku then
       begin
         PoziceVKroku:=P;
         DelkaKroku:=I;
         if DelkaKroku>=MaxDelkaKroku then
           GoTo VelmiDlouhaShoda
       end
   until False;
 VelmiDlouhaShoda:
   Otec^[R]:=Otec^[P];
   levysyn^[R]:=levysyn^[P];
   PravySyn^[R]:=PravySyn^[P];
   Otec^[levysyn^[P]]:=R;
   Otec^[PravySyn^[P]]:=R;
   if PravySyn^[Otec^[P]]=P then PravySyn^[Otec^[P]]:=R
                          else levysyn^[Otec^[P]]:=R;
   Otec^[P]:=Nula
 end;

 procedure ZrusUkazatel (P:word);
 var Q:word;
 begin
   if Otec^[P]=Nula then
     Exit;
   if PravySyn^[P]=Nula then
     Q:=levysyn^[P]
   else if levysyn^[P]=Nula
     then Q:=PravySyn^[P]
     else begin
       Q:=levysyn^[P];
       if PravySyn^[Q]<>Nula then
         begin
           repeat
             Q:=PravySyn^[Q]
           until PravySyn^[Q]=Nula;
           PravySyn^[Otec^[Q]]:=levysyn^[Q];
           Otec^[levysyn^[Q]]:=Otec^[Q];
           levysyn^[Q]:=levysyn^[P];
           Otec^[levysyn^[P]]:=Q
         end;
       PravySyn^[Q]:=PravySyn^[P];
       Otec^[PravySyn^[P]]:=Q
     end;
   Otec^[Q]:=Otec^[P];
   if PravySyn^[Otec^[P]]=P then PravySyn^[Otec^[P]]:=Q
                          else levysyn^[Otec^[P]]:=Q;
   Otec^[P]:=Nula
 end;

 procedure Komprimuj;
 var I,Delka,R,S:word;
     C,PosledniDelkaKroku,UkazatelKodu,Maska:byte;
     BufferKodu:array[0..16]of byte;
 begin
   InicializujStrom;
   BufferKodu[0]:=0;
   Maska:=1;
   UkazatelKodu:=1;
   S:=0;
   R:=VelikostBufferu-MaxDelkaKroku;
   for I:=S to R-1 do
     buffer^[I]:=$20;
   Delka:=0;

   poci:=1; {kam zapisovat}
   poco:=0; {index na konec prozat�mn�ho z�pisu}

   while (Delka<MaxDelkaKroku)and(poci<=dekompdelka) do
     begin
       buffer^[R+Delka]:=odkud^[poci];
       inc(poci);
       Inc(Delka);
     end;
   if Delka=0 then Exit;

   for I:=1 to MaxDelkaKroku do
     VlozUkazatel(R-I);
   VlozUkazatel(R);

   repeat
     if DelkaKroku>Delka then
       DelkaKroku:=Delka;
     if DelkaKroku<=MinDelkaKroku
       then begin
              DelkaKroku:=1;
              BufferKodu[0]:=BufferKodu[0] or Maska;
              BufferKodu[UkazatelKodu]:=buffer^[R];
              Inc(UkazatelKodu)
            end
       else begin
              BufferKodu[UkazatelKodu]:=Lo(PoziceVKroku);
              Inc(UkazatelKodu);
              BufferKodu[UkazatelKodu]:=(Hi(PoziceVKroku) SHL 4) or
                                        (DelkaKroku-MinDelkaKroku-1);
              Inc(UkazatelKodu)
            end;

     Maska:=(Maska SHL 1) and $FF;
     if Maska=0 then
       begin
         if poco>=kompdelka-(ukazatelkodu-1) then begin
           chyba:=65535;
           exit;
         end;
         for I:=0 to UkazatelKodu-1 do begin
           inc(poco);
           kam^[poco]:=bufferkodu[i];
         end;
         BufferKodu[0]:=0;
         Maska:=1;
         UkazatelKodu:=1
       end;

     PosledniDelkaKroku:=DelkaKroku;
     I:=0;
     while (I<PosledniDelkaKroku) and (poci<=dekompdelka) do
       begin
         C:=odkud^[poci];
         inc(poci);
         ZrusUkazatel(S);
         buffer^[S]:=C;
         if S<MaxDelkaKroku-1 then
           buffer^[S+VelikostBufferu]:=C;
         S:=(S+1) and (VelikostBufferu-1);
         R:=(R+1) and (VelikostBufferu-1);
         VlozUkazatel(R);
         Inc(I)
       end;

     while I<PosledniDelkaKroku do
       begin
         Inc(I);
         ZrusUkazatel(S);
         S:=(S+1) and (VelikostBufferu-1);
         R:=(R+1) and (VelikostBufferu-1);
         Dec(Delka);
         if Delka<>0 then VlozUkazatel(R)
       end;

   until Delka<=0;

   if UkazatelKodu>1 then
     begin
       if poco>=kompdelka-(ukazatelkodu-1) then begin {konec?}
         chyba:=65535;
         exit;
       end;
       for I:=0 to UkazatelKodu-1 do begin
         inc(poco);
         kam^[poco]:=BufferKodu[I];
       end;
     end;
 end;

begin
  chyba:=0;
  komprese_lzw:=65535;

  new(buffer);
  new(otec);
  new(levysyn);
  new(pravysyn);
  komprimuj; {provede onu z�hadnou kompresi}
  dispose(buffer);
  dispose(otec);
  dispose(levysyn);
  dispose(pravysyn);
  if chyba=65535 then exit;

  komprese_lzw:=0;
  kompdelka:=poco;
end;

function dekomprese_lzw(
  odkud:pbytearray; kompdelka:word;
  kam:pbytearray; var dekompdelka:word):word; {65535=chyba}
{komprimuje do naalokovan�ho v�stupu, pokud nejsou v�sledn� d�lky shodn�,
 ohl�s� chybu, jinak vr�t� zkomprimovanou d�lku (tzn. nic nav�c se nestane)}
var poci,poco:word; {kompresn� indexy}
    chyba:word;

    buffer:pbuffer;

 procedure DeKomprimuj;
 var I,C,Delka:byte;
     K,R,Pozice,Vlajka:word;
 begin
   for K:=0 to VelikostBufferu-MaxDelkaKroku-1 do
     buffer^[K]:=$20;
   R:=VelikostBufferu-MaxDelkaKroku;
   Vlajka:=0;

   poci:=1; {kam zapisovat}
   poco:=0; {index na konec prozat�mn�ho z�pisu}

   repeat
     Vlajka:=Vlajka shr 1;
     if (Vlajka and $100)=0 then
       begin
         if poci>kompdelka then
           Break;
         C:=odkud^[poci];
         inc(poci);
         Vlajka:=C or $FF00
       end;

     if (Vlajka and $01)=0
       then begin
              if poci>kompdelka-1 then
                Break;
              I:=odkud^[poci];
              Delka:=odkud^[poci+1];
              inc(poci,2);
              Pozice:=I or ((Delka and $F0) shl 4);
              Delka:=(Delka and $0F)+MinDelkaKroku;
              if poco>=dekompdelka-delka then begin
                chyba:=65535;
                exit;
              end;
              for K:=0 to Delka do
                begin
                  C:=buffer^[(Pozice+K) and (VelikostBufferu-1)];
                  inc(poco);
                  kam^[poco]:=c;
                  buffer^[R]:=C;
                  R:=(R+1) and (VelikostBufferu-1)
                end
            end
       else begin
              if poci>kompdelka then
                Break;
              if poco>=dekompdelka then begin
                chyba:=65535;
                exit;
              end;
              inc(poco);
              c:=odkud^[poci];
              kam^[poco]:=c;
              inc(poci);
              buffer^[R]:=C;
              R:=(R+1) and (VelikostBufferu-1)
            end
   until False;
 end;

begin
  chyba:=0;
  dekomprese_lzw:=65535;

  new(buffer);
  dekomprimuj;
  dispose(buffer);
  if chyba=65535 then exit;
  if poco<>dekompdelka then exit;

  dekomprese_lzw:=0;
end;

end.
