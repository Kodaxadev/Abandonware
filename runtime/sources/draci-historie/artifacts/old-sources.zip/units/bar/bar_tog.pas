{spole�n� deklarace pro bar}

unit bar_tog;
interface

const maxdelkaslozky=65000;
      maxotevrenycharchivu=10;
      maxslozekarchivu=10000;
      maxhloubkastromu=256;

type plongintarray=^tlongintarray;
     tlongintarray=array[1..maxslozekarchivu]of longint;

     pwordarray=^twordarray;
     twordarray=array[1..1000]of word;

     pbytearray=^tbytearray;
     tbytearray=array[1..maxdelkaslozky]of byte;

implementation

end.
