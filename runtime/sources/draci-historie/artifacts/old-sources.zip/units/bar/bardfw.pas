{bar-knihovna emuluj�c� dfw-rozhran�}
unit bardfw;
interface
uses bar_tog;

const maxemulaci=(maxotevrenycharchivu-1)div 3+1;

type t1emulacnislozky=record
       cesta:string;
       cislo:byte;
       {0=puvodni dfw}
     end;
     temulacnichslozek=record
       pocet:byte;
       s:array[1..maxemulaci]of t1emulacnislozky;
     end;

function CCloseArchive(Archiv:string):word; {moje, p�id�no pro efektivitu}
Function CAddFromFile(Archiv : String; Supplement : String) : Word;
Function CAddFromMemory(Archiv : String; Supplement : Pointer; SuppSize : Word) : Word;
Function CLoadItem(Archiv : String; Var Destination : Pointer; Which : Word) : Word; {Nahraje soubor do pameti}
Function CReadItem(Archiv :  String; Destination : Pointer; Which : Word) : Word;
Function UnpackedItemSize(Archiv : String; Which : Word) : Word; {Zjisti delku souboru}
Function GetArchiveAvail(Archiv : String) : Word; {Vysledkem je pocet volnych pozic}
Function GetArchiveOccupy(Archiv : String) : Word; {Vysledkem je pocet obsazenych pozic}

implementation
uses barchiv,dfw,dos;

var emul:temulacnichslozek;

function vratcislobar(cesta:string;jak:byte):byte;
{prohled� emula�n� z�znamy, jestli to nen� u� otev�eno
 255=nastala chyba pri otevreni
 0=volat puvodni dfw
 jinak cislo BARu}
var i:byte;
    j:word;
begin
  vratcislobar:=255; {chyba};
  cesta:=fexpand(cesta);
  for i:=1 to emul.pocet do
    if emul.s[i].cesta=cesta then begin
    {u� tam existuje}
      if emul.s[i].cislo=0 then begin {puvodni dfw}
        vratcislobar:=0;
        exit;
      end;
      j:=barotevri(emul.s[i].cesta,jak);
      if j=emul.s[i].cislo then
      {reotev�eme ho, pokud je to pod stejn�m m�dem, nic se nestane}
        vratcislobar:=emul.s[i].cislo {o.k.}
      else if j=65535 then
        {vratcislobar:=0 {nepovedlo se}
      else begin {nic jin�ho to vr�tit nem��e!}
        writeln('intern� chyba emul�toru dfw');
        halt(100);
      end;
      exit;
      {vr�t�me obvykl� ��slo}
    end;
  {jinak dosud v emula�n�m seznamu nen�}
  while emul.pocet>=maxemulaci do begin {aby se n�m to ve�lo do pole}
    if emul.s[1].cislo<>0 then {neni to dfw}
      if barzavri(emul.s[1].cislo)=65535 then {chyba}
        exit;
    dec(emul.pocet); {uzav�eme nejstar�� slo�ku}
    for i:=1 to emul.pocet do
      emul.s[i]:=emul.s[i+1];
  end;

  j:=barotevri(cesta,jak); {p�iotev�eme}
  if j<>65535 then begin {bez chyby}
    inc(emul.pocet);
    emul.s[emul.pocet].cesta:=cesta;
    emul.s[emul.pocet].cislo:=j;
    vratcislobar:=j;
    exit;
  end else begin {nepoda�ilo se otev��t}
    inc(emul.pocet);
    emul.s[emul.pocet].cesta:=cesta;
    emul.s[emul.pocet].cislo:=0;
    vratcislobar:=0; {nechame to na bedrech dfw}
    exit;
  end;
{m��eme taky po��d jenom otv�rat a zav�rat soubory, ale j� to chci ud�lat
 takhle �ikovn�ji!}
end;

function CCloseArchive(Archiv:string):word;
var i:byte;
begin
  CCloseArchive:=0; {chyba}
  archiv:=fexpand(archiv);
  for i:=1 to emul.pocet do
    if (emul.s[i].cesta=archiv)and(emul.s[i].cislo<>0) then begin
      if barzavri(emul.s[i].cislo)=65535 then {zkus�me zav��t}
        exit;
      dec(emul.pocet); {odstran�me ze seznam�}
      for i:=i to emul.pocet do
        emul.s[i]:=emul.s[i+1];
      cclosearchive:=1;
      exit;
    end;
end;

Function CAddFromFile(Archiv : String; Supplement : String) : Word;
var cisarch:byte;
    x:word;
begin
  caddfromfile:=0;
  cisarch:=vratcislobar(archiv,2); {p�ips�n�}
  if cisarch=255 then exit;
  if cisarch=0 then
    x:=dfw.caddfromfile(archiv,supplement)
  else begin
    x:=barzapissoubor(cisarch,supplement);
    if x=65535 then exit;
  end;
  caddfromfile:=x;
end;

Function CAddFromMemory(Archiv : String; Supplement : Pointer; SuppSize : Word) : Word;
var cisarch:byte;
    x:word;
begin
  caddfrommemory:=0;
  cisarch:=vratcislobar(archiv,2); {p�ips�n�}
  if cisarch=255 then exit;
  if cisarch=0 then
    x:=dfw.caddfrommemory(archiv,supplement,suppsize)
  else begin
    x:=barzapis(cisarch,supplement,suppsize);
    if x=65535 then exit;
  end;
  caddfrommemory:=x;
end;

Function CLoadItem(Archiv : String; Var Destination : Pointer; Which : Word) : Word; {Nahraje soubor do pameti}
var cisarch:byte;
    x:word;
begin
  cloaditem:=0;
  cisarch:=vratcislobar(archiv,1); {�ten�}
  if cisarch=255 then exit;
  if cisarch=0 then
    x:=dfw.cloaditem(archiv,destination,which)
  else begin
    x:=barnactialok(cisarch,which,destination);
    if x=65535 then exit;
  end;
  cloaditem:=x;
end;

Function CReadItem(Archiv :  String; Destination : Pointer; Which : Word) : Word;
var cisarch:byte;
    x:word;
begin
  creaditem:=0;
  cisarch:=vratcislobar(archiv,1); {�ten�}
  if cisarch=255 then exit;
  if cisarch=0 then
    x:=dfw.creaditem(archiv,destination,which)
  else begin
    x:=barnacti(cisarch,which,destination);
    if x=65535 then exit;
  end;
  creaditem:=x;
end;

Function UnpackedItemSize(Archiv : String; Which : Word) : Word; {Zjisti delku souboru}
var cisarch:byte;
    x:word;
begin
  unpackeditemsize:=0;
  cisarch:=vratcislobar(archiv,1); {�ten�}
  if cisarch=255 then exit;
  if cisarch=0 then
    x:=dfw.unpackeditemsize(archiv,which)
  else begin
    x:=bardelkaslozky(cisarch,which);
    if x=65535 then exit;
  end;
  unpackeditemsize:=x;
end;

Function GetArchiveAvail(Archiv : String) : Word; {Vysledkem je pocet volnych pozic}
var cisarch:byte;
begin
  getarchiveavail:=0;
  cisarch:=vratcislobar(archiv,1);
  if cisarch=255 then exit;
  if cisarch=0 then
    getarchiveavail:=dfw.getarchiveavail(archiv)
  else
    getarchiveavail:=maxslozekarchivu;
end;

Function GetArchiveOccupy(Archiv : String) : Word; {Vysledkem je pocet obsazenych pozic}
var cisarch:byte;
    x:word;
begin
  getarchiveoccupy:=0;
  cisarch:=vratcislobar(archiv,1); {�ten�}
  if cisarch=255 then exit;
  if cisarch=0 then
    x:=dfw.getarchiveoccupy(archiv)
  else begin
    x:=barpocetslozek(cisarch);
    if x=65535 then exit;
  end;
  getarchiveoccupy:=x;
end;

begin
  emul.pocet:=0;
  typkomprese:=0; {nekompimuje}
end.