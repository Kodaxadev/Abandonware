{gpl2 kompil�tor, hlavn� modul}

unit gpl2;





interface
uses txt2iden,txt2comm;

const maxdelkakodu=10000;
      maxretezcu=1000;

type pkod=^tkod;
     tkod=record
       {alok,}delka:integer;
       k:array[1..maxdelkakodu]of integer;
     end;

     pstring=^string;

     pseznamretezcu=^tseznamretezcu;
     tseznamretezcu=record
       {alok,}pocet:integer;
       r:array[1..maxretezcu]of pstring;
     end;

     pseznampomretezcu=^tseznampomretezcu;
     tseznampomretezcu=record
       {alok,}pocet:integer;
       r:array[1..maxretezcu]of record
         r:pstring;
         vyskyt:integer; {index, kde se to ve zdrojov�m textu vyskytlo}
         cis,podcis,par:byte; {��slo, pod��slo a parametr dan�ho p��kazu}
       end;
     end;

function gpl2kompiluj(var fi:text;
                      var vyslkod:pkod;
                      var seznret:pseznamretezcu;
                      pricistret:integer;
                      var seznpomret:pseznampomretezcu;
                      ident:pident; maxident:byte;
                      prik,talk:pprikaz):integer;
{p�edpokl�d� otev�en� textov� soubor, ze kter�ho bude ��st, dokud
 nenaraz� na konec souboru nebo ��dek za��naj�c� `endgpl' nebo `gplend'
 pricistret: z�sobn�k �et�zc� se m��e t�eba pr�b��n� vyb�rat, tak�e i
             kdy� se p�ed� pr�zdn�, bylo by vhodn� nenaru�it ��slov�n�}

function nactiident_prik(var ident:pident; var maxident:byte;
                         var prik,talk:pprikaz):integer;
procedure dealokujident_prik(var ident:pident; var prik:pprikaz);





implementation
uses together,mat2bin;

const maxnavesti=20;
      maxdelnavesti=maxdelident;

type tjmnavesti=string[maxdelnavesti];

     tnavesti=record
       cislo:integer; {po�. ��slo p��kazu, nebo 0=zat�m nedefinov�no}
       jm:tjmnavesti;
     end;

     tseznamnavesti=record
       pocet:byte;
       n:array[1..maxnavesti]of tnavesti;
     end;

     tseznamskutecnychparametru=record
       pocet:byte;
       p:array[1..maxparametru]of record
         typ, {1234}
         podtyp:byte; {u �et�zce a identifik�toru; viz. txt2iden}
         hodn:integer; {p��mo ��slo, nebo hodnota identifik�toru nebo
                        index do tabulky �et�zc� a mat. v�raz�}
       end;
     end;

     tseznammatvyrazu=record
       pocet:integer;
       m:array[1..2]of tpostfix;
       d:array[1..2]of integer;
     end;

     tseznampouzitychnavesti=record
       pocet:integer;
       n:array[1..100]of record
         kod:integer; {kde je um�st�n odkaz}
         odkud,kam:integer; {z kter�ho p��kazu na kter� (kv�li rel. skoku)}
       end;
     end;

     tseznamprogrradku=record
       pocet:integer;
       r:array[1..100]of integer; {kde za��n� dan� bin. ��dek}
     end;

function gpl2kompiluj(var fi:text;
                      var vyslkod:pkod;
                      var seznret:pseznamretezcu;
                      pricistret:integer;
                      var seznpomret:pseznampomretezcu;
                      ident:pident; maxident:byte;
                      prik,talk:pprikaz):integer;
var nav:tseznamnavesti; {seznam v�ech n�v��t�}
    par:tseznamskutecnychparametru; {seznam skute�n� naspan�ch parametr�}
    mat:tseznammatvyrazu; {seznam mat. v�raz� v parametrech}
    zpracret:pseznamretezcu; {seznam pou�it�ch �et�zc� v parametrech
                              (�et�zce, identifik�tory, n�v��t�)}
    skok:tseznampouzitychnavesti;
    radky:tseznamprogrradku;

    ktery:pprikaz;
    ret:string;
    x:integer;
    chyba:integer;

function chcekonec(ret:string):boolean;
var ret1:string;
begin
  ret1:=slovo(ret);
  uppercase(ret1);
  chcekonec:=(ret1='ENDGPL')or(ret1='GPLEND');
end;

function syntslovo(var ret:string; var pokracovani:boolean):string;
var i,j:byte;
begin
  pokracovani:=false;
  if ret='' then begin
    syntslovo:='';
    exit;
  end;
  i:=1;
  syntslovo:='';
  if ret[1] in (cisla+['-']) then begin {��slo}
    if ret[1]='-' then
      i:=2;
    while (i<=length(ret))and(ret[i]in cisla) do
      inc(i);
  end else if ret[1] in znaky then {identifik�tor, v�. n�v��t�}
    while (i<=length(ret))and(ret[i]in znaky) do
      inc(i)
  else if ret[1]='(' then begin {matematick� v�raz}
    j:=1;
    i:=2;
    while (i<=length(ret))and(j<>0) do begin
      if ret[i]='(' then inc(j) else
      if ret[i]=')' then dec(j);
      inc(i);
    end;
    if j<>0 then begin {neukon�en� matematick� v�raz}
      chyba:=29;
      exit;
    end;
  end else if ret[1]='"' then begin {�et�zec}
    i:=2;
    while (i<=length(ret))and(ret[i]<>'"') do
      inc(i);
    inc(i); {a� za "}
  end else if ret[1]='\' then begin {pokra�ovac� znak}
    for i:=2 to length(ret) do {za t�m mus� b�t u� pouze meezery}
      if ret[i]<>' ' then begin
        chyba:=30;
        exit;
      end;
    pokracovani:=true;
    exit;
  end else if ret[1]=':' then begin {: za jm�nem p��kazu znamen� TALK}
    i:=2;
  end else begin {jinak je to nezn�m� syntaktick� objekt ---> chyba}
    chyba:=31;
    exit;
  end;

  syntslovo:=copy(ret,1,i-1); {p�ekop�rujeme nalezen� objekt}
  delete(ret,1,i-1); {a vyma�eme ho ze zdroje}
  oriznileve(ret); {op�t u��zneme lev� mezery}
end;

procedure prozkoumejparametry(ret:string; var par:tseznamskutecnychparametru);
var slov,ulozret{p�id�van� �et�zec}:string;
    retezec:integer; {0=��dn� �et�zec, jinak ��slo do skladu}
    x:byte;
    ch:integer;
    cis:longint;
    pomident:pident;
    pokracovani:boolean;
begin
  par.pocet:=0;
  retezec:=0; {aktu�ln� je otev�en �et�zec}
  {po��te�n� �et�zec byl p�ed�n}
  repeat

    repeat
      if retezec<>0 then begin {je-li rozpracov�n �et�zec, hled�me "}
        x:=pos('"',ret);
        if x=0 then begin
          slov:=ret;
          ret:='';
        end else begin
          slov:=copy(ret,1,x); {v�. posledn�ho "}
          delete(ret,1,x+1);
        end
      end else begin {jinak na�te dal�� objekt podle syntaktick�ch pravidel}
        slov:=syntslovo(ret,pokracovani);
        if chyba<>0 then
          exit;
      end;

      if slov='' then begin {konec ��dky}
        if (retezec=0)and not pokracovani then
        {nen� otev�en �et�zec a nepokra�uje ��dek p�es \ ---> konec p��kazu}
          exit
        else {je otev�en �et�zec}
          if not eof(fi) then begin {nen�-li konec vstupn�ho souboru}
            readln(fi,ret); {na�teme dal�� ��dek}
            oriznileve(ret);
{p��p. p��kaz na konec je te� parametr ---> ignoruje se a koment��e uvnit�
 p��kaz� je�t� nejsou do�e�eny}
          end else begin {jinak ohl�s�me chybu}
            chyba:=32;
            exit;
          end;
      end else
        break; {jinak jsme na�etli to, co cheme; O.K., done}
    until false;

    if (retezec=0)and(slov[1]='"') then begin {za��tek nov�ho �et�zce}
      inc(zpracret^.pocet);
      retezec:=zpracret^.pocet;
      inc(par.pocet);
      if par.pocet>maxparametru then begin
        chyba:=51;
        exit;
      end;
      par.p[par.pocet].typ:=2;
      par.p[par.pocet].podtyp:=255; {zat�m nev�me, zda je podtyp 1 nebo 2}
      par.p[par.pocet].hodn:=retezec;
      ulozret:='';
      delete(slov,1,1);
    end; {bude pokra�ovat dal��m IFem}

    if retezec<>0 then begin {pokra�ov�n� �et�zce}
      ulozret:=ulozret+slov;
      if slov[byte(slov[0])]='"' then begin
        dec(ulozret[0]);
        getmem(zpracret^.r[retezec],length(ulozret)+1);
        zpracret^.r[retezec]^:=ulozret;
        retezec:=0;
      end else
        ulozret:=ulozret+#13;
    end else begin {jinak je to nov� syntaktick� slovo (ident, cis, mat)}
      uppercase(slov);
      inc(par.pocet);
      if par.pocet>maxparametru then begin
        chyba:=51;
        exit;
      end;
      if slov[1]in cisla+['-'] then begin {je-li to ��slo}
        par.p[par.pocet].typ:=1;
        par.p[par.pocet].podtyp:=255;
        val(slov,cis,ch);
        if (ch<>0)or(cis<-maxint)or(cis>maxint) then begin
          chyba:=33;
          exit;
        end;
        par.p[par.pocet].hodn:=cis;
      end else if slov[1]in znaky then begin
      {identifik�tor, je�t� nebudeme hledat; je-li to jm�no p��kazu,
       zajist�me pozd�ji; te� to bude jenom identifik�tor}
        inc(zpracret^.pocet);
        retezec:=zpracret^.pocet;
        par.p[par.pocet].typ:=3;
        par.p[par.pocet].podtyp:=255;
        par.p[par.pocet].hodn:=retezec;
        getmem(zpracret^.r[retezec],length(slov)+1);
        zpracret^.r[retezec]^:=slov;
        retezec:=0;
        {ulo��me ho do seznamu �et�zc� a zaznamen�me si, �e to byl n�jak�
         identifik�tor}
      end else if slov[1]='(' then begin {matematick� v�raz}
        par.p[par.pocet].typ:=4;
        par.p[par.pocet].podtyp:=255;
        inc(mat.pocet);
        par.p[par.pocet].hodn:=mat.pocet;
        chyba:=mat2postfix(slov,ident,mat.m[mat.pocet],mat.d[mat.pocet]);
        if chyba<>0 then
          exit;
          {zkompiluje mat. v�raz a nastane-li chyba, ohl�s� to, jinak done}
      end else if slov[1]=':' then begin {: za jm�nem p��kazu znamen� TALK}
        if (par.pocet=2)and(par.p[1].typ=3) then begin
        {pokud je to ihned jako 2. parametr za identifik�torem,
         m� to tento spec. v�znam; zat�m ale nekontrolujeme ��dn� typy...}
          par.p[2]:=par.p[1]; {typ, podtyp, hodn}
          par.p[1].typ:=3; {zde d�me jm�no p��kazu TALK}
          par.p[1].podtyp:=255;
          inc(zpracret^.pocet);
          retezec:=zpracret^.pocet;
          par.p[1].hodn:=retezec;
          getmem(zpracret^.r[retezec],length(talk^.jm)+1);
          zpracret^.r[retezec]^:=talk^.jm;
          retezec:=0;
          {d�le se pokra�uje ve �ten� dal��ch parametr�; chov� se to, jako
           bychom napsali TALK <jm�no> m�sto <jm�no>:}
        end else begin {jinak je to chyba}
          chyba:=35;
          exit;
        end;
      end else begin {nezn�m� objekt, rad�i druh� kontrola}
        chyba:=36;
        exit;
      end;
    end;

  until false; {vysko�� se p�i nalezen� konce ��dku bez otev�en�ho �et�zce}
end;

procedure vyjmijmenoprikazu(var jmeno:string; var par:tseznamskutecnychparametru);
var x:byte;
begin
  if par.p[1].typ<>3 then begin {1. parametr nebyl identifik�tor p��kazu}
    chyba:=37;
    exit;
  end else begin {byl ---> nastav�me toto jm�no}
    jmeno:=zpracret^.r[par.p[1].hodn]^;
    dec(par.pocet); {vyma�eme 1. parametr + posuneme ostatn� parametry}
    for x:=1 to par.pocet do
      par.p[x]:=par.p[x+1];
  end;
end;

procedure osetriLABELS;
var x,y:byte;
    _ident:pident;
begin
  if radky.pocet<>1 then begin {p��kaz je dovolen jen na po��tku}
    chyba:=38;
    exit;
  end;
  for x:=1 to par.pocet do {zkontroluje v�echny parametry}
    if par.p[x].typ<>3 then begin
      chyba:=39;
      exit;
    end else begin
      _ident:=ident^.dalsi;
      while (_ident<>nil)and(_ident^.txt<>zpracret^.r[ par.p[x].hodn ]^) do
        _ident:=_ident^.dalsi;
      if _ident<>nil then begin {existuje stejn� identifik�tor}
        writeln(_ident^.txt);
        chyba:=40;
        exit;
      end;
    end;
  nav.pocet:=par.pocet;
  for x:=1 to par.pocet do begin {deklaruje tedy v�echna tato n�v��t�}
    nav.n[x].cislo:=0;
    nav.n[x].jm:=zpracret^.r[ par.p[x].hodn ]^;
    for y:=1 to x-1 do
      if nav.n[x].jm=nav.n[y].jm then begin
        chyba:=41;
        exit;
      end;
  end;
  dec(radky.pocet); {toto nebyl p��kaz, tak�e ho vyma�eme}
end;

procedure osetriLABEL;
var x:byte;
begin
  if (par.pocet<>1)or(par.p[1].typ<>3) then begin {po�aduje jedin� parametr}
    chyba:=42;
    exit;
  end;
  x:=1;
  while (x<=nav.pocet)and(nav.n[x].jm<>zpracret^.r[ par.p[1].hodn ]^) do
    inc(x);
  if x>nav.pocet then begin {nenalezeno n�v��t�}
    chyba:=43;
    exit;
  end;
  if nav.n[x].cislo<>0 then begin {u� bylo definov�no n�v��t�}
    writeln(nav.n[x].jm);
    chyba:=44;
    exit;
  end;
  nav.n[x].cislo:=radky.pocet; {jinak zap��eme ��slo ��dku}
  dec(radky.pocet);            {toto nebyl p��kaz, tak�e ho vyma�eme}
end;

function kteryprikaz(var jmeno:string; var par:tseznamskutecnychparametru):pprikaz;
var ktery:pprikaz;
    x:byte;
begin
  ktery:=prik^.dalsi;
  while ktery<>nil do begin
    if (ktery^.jm=jmeno)and(ktery^.pocpar=par.pocet) then begin
      x:=1;
      while (x<=par.pocet)and(par.p[x].typ=ktery^.par[x,1]) do
        inc(x);
      if x>par.pocet then begin {nalezen shodn� p��kaz}
        kteryprikaz:=ktery;
        exit;
      end;
    end;
    ktery:=ktery^.dalsi;
  end;
  kteryprikaz:=nil; {nenalezeno nic}
  chyba:=45;
end;

procedure pridejdokodu(_prik:pprikaz; var jmeno:string;
                       var par:tseznamskutecnychparametru);
var x,y:byte;
    _ident:pident;
begin
  inc(vyslkod^.delka); {zap��e se jm�no p��kazu}
  vyslkod^.k[vyslkod^.delka]:=_prik^.cis+_prik^.podcis shl 8;
  for x:=1 to par.pocet do
    if par.p[x].typ=1 then begin {��slo, pouze se p�id� do k�du}
      inc(vyslkod^.delka);
      vyslkod^.k[vyslkod^.delka]:=par.p[x].hodn;
    end else if par.p[x].typ=2 then begin {�et�zec, za�ad� se do 1 ze seznam�}
      inc(vyslkod^.delka);
      if _prik^.par[x,2]=1 then begin {st�l� �et�zec, p�id� se do seznamu}
        inc(seznret^.pocet);
        getmem(seznret^.r[seznret^.pocet],
          length(zpracret^.r[ par.p[x].hodn ]^)+1);
        seznret^.r[seznret^.pocet]^:=zpracret^.r[ par.p[x].hodn ]^;
        vyslkod^.k[vyslkod^.delka]:=seznret^.pocet+pricistret;
        {p�i�ten� kv�li nenaru�en� ��slov�n�, viz. interface}
      end else begin {jinak pomocn� �et�zec, p�id� se a zap��e odkaz sem}
        inc(seznpomret^.pocet);
        seznpomret^.r[seznpomret^.pocet].vyskyt:=vyslkod^.delka;
        seznpomret^.r[seznpomret^.pocet].cis:=_prik^.cis;
        seznpomret^.r[seznpomret^.pocet].podcis:=_prik^.podcis;
        seznpomret^.r[seznpomret^.pocet].par:=x;
        getmem(seznpomret^.r[seznpomret^.pocet].r,
          length(zpracret^.r[ par.p[x].hodn ]^)+1);
        seznpomret^.r[seznpomret^.pocet].r^:=zpracret^.r[ par.p[x].hodn ]^;
        vyslkod^.k[vyslkod^.delka]:=seznpomret^.pocet;
      end;
    end else if par.p[x].typ=3 then begin {identifik�tor, kontrola (i n�v��t�)}
      inc(vyslkod^.delka);
      _ident:=ident^.dalsi;
      while (_ident<>nil)and(_ident^.txt<>zpracret^.r[ par.p[x].hodn ]^) do
        _ident:=_ident^.dalsi;
      if _ident<>nil then begin {nalezen ---> identifik�tor}
        if _ident^.trida<>_prik^.par[x,2] then begin {li�� se typ ---> chyba}
          chyba:=46;
          exit;
        end;
        vyslkod^.k[vyslkod^.delka]:=_ident^.hodn;
        {jinak typ sed� ---> zap��eme jeho hodnotu}
      end else begin
        y:=1;
        while (y<=nav.pocet)and(nav.n[y].jm<>zpracret^.r[ par.p[x].hodn ]^) do
          inc(y);
        if y>nav.pocet then begin {nen� ani n�v��t� ---> nezn�m� identifik�tor}
          chyba:=47;
          exit;
        end;
        if _prik^.par[x,2]<>0 then begin {p��kaz nechce n�v��t� ---> chyba}
          chyba:=48;
          exit;
        end;
        {jinak zap��eme odkaz na nov� n�v��t�}
        vyslkod^.k[vyslkod^.delka]:=y; {��slo n�v��t�}
        inc(skok.pocet);
        skok.n[skok.pocet].kod:=vyslkod^.delka;
        skok.n[skok.pocet].kam:=y; {zde je zat�m jen ��slo n�v��t�}
        skok.n[skok.pocet].odkud:=radky.pocet;
      end;
    end else if par.p[x].typ=4 then begin {matematick� v�raz}
      inc(vyslkod^.delka);
      move(mat.m[par.p[x].hodn],vyslkod^.k[vyslkod^.delka],
        mat.d[par.p[x].hodn]*2*sizeof(integer)-2);
      inc(vyslkod^.delka,mat.d[par.p[x].hodn]*sizeof(integer)-1-1);
      {p�ekop�ruje matematick� v�raz do k�du
       posledn� 2 bajty (dv� nuly jsou zbyte�n� a nesm� tam v play3.asm b�t)}
    end else begin {jinak je to nesmysln� typ parametru ---> chyba}
      chyba:=49;
      exit;
    end;

end;

begin
  nav.pocet:=0;
  skok.pocet:=0;
  radky.pocet:=0;
  getmem(zpracret,sizeof(integer)+maxparametru*sizeof(pstring));
{  zpracret^.alok:=maxparametru;}
  chyba:=0;

  while not eof(fi) do begin
    readln(fi,ret);
    oriznileve(ret);
    if (ret='')or(ret[1]='{') then continue;
    if chcekonec(ret) then break;
    {jinak je to leg�ln� p��kaz}
    inc(radky.pocet);
    radky.r[radky.pocet]:=vyslkod^.delka+1; {kde za��n� dan� ��dek}
    mat.pocet:=0;
    par.pocet:=0;
    zpracret^.pocet:=0;
    prozkoumejparametry(ret,par);
    if chyba<>0 then begin
      gpl2kompiluj:=chyba;
      exit;
    end;
    vyjmijmenoprikazu(ret,par);
    if chyba<>0 then begin
      gpl2kompiluj:=chyba;
      exit;
    end;
    {nyn� je v ret jm�no p��kazu a v par seznam parametr�, u ka�d�ho je
     uveden pouze p�ibli�n� typ (1234), nic v�c!
     p��padn� p��kaz TALK ve dvojte�kov� notaci u� byl o�et�en}
    if ret='LABELS' then {deklaruje v�echny n�v��t�, lze pouze na za��tku}
      osetriLABELS
    else if ret='LABEL' then {definuje dal�� n�v��t�}
      osetriLABEL
    else begin
      ktery:=kteryprikaz(ret,par);
      if chyba<>0 then begin
        gpl2kompiluj:=chyba;
        exit;
      end;
      pridejdokodu(ktery,ret,par); {p�id� to do k�du a pr�b��n� zkontroluje parametry}
      if chyba<>0 then begin
        gpl2kompiluj:=chyba;
        exit;
      end;
    end;
    if chyba<>0 then begin
      gpl2kompiluj:=chyba;
      exit;
    end;
    {par nen� t�eba �istit}
    for x:=1 to zpracret^.pocet do {vy�ist�me zpracret}
      freemem(zpracret^.r[x], length(zpracret^.r[x]^)+1);
  end;

  inc(radky.pocet); {zap��eme konec posledn�ho p��kazu}
  inc(vyslkod^.delka); {a p��kaz EXIT}
  vyslkod^.k[vyslkod^.delka]:=0;
  radky.r[radky.pocet]:=vyslkod^.delka;

  for x:=1 to nav.pocet do
    if nav.n[x].cislo=0 then begin {nedefinovan� n�v��t�?}
      gpl2kompiluj:=50;
      exit;
    end;
  for x:=1 to skok.pocet do {p�ep��eme n�v��t� na skute�n� rel. skoky}
    vyslkod^.k[ skok.n[x].kod ]:=
      (radky.r[nav.n[skok.n[x].kam].cislo]-radky.r[skok.n[x].odkud+1])*2;
      {proto�e k�d je tvo�en integery}

  freemem(zpracret,sizeof(integer)+maxparametru*sizeof(pstring));

  gpl2kompiluj:=0;
end;

function nactiident_prik(var ident:pident; var maxident:byte;
                         var prik,talk:pprikaz):integer;
var x:integer;
begin
  x:=nactiidentifikatory(jmsoubident,ident,maxident);
  if x<>0 then begin
    nactiident_prik:=x;
    exit;
  end;
  x:=nactiprikazy(jmsoubprik,prik,talk, maxident);
  if x<>0 then begin
    nactiident_prik:=x;
    exit;
  end;
  nactiident_prik:=0; {jinak v�echno prob�hlo bez chyby}
end;

procedure dealokujident_prik(var ident:pident; var prik:pprikaz);
begin
  dealokujprikazy(prik);
  prik:=nil;
  dealokujidentifikatory(ident);
  ident:=nil;
end;

end.

{todo: mo�n� vynutit = v p��kazu LET, te� to chod� nezn�m� syntaktick� objekt!
       lep�� rozp�len� ��dku (i uprost�ed mat. v�razu)
       zav�st koment��e i uprost�ed ��dku (a� do konce ��dku)
       while(length(ret)) ulo�it si length!
       bacha na p�ete�en�, �e n��eho bylo p�ed�no moc a my to furt ukl�d�me
       ignorovat lev� a prav� mezery nejenom u parametr�, ale i uvnit�
       �et�zce!
       a� chybov� hl��ky hl�s� p�esn� popis jako v k3}
