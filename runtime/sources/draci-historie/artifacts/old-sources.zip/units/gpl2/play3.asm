;PP: pridan jeden zapomenuty ret na konec procedury fce_logickyoperator
;PP: opravena tataz funkce, podle Roberta konvertovala vsechno na False!

;zm�ny:
;1) opraveny p��kazy o 0 parametrech
;2) playgpl3 si nenastavuje adresu prom�nn�ch
;3) vyhodnocova� mat. v�raz� je zvl���
;4) vyhodnocova� d�l� stejn� s ��sly a prom�nn�mi, ale funkce �te z tabulky
;   stejn� jako p��kazy a zavol� je a oper�tory �te rovn�� z takov� tabulky
;   a taky je zavol�
;5) jsou dob�e implementov�ny logick� operace, byly p�id�ny aritmetick�
;6) odlad�no vol�n� vypocetmatvyrazu vn� i vevnit� stejn� jako playgpl3

;todo: mat2bin mus� d�t na konec jednu 0, ne 2
;execinit ---> exec init
;mo�n� ud�lat samomodifikuj�c� se k�d (zrychl� se to...)
;pou��vat es:di v playgpl3!

;d�le�it�!
;indexy do kodu jsou integerove ---> zde odecist 1 a vynasobit 2
;relativni skoky v kodu jsou bajtove (od GPL) ---> pouze pricist
;��sla do prom�nn�ch jsou taky integer ---> odecist 1 a vynasobit 2
;pam�� mus� b�t nastavena takto, jinak to blbne
;nelze uv�d�t dataptr (to jsou 2b), ale word:2 (to jsou 4b)
;retf a retn jsou instrukce, ret je makro ---> s parametry pou��vat jeho!
;nezapomenout na dec si, kdy� to d�m do play05.pas!
;+p�i vol�n� mat. v�razu p�edat 1, ne 0

.286c

model small,pascal

public VypocetMatVyrazu                         ;vyv���me tyto 2 FAR rutiny
public PlayGPL3

;RelativniGPLSkok asi nejde definovat zde a pou��t v Pascalu,
;jako zp�tnou hodnotu funkce ho d�lat nechci, tak�e bude definov�n mimo :-(
extrn RelativniGPLSkok
extrn GPLUkoncitProgram

extrn F_Random                                  ;dov��en� NEAR funkce
extrn F_IsIcoOn
extrn F_IsIcoAct
extrn F_IcoStat
extrn F_ActIco
extrn F_IsObjOn
extrn F_IsObjOff
extrn F_IsObjAway
extrn F_ObjStat
extrn F_LastBlock
extrn F_AtBegin
extrn F_BlockVar
extrn F_HasBeen
extrn F_MaxLine
extrn F_ActPhase
extrn F_Cheat

extrn C_Load                                    ;dov��en� NEAR procedury
extrn C_Start
extrn C_StartPlay
extrn C_JustTalk
extrn C_JustStay
extrn C_StayOn
extrn C_WalkOn
extrn C_WalkOnPlay
extrn C_ObjStat
extrn C_ObjStat_On
extrn C_IcoStat
extrn C_RepaintInventory
extrn C_ExitInventory
extrn C_NewRoom
extrn C_Talk
extrn C_Let
extrn C_ExecInit
extrn C_ExecLook
extrn C_ExecUse
extrn C_goto
extrn C_if
extrn C_Dialogue
extrn C_ExitDialogue
extrn C_ResetDialogue
extrn C_ResetDialogueFrom
extrn C_ResetBlock
extrn C_ExitMap
extrn C_LoadPalette
extrn C_SetPalette
extrn C_BlackPalette
extrn C_FadePalette
extrn C_FadePalettePlay
extrn C_LoadMusic
extrn C_StartMusic
extrn C_StopMusic
extrn C_FadeOutMusic
extrn C_FadeInMusic
extrn C_Mark
extrn C_Release
extrn C_Play
extrn C_LoadMap
extrn C_RoomMap
extrn C_DisableQuickHero
extrn C_EnableQuickHero
extrn C_DisableSpeedText
extrn C_EnableSpeedText
extrn C_QuitGame
extrn C_PopNewRoom
extrn C_PushNewRoom
extrn C_ShowCheat
extrn C_HideCheat
extrn C_ClearCheat
extrn C_FeedPassword

.code

VypocetMatVyrazu proc far
                 arg vyraz:word:2,index,promenne:word:2
                 local puvds

                 push es si di bx cx dx         ;zap��eme si v�echno
                 mov ss:word ptr puvds,ds       ;zap��eme si ds pro vol�n� fc�

                 mov si,ss:word ptr index       ;start je od 1, hlavi�ka u� nen�
                 dec si                         ;index je zad�n v integerech
                 shl si,1
                 add si,ss:word ptr vyraz       ;p�idej offset �ten� k�du
                 mov ds,ss:word ptr vyraz+2
                 mov di,ss:word ptr promenne    ;vezmeme adresu v�razu
                 mov es,ss:word ptr promenne+2
                 xor bx,bx                      ;d�lka Stacku je 0

dalsi_mat_objekt:
                 lodsw                          ;na�teme dal�� objekt mat. v�razu
                 or ax,ax                       ;konec?
                 jz konec_mat_vyrazu
                 cmp ax,1                       ;��slo?
                 je obj_cislo
                 cmp ax,2                       ;oper�tor?
                 je obj_oper
                 cmp ax,3                       ;funkce?
                 je obj_fce
                 cmp ax,4                       ;identifik�tor prom�nn�?
                 je obj_prom
                 jmp obj_cislo
                 ;jinak je to identifik�tor objektu, kter� se bere jako ��slo

konec_mat_vyrazu:
                 mov ax,si                      ;kolik jsme p�e�etli bajt�?
                 sub ax,ss:word ptr vyraz
                 pop dx cx bx di si es          ;obnov�me v�echno
                 mov ds,ss:word ptr puvds       ;v�. ds
                 add si,ax                      ;posuneme si o p�e�ten� po�et
                 mov ax,cs:word ptr poststack   ;vr�t�me hodnotu
                 ret                            ;konec rutiny
                 ;0 na konci u� se neodstra�uje

VypocetMatVyrazu endp

obj_cislo:                                      ;do�lo n�m ��slo
                 lodsw                          ;vezmeme a PUSHneme hodnotu
                 mov cs:word ptr [poststack+bx],ax
                 add bx,2
                 jmp dalsi_mat_objekt

obj_prom:                                       ;prom�nn�
                 lodsw                          ;vz�t ��slo
                 dec ax                         ;p�ev�st na index
                 shl ax,1
                 add di,ax
                 mov dx,es:word ptr di          ;na��st hodnotu
                 sub di,ax
                 mov cs:word ptr [poststack+bx],dx ;ulo�it do stacku
                 add bx,2
                 jmp dalsi_mat_objekt

obj_fce:                                        ;vol�n� funkce?
                 lodsw                          ;��slo funkce
                 push ds es si di bx cx dx      ;PUSHneme registry
                 dec ax                         ;p�evedeme na index
                 shl ax,1
                 push cs:word ptr [poststack+bx-2] ;ulo��me p�edanou hdonotu

                 mov ds,ss:word ptr puvds       ;obnov�me ds
                 mov bx,ax                      ;zavol�me funkci
                 call cs:word ptr [volejfce+bx]

                 mov ds,ss:word ptr vyraz+2     ;obnov�me si ds
                 pop dx cx bx di si es ds       ;POPneme registry
                 mov cs:word ptr [poststack+bx-2],ax ;ulo��me vr�cenou hodnotu
                 jmp dalsi_mat_objekt

obj_oper:                                       ;vol�n� oper�toru?
                 lodsw                          ;na�ti ��slo oper�toru
                 push si
                 mov si,ax                      ;p�evedeme ��slo na index
                 dec si
                 shl si,1
                 sub bx,2                       ;sn���me po��tadlo postfixu
                 mov ax,cs:word ptr [poststack+bx-2] ;zap��eme operandy
                 push bx
                 mov bx,cs:word ptr [poststack+bx]
                 call cs:word ptr [volejoper+si] ;zavol�me dan� oper�tor
                 pop bx si
                 mov cs:word ptr [poststack+bx-2],ax ;zap��eme v�sledek
                 jmp dalsi_mat_objekt

;m�sto pro postfixov� vyhodnocova�, 1 je zrovna proto :)))
poststack        dw 50 dup(1)

;adresa volan�ch funkc�, zat�m je tam pouze not a random
volejfce         dw offset fce_not
                 dw offset F_Random
                 dw offset F_IsIcoOn
                 dw offset F_IsIcoAct
                 dw offset F_IcoStat
                 dw offset F_ActIco
                 dw offset F_IsObjOn
                 dw offset F_IsObjOff
                 dw offset F_IsObjAway
                 dw offset F_ObjStat
                 dw offset F_LastBlock
                 dw offset F_AtBegin
                 dw offset F_BlockVar
                 dw offset F_HasBeen
                 dw offset F_MaxLine
                 dw offset F_ActPhase
		 dw offset F_Cheat

;adresa volan�ch oper�tor�
volejoper        dw offset oper_and
                 dw offset oper_or
                 dw offset oper_xor
                 dw offset oper_rovno
                 dw offset oper_ruzno
                 dw offset oper_mensi
                 dw offset oper_vetsi
                 dw offset oper_mensirovno
                 dw offset oper_vetsirovno
                 dw offset oper_krat
                 dw offset oper_deleno
                 dw offset oper_zbytek
                 dw offset oper_plus
                 dw offset oper_minus

fce_not proc near                       ;funkce vracej�c� logick� not
             arg cislo                  ;nelze vyvolat instrukci not
             mov ax,cislo
             or ax,ax
             jz not_nulove
             mov ax,1
not_nulove:
             xor ax,1
             ret
fce_not endp

fce_logickyoperator proc near           ;provede korekci obou cisel na bool
             or ax,ax                   ;0--->0, jine cislo--->1
             jz log_nuloveax
             mov ax,1
log_nuloveax:
             or bx,bx                   ;tady bylo navic: xor ax,1 ...
             jz log_nulovebx
             mov bx,1
log_nulovebx:
             ret                        ;tady xor bx,1 ...
fce_logickyoperator endp

oper_and proc near                      ;ud�l� logick� and
              call fce_logickyoperator
              and ax,bx
              ret
oper_and endp

oper_or proc near                       ;ud�l� logick� or
              call fce_logickyoperator
              or ax,bx
              ret
oper_or endp

oper_xor proc near                      ;ud�l� logick� xor
              call fce_logickyoperator
              xor ax,bx
              ret
oper_xor endp

oper_vysledek1:                         ;u komparace nastav� v�sledek 1
              mov ax,1
              retn

oper_vysledek0:                         ;u komparace nastav� v�sledek 0
              xor ax,ax
              retn

oper_rovno proc near
           cmp ax,bx
           je oper_vysledek1
           jmp oper_vysledek0
oper_rovno endp

oper_ruzno proc near
           cmp ax,bx
           jne oper_vysledek1
           jmp oper_vysledek0
oper_ruzno endp

oper_mensi proc near
           cmp ax,bx
           jl oper_vysledek1
           jmp oper_vysledek0
oper_mensi endp

oper_vetsi proc near
           cmp ax,bx
           jg oper_vysledek1
           jmp oper_vysledek0
oper_vetsi endp

oper_mensirovno proc near
           cmp ax,bx
           jle oper_vysledek1
           jmp oper_vysledek0
oper_mensirovno endp

oper_vetsirovno proc near
           cmp ax,bx
           jge oper_vysledek1
           jmp oper_vysledek0
oper_vetsirovno endp

oper_krat proc near
          imul bx                        ;dx se zanedba
          ret
oper_krat endp

oper_deleno proc near
          xor dx,dx
          idiv bx                        ;pod�l je v ax
          ret
oper_deleno endp

oper_zbytek proc near
          xor dx,dx
          idiv bx                        ;zbytek je v dx
          mov ax,dx
          ret
oper_zbytek endp

oper_plus proc near
          add ax,bx
          ret
oper_plus endp

oper_minus proc near
          sub ax,bx
          ret
oper_minus endp

;****************************************************************************

PlayGPL3 proc far
         arg kod:word:2,start:word,promenne:word:2      ;dataptr n�jak nefach�
         local puvds,uchovsi

         pusha                          ;ulo�� se v�echno
         push es
         mov ss:word ptr puvds,ds       ;ulo��me si je�t� ds

         mov si,ss:word ptr start       ;start je od 1, hlavi�ka u� nen�
         dec si                         ;index je zad�n v integerech
         shl si,1
         add si,ss:word ptr kod         ;p�idej offset �ten� k�du
         mov ds,ss:word ptr kod+2
;es:di je volno, proto�e R/W prom�nn�ch zde nepot�ebuji
;ds:si (�ten� programu a mat. v�razu)
;�ten� masek p��kaz� je adresov�no p�es cs:[bx+offset]
;vyhodnocova� postfix� pracuje tak� p�es cs:[bx+offset], bx se PUSHne
;do z�sobn�ku se po registrech postupn� ukl�daj� parametry, ale v postfixu
;mohu PUSHovat, nebo� se to pak na jeho konci zase obnov�...

cteni_prikazu:
         lodsw                          ;na�ti ��slo prov�d�n�ho p��kazu
         or al,al
         jnz ne_konec                   ;0=p��kaz na konec
         jmp konec
ne_konec:
         mov dx,ax                      ;zaznamenej ��slo p��kazu
         xor bx,bx                      ;�teme nyn� podporovan� p��kazy
cteni_predlohy:
         mov ax,word ptr cs:[volejproc+bx]  ;na�ti ��slo dal��ho p��kazu
         or ax,ax                       ;0=konec seznamu
         jnz ne_konec_predlohy
         jmp konec                      ;nena�li jsme ---> chyba!
ne_konec_predlohy:
         mov cx,word ptr cs:[volejproc+bx+2];na�ti po�et parametr� p��kazu
         add bx,2+2                     ;budeme mo�n� ��st parametry
         cmp ax,dx                      ;je to n�� p��kaz?
         je zpracuj_prikaz              ;ano ---> zpracujeme ho
         add bx,cx                      ;ne ---> p�esko��me parametry
         add bx,2                       ;a offset rutiny
         jmp short cteni_predlohy       ;a zkus�me dal�� p��kaz

;v cx je po�et parametr�, bx je na 1. parametru rutiny
;pro pozd�j�� zavol�n� si te� PUSHneme registry, pak p�ijdou na �adu parametry
zpracuj_prikaz:
         push ds bx cx dx

zpracuj_parametr:
         or cx,cx                       ;kolik zb�v� parametr�?
         jz spust_prikaz                ;0 ---> spust�me p��kaz
         dec cx                         ;dekrementace po��tadla
         mov al,byte ptr cs:[volejproc+bx]  ;vezmeme typ parametru
         inc bx
         cmp al,4                       ;je to matematick� v�raz?
         jne parametr_cislo
         push ds                        ;p�ed�me adresu v�razu
         push si
         push 1                         ;0 je p�i��tan� index
         push ss:word ptr promenne+2    ;adresa prom�nn�ch
         push ss:word ptr promenne
         mov ds,ss:word ptr puvds       ;obnov�me rutin� ds
         call VypocetMatVyrazu          ;FAR vol�n�
           ;a zavol�me na to rutinu: tyto 3 parametry vybere ze z�bon�ku,
           ;v�sledek vr�t� v ax, v�echny registry nech� netknuty (je to fce)
           ;si posune za konec mat. v�razu
         mov ds,ss:word ptr kod+2       ;obnov�me si ds
         push ax                        ;ulo��me vr�cenou hodnotu
         jmp short zpracuj_parametr     ;a sko��me na dal�� parametr
parametr_cislo:
         lodsw                          ;jinak na�teme hodnotu
         push ax                        ;ulo��me do z�sobn�ku
         jmp short zpracuj_parametr     ;a sko��me na dal�� parametr

;nyn� jsou v�echny registry PUSHnuty a parametry p�ed�ny jako integer
;bx n�m ukazuje na offset rutiny
spust_prikaz:
         mov ds,ss:word ptr puvds       ;obnov�me pro zavol�n� DS
         mov ds:word ptr RelativniGPLSkok,0      ;vynulujeme po��tadlo skok�
         mov ds:word ptr GPLUkoncitProgram,0     ;program b��� d�l
         mov ss:word ptr uchovsi,si     ;ulo��me sob� je�t� si
         call cs:word ptr [volejproc+bx]         ;zavol�me danou rutinu
         mov ax,ds:word ptr RelativniGPLSkok     ;na�te po��tadlo skok�
         mov si,ss:word ptr uchovsi     ;obnov� je�t� si
         add si,ax                      ;sko�� dan� skok
         mov ax,ds:word ptr GPLUkoncitProgram
         pop dx cx bx ds                ;obnov� v�echny registry
         or ax,ax                       ;nem� se ukon�it prov�d�n� p��kazu?
         jnz konec
         jmp cteni_prikazu              ;p�e�te dal�� p��kaz

;konec p�i p��kazu 0 nebo nezn�m�m p��kazu:
konec:
         mov ds,ss:word ptr puvds       ;obnov�me si ds
         pop es                         ;obnov� se v�echno
         popa
         ret                            ;konec rutiny

PlayGPL3 endp

;data jsou v code segmentu kv�li sna���mu odkazov�n� se:

;ulo�en� vol�n� procedur:
;0              integer --- ��slo (AL) a pod��slo (AH) p��kazu
;               AX=0 je konec
;2              integer --- po�et parametr�, int kv�li lehk�mu �ten�
;4.--Po�etPar+3 byte --- parametry (oznamuje se typ 1234)
;               123=p�ed� se integer ��slo
;               4=vyhodnot� se matematick� v�raz, dokud se nenaraz� na 0
;                 ten identifik�toru bere jako ��sla, pouze prom�nn�
;                 vyhodnot�, funkce zavol�
;Po�etPar+4     integer --- NEAR ukazatel na proceduru

VolejProc  db 5,1       ;prikaz cislo 4-1
       dw 2         ;pocet parametru, DW!!!
       db 3,2       ;seznamy parametru
       dw offset C_Load

       db 4,1       ;prikaz cislo 5-1
       dw 2         ;pocet parametru, DW!!!
       db 3,2       ;seznamy parametru
       dw offset C_Start

       db 5,2       ;prikaz cislo 5-2
       dw 2         ;pocet parametru, DW!!!
       db 3,2       ;seznamy parametru
       dw offset C_StartPlay

       db 5,3
       dw 0
       dw offset C_JustTalk

       db 5,4
       dw 0
       dw offset C_JustStay

       db 10,2      ;prikaz cislo 10-2
       dw 3         ;pocet parametru, DW!!!
       db 1,1,3     ;seznamy parametru
       dw offset C_StayOn

       db 10,1      ;prikaz cislo 10-1
       dw 3         ;pocet parametru, DW!!!
       db 1,1,3     ;seznamy parametru
       dw offset C_WalkOn

       db 10,3      ;prikaz cislo 10-3
       dw 3         ;pocet parametru, DW!!!
       db 1,1,3     ;seznamy parametru
       dw offset C_WalkOnPlay


       db 7,1       ;prikaz cislo 7-1
       dw 2         ;pocet parametru, DW!!!
       db 3,3       ;seznamy parametru
       dw offset C_ObjStat

       db 7,2       ;prikaz cislo 7-2
       dw 2         ;pocet parametru, DW!!!
       db 3,3       ;seznamy parametru
       dw offset C_ObjStat_On

       db 8,1       ;prikaz cislo 8-1
       dw 2         ;pocet parametru, DW!!!
       db 3,3       ;seznamy parametru
       dw offset C_IcoStat

       db 14,1      ;prikaz cislo 14-1
       dw 2         ;pocet parametru, DW!!!
       db 3,1       ;seznamy parametru
       dw offset C_NewRoom

       db 6,1       ;prikaz cislo 6-1
       dw 2         ;pocet parametru, DW!!!
       db 3,2       ;seznamy parametru
       dw offset C_Talk

       db 2,1       ;prikaz cislo 2-1
       dw 2         ;pocet parametru, DW!!!
       db 3,4       ;seznamy parametru
       dw offset C_Let

       db 15,1      ;prikaz cislo 15-1
       dw 1         ;pocet parametru, DW!!!
       db 3         ;seznamy parametru
       dw offset C_ExecInit

       db 15,2      ;prikaz cislo 15-2
       dw 1         ;pocet parametru, DW!!!
       db 3         ;seznamy parametru
       dw offset C_ExecLook

       db 15,3      ;prikaz cislo 15-2
       dw 1         ;pocet parametru, DW!!!
       db 3         ;seznamy parametru
       dw offset C_ExecUse

       db 16,1      ;prikaz cislo 16-1
       dw 0         ;pocet parametru, DW!!!
       dw offset C_RepaintInventory

       db 16,2      ;prikaz cislo 16-2
       dw 0         ;pocet parametru, DW!!!
       dw offset C_ExitInventory

       db 1,1
       dw 1
       db 3
       dw offset C_goto

       db 3,1
       dw 2
       db 4,3
       dw offset C_if

       db 9,1       ;prikaz cislo 9-1
       dw 1         ;pocet parametru, DW!!!
       db 2         ;seznamy parametru
       dw offset C_Dialogue

       db 9,2       ;prikaz cislo 9-2
       dw 0         ;pocet parametru, DW!!!
       dw offset C_ExitDialogue

       db 9,3       ;prikaz cislo 9-3
       dw 0         ;pocet parametru, DW!!!
       dw offset C_ResetDialogue

       db 9,4       ;prikaz cislo 9-4
       dw 0         ;pocet parametru, DW!!!
       dw offset C_ResetDialogueFrom

       db 9,5
       dw 1
       db 3
       dw offset C_ResetBlock

       db 11,1
       dw 1
       db 2
       dw offset C_LoadPalette

       db 12,1
       dw 0
       dw offset C_SetPalette

       db 12,2
       dw 0
       dw offset C_BlackPalette

       db 13,1
       dw 3
       db 1,1,1
       dw offset C_FadePalette

       db 13,2
       dw 3
       db 1,1,1
       dw offset C_FadePalettePlay

       db 17,1      ;prikaz cislo 17-1
       dw 0         ;pocet parametru, DW!!!
       dw offset C_ExitMap

       db 18,1
       dw 1
       db 2
       dw offset C_LoadMusic

       db 18,2
       dw 0
       dw offset C_StartMusic

       db 18,3
       dw 0
       dw offset C_StopMusic

       db 18,4
       dw 1
       db 1
       dw offset C_FadeOutMusic

       db 18,5
       dw 1
       db 1
       dw offset C_FadeInMusic

       db 19,1
       dw 0
       dw offset C_Mark

       db 19,2
       dw 0
       dw offset C_Release

       db 20,1
       dw 0
       dw offset C_Play

       db 21,1
       dw 1
       db 2
       dw offset C_LoadMap

       db 21,2
       dw 0
       dw offset C_RoomMap

       db 22,1
       dw 0
       dw offset C_DisableQuickHero

       db 22,2
       dw 0
       dw offset C_EnableQuickHero

       db 23,1
       dw 0
       dw offset C_DisableSpeedText

       db 23,2
       dw 0
       dw offset C_EnableSpeedText

       db 24,1
       dw 0
       dw offset C_QuitGame

       db 25,1
       dw 0
       dw offset C_PushNewRoom

       db 25,2
       dw 0
       dw offset C_PopNewRoom

       db 26,1
       dw 0
       dw offset C_ShowCheat

       db 26,2
       dw 0
       dw offset C_HideCheat

       db 26,3
       dw 1
       db 1
       dw offset C_ClearCheat

       db 27,1
       dw 3
       db 1,1,1
       dw offset C_FeedPassword

       dw 0         ;konec t�chto dat

end
