.286c

delkay          equ     200             ;y-ovy rozmer obrazovky
delkabuf        equ     delkay*2*2*4    ;delka bufferu

model large,pascal

codeseg

extrn ActiveAddrPage:word
public FloodFill
public Circle
public Line
public XorLine





;vyplnovani uzavrenych oblasti, pro buffer pouziva lokalni promennou v SS
FloodFill proc far
          arg X:word,Y:word,Cim:byte,Hranice:byte
          uses ds,es,si,di,ax,bx,cx,dx
          ;algoritmus + cx a dx v procedure zapis (cx i v init tady)
          local addrpage:word,buf:word:delkabuf
          ;lokalni promenne na zasobniku

          mov       ax,ds:[ActiveAddrPage]      ;kreslici stranka (pamatovat,
          mov       addrpage,ax                   ;nebudeme znat ds)

          push      ss                          ;ds,es:=ss pro retez.instr.
          pop       ds                            ;(buffer a addrpage jsou
          push      ss                            ;totiz lok. prom. a jsou
          pop       es                            ;tedy na zasobniku)

          mov       si,bp                       ;inicializuj cteci a zapiso-
          sub       si,delkabuf                   ;vaci hlavu na zacatek
          mov       di,si                         ;bufferu
          cld                                   ;retezce jdou dopredu

          mov       ax,x                        ;nacte si ty 2 body
          mov       bx,y

          call      floodzapis
          ;zapise bod na x=ax a y=bx s tim, ze zkontroluje
          ;barvu cim a hranice a zapise to do pole jako dalsiho souseda

vyplnovani:
          cmp       si,bp                       ;osetri preteceni bufferu
          jne       nepretekl
          sub       si,delkabuf                 ;pretekl-li, na zacatek
nepretekl:

          cmp       si,di                       ;otestuj prazdnost bufferu
          je        konecvyplne                   ;ano, konec

          ;nacti 1. bod z bufferu
          lodsw                                 ;nacti y do bx
          mov       bx,ax
          lodsw                                 ;nacti x do ax

          ;nyni projdi jeho sousedy
          dec       bx                          ;horni soused
          cmp       bx,0
          jl        hornkon
          call      floodzapis
hornkon:
          add       bx,2                        ;dolni soused
          cmp       bx,199
          jg        dolnkon
          call      floodzapis
dolnkon:
          dec       bx                          ;levy soused
          dec       ax
          cmp       ax,0
          jl        levykon
          call      floodzapis
levykon:
          add       ax,2                        ;pravy soused
          cmp       ax,319
          jg        pravkon
          call      floodzapis
pravkon:                                        ;opakuj cyklus
          jmp       short vyplnovani

konecvyplne:
          ret                                   ;sem se skoci pro konec
FloodFill endp

floodzapis proc near
      ;souradnice bodu jsou x=ax a y=bx
      ;zkontroluje, zda tam neni barva vyplne nebo hranice a pokud ne,
      ;vyplni to barvou vyplne a zaradi na konec bufferu
          uses es,si,ax,bx
               ;es - segment retezce, zde adresara VideoRam
               ;si - cteci hlava bufferu, zde pro vypocet adresy

          stosw                                 ;ulozi x tam, kde ma byt y
          stosw                                 ;ulozi x spravne
          mov       es:[di-4],bx                ;ulozi y spravne
          ;predpokladam, ze se to podari a zapisu pozici do bufferu ihned,
          ;protoze se mi souradnice casem z registru ztrati

          mov       cx,ax                       ;uchovej pozici x
          mov       ax,0A000h                   ;segment VRAM
          mov       es,ax

          mov       si,addrpage                 ;dej offset VRAM

          mov       ax,80                       ;ktery radek
          mul       bx
          add       si,ax

          mov       dx,cx                       ;pridej znak k offsetu
          shr       dx,2
          add       si,dx

          and       cl,3                        ;vezmi cislo stranky

          ;cteni znaku podle nastavenych portu
          mov       ah,cl                       ;pozadavek prepnuti stranky
          mov       dx,3CEh                       ;pro cteni
          mov       al,4
          out       dx,al
          inc       dx                          ;kterou stranku
          mov       al,ah
          out       dx,al

          mov       al,byte ptr es:[si]         ;nacteni bodu

          cmp       al,cim                      ;je-li shodny s barvou
          je        neuspech                      ;vyplne nebo hranice,
          cmp       al,hranice                    ;konec
          je        neuspech

          ;nyni musime vykreslit na obrazovku novy bod
          mov       ah,1                        ;pozadavek prepnuti stranky
          shl       ah,cl                         ;pro zapis
          mov       dx,3C4h
          mov       al,2
          out       dx,al

          inc       dx                          ;ktera stranka
          mov       al,ah
          out       dx,al

          mov       al,cim                      ;vypis novy bod
          mov       byte ptr es:[si],al

          ;nyni pouze zkontrolujeme, zda uz posunuta zapisova hlava bufferu
          ;nepretekla pres konec
          cmp       di,bp                       ;osetri preteceni bufferu
          jne       koneczapisu
          sub       di,delkabuf                 ;pretekl-li, na zacatek
          jmp       short koneczapisu

neuspech:                                       ;je-li neuspech, nezapise se
          sub       di,4                          ;nic, vrat zapis. hlavu

koneczapisu:
          ret
floodzapis endp





;circle celociselnym algoritmem Martina Marese (opsano z knizky od Grady :
;Grafika - principy a algoritmy z jejich doprovodne diskety)
Circle proc far
     arg X:word,Y:word,R:word, Barva:byte
          uses ax,bx,cx,dx,si,es

          mov       ax,0A000h           ;es=segment VRAM
          mov       es,ax

          mov       ax,0
          mov       bx,r
          mov       si,1
          sub       si,bx
          mov       cx,3
          mov       dx,bx
          shl       dx,1
          sub       dx,2
_repeat:
          call      circlekreslisymetrickebody
          cmp       si,0
          jl        nenipoklesy
          sub       si,dx
          sub       dx,2
          dec       bx
nenipoklesy:
          add       si,cx
          add       cx,2
          inc       ax

          cmp       ax,bx
          jle       _repeat

          ret
Circle endp

circlekreslisymetrickebody proc near
;          uses cx,dx
          push cx
          push dx
          mov       cx,x
          mov       dx,y

          add       cx,ax
          add       dx,bx
          call      circlevypisbod

          sub       cx,ax
          sub       cx,ax
          call      circlevypisbod
          add       cx,ax
          add       cx,ax
          sub       dx,bx
          sub       dx,bx
          call      circlevypisbod
          sub       cx,ax
          sub       cx,ax
          call      circlevypisbod

          add       cx,ax
          add       dx,bx

          add       cx,bx
          add       dx,ax
          call      circlevypisbod

          sub       cx,bx
          sub       cx,bx
          call      circlevypisbod
          add       cx,bx
          add       cx,bx
          sub       dx,ax
          sub       dx,ax
          call      circlevypisbod
          sub       cx,bx
          sub       cx,bx
          call      circlevypisbod

          pop dx
          pop cx
          retn
circlekreslisymetrickebody endp

circlevypisbod proc near
         ;souradnice v cx a dx
          uses ax,bx,cx,dx,si

          ;nezmenena rutina z line (ona to taky bere z cx,dx a nici a-dx+si)
          mov       si,ds:ActiveAddrPage;dej offset VRAM

          mov       ax,80               ;ktery radek
          mul       dx
          add       si,ax
          mov       dx,cx               ;zachovej sloupec
          shr       dx,2
          add       si,dx               ;pridej sloupec k offsetu

          and       cl,3                ;vezmi cislo stranky ze sloupce
          mov       ah,1                ;pozadavek prepnuti stranky
          shl       ah,cl                 ;pro zapis
          mov       dx,3C4h
          mov       al,2
          out       dx,al
          inc       dx                  ;ktera stranka
          mov       al,ah
          out       dx,al

          mov       al,barva            ;vypis konecne bod cary
          mov       es:[si],al

          ret
circlevypisbod endp





;kresleni usecky mnou vylepsenym algoritmem, ktery skoro bez IFu zvladne
;pomoci 1 slozeneho cyklu vsechny kvadranty pro uhly <,=,>45 stupnu
;je to linearni celociselny vzorkovaci algoritmus
Line proc far
     arg X1:word,Y1:word,X2:word,Y2:word, Barva:byte
          uses ax,bx,cx,dx,si,di,es

          mov       ax,0A000h           ;es=segment VRAM
          mov       es,ax

          mov       ax,x2               ;ax=abs(x2-x1) a dl=smerx
          sub       ax,x1
          jge       vetsi1
          mov       dl,0
          neg       ax
          jmp       short _1
vetsi1:
          mov       dl,1
_1:

          mov       bx,y2               ;bx=abs(y2-y1) a dh=smery
          sub       bx,y1
          jge       vetsi2
          mov       dh,0
          neg       bx
          jmp       short _2
vetsi2:
          mov       dh,1
_2:

          xor       si,si               ;pocitadlo pozice x=si=i a y=di=j
          xor       di,di

          xor       cx,cx               ;cx=pocitadlo preteceni

cyklus:                                 ;for j:=0 to y
          add       cx,ax               ;inc(poc,x)
          call      linevypisbod        ;putpixel(x1+i*smerx,y1+j*smery,barva)
          cmp       cx,bx               ;if poc>=y
          jl        dalsi               ;ne - nic
                                        ;ano - pokracuj
          sub       cx,bx               ;dec(poc,y)
          inc       si                  ;inc(i)
_while:                                 ;while (poc>=y)and(i<=x)
          cmp       cx,bx               ;poc<y ===> konec
          jl        dalsi
          cmp       si,ax               ;i>x   ===> konec
          jg        dalsi
          call      linevypisbod        ;putpixel(x1+i*smerx,y1+j*smery,barva)
          sub       cx,bx               ;dec(poc,y)
          inc       si                  ;inc(i)
          jmp       short _while        ;===> while

dalsi:
          inc       di                  ;for : zvys j
          cmp       di,bx               ;for : otestuj horni mez
          jle       cyklus              ;ano, jeste jednou

          ret                           ;jinak konec
Line endp

linevypisbod proc near
          ;putpixel(x1+i*smerx,y1+j*smery,barva)
          uses ax,bx,cx,dx,si

          cmp       dl,1                ;smerx=1 ?
          je        _sx1
          mov       cx,si               ;-1 ===> odecist
          neg       cx
          jmp short _sx
_sx1:
          mov       cx,si               ;1  ===> pricist
_sx:
          add       cx,x1               ;pridat x1

          cmp       dh,1                ;smerx=1 ?
          je        _sy1
          mov       dx,di               ;-1 ===> odecist
          neg       dx
          jmp short _sy
_sy1:
          mov       dx,di               ;1  ===> pricist
_sy:
          add       dx,y1               ;pridat y1

          mov       si,ds:ActiveAddrPage;dej offset VRAM

          mov       ax,80               ;ktery radek
          mul       dx
          add       si,ax
          mov       dx,cx               ;zachovej sloupec
          shr       dx,2
          add       si,dx               ;pridej sloupec k offsetu

          and       cl,3                ;vezmi cislo stranky ze sloupce
          mov       ah,1                ;pozadavek prepnuti stranky
          shl       ah,cl                 ;pro zapis
          mov       dx,3C4h
          mov       al,2
          out       dx,al
          inc       dx                  ;ktera stranka
          mov       al,ah
          out       dx,al
;tady to dela na obrazovce v bp pri debugovani zahadne krasne veci !!!!!
          mov       al,barva            ;vypis konecne bod cary
          mov       byte ptr es:[si],al

          ret                           ;vse zmenene se POPne
linevypisbod endp





;naprosto stejna procedura, lisi se pouze vystup bodu a v teto procedure
;volani jine procedury (onen vystup bodu) + odstraneny prazdne radky atp...
XorLine proc far
     arg X1:word,Y1:word,X2:word,Y2:word, Barva:byte
          uses ax,bx,cx,dx,si,di,es
          mov       ax,0A000h           ;es=segment VRAM
          mov       es,ax
          mov       ax,x2               ;ax=abs(x2-x1) a dl=smerx
          sub       ax,x1
          jge       v1
          mov       dl,0
          neg       ax
          jmp       short __1
v1:
          mov       dl,1
__1:
          mov       bx,y2               ;bx=abs(y2-y1) a dh=smery
          sub       bx,y1
          jge       v2
          mov       dh,0
          neg       bx
          jmp       short __2
v2:
          mov       dh,1
__2:
          xor       si,si               ;pocitadlo pozice x=si=i a y=di=j
          xor       di,di
          xor       cx,cx               ;cx=pocitadlo preteceni
cykl:                                   ;for j:=0 to y
          add       cx,ax               ;inc(poc,x)
          call      xorlinevypisbod     ;putpixel(x1+i*smerx,y1+j*smery,barva)
          cmp       cx,bx               ;if poc>=y
          jl        dal                 ;ne - nic, ano - pokracuj
          sub       cx,bx               ;dec(poc,y)
          inc       si                  ;inc(i)
__while:                                ;while (poc>=y)and(i<=x)
          cmp       cx,bx               ;poc<y ===> konec
          jl        dal
          cmp       si,ax               ;i>x   ===> konec
          jg        dal
          call      xorlinevypisbod     ;putpixel(x1+i*smerx,y1+j*smery,barva)
          sub       cx,bx               ;dec(poc,y)
          inc       si                  ;inc(i)
          jmp       short __while       ;===> while
dal:
          inc       di                  ;for : zvys j
          cmp       di,bx               ;for : otestuj horni mez
          jle       cykl                ;ano, jeste jednou
          ret                           ;jinak konec
XorLine endp

xorlinevypisbod proc near
          uses ax,bx,cx,dx,si
          cmp       dl,1                ;smerx=1 ?
          je        __sx1
          mov       cx,si               ;-1 ===> odecist
          neg       cx
          jmp short __sx
__sx1:
          mov       cx,si               ;1  ===> pricist
__sx:
          add       cx,x1               ;pridat x1
          cmp       dh,1                ;smerx=1 ?
          je        __sy1
          mov       dx,di               ;-1 ===> odecist
          neg       dx
          jmp short __sy
__sy1:
          mov       dx,di               ;1  ===> pricist
__sy:
          add       dx,y1               ;pridat y1

          mov       si,ds:ActiveAddrPage;dej offset VRAM
          mov       ax,80               ;ktery radek
          mul       dx
          add       si,ax
          mov       dx,cx               ;zachovej sloupec
          shr       dx,2
          add       si,dx               ;pridej sloupec k offsetu

          and       cl,3                ;vezmi cislo stranky ze sloupce
          mov       ah,1                ;pozadavek prepnuti stranky
          shl       ah,cl                 ;pro zapis
          mov       dx,3C4h
          mov       al,2
          out       dx,al
          inc       dx                  ;ktera stranka
          mov       al,ah
          out       dx,al
          mov       dx,3CEh
          mov       al,4
          out       dx,ax
          inc       dx
          mov       al,cl
          out       dx,al

          mov       al, byte ptr es:[si] ;vyxoruj bod
          xor       al, Barva
          mov       byte ptr es:[si], al

          ret
xorlinevypisbod endp





end
