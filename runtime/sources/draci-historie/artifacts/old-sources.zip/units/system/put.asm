;p��a TASM! arg asi nesm� b�t na 2 ��dky!

.286c

model large,pascal

codeseg

extrn ActiveAddrPage:word
public PutImageMaskMirrorZoomPart
public TestImageMaskMirrorZoom
public readsmallscreen
public remappal
public barva2sed
public zmenapalety
       ;init a done se kv�li getmem a freemem mus� d�lat mimo

PutImageMaskMirrorZoomPart proc pascal
        arg x,y,obr:word:2,maska:byte,jemaska:byte,mirror:byte, zdx,zdy, px1,py1,px2,py2
        ;v�e je integer, vyj�me�n� byte!
        local ox1,oy1,oy2,predx,predy,izpet,iprechod,sy,ozpet,odx,ody,vbit:byte
;        local ox1,oy1,oy2               ;sou�adnice za��tku/konce v obr.
;        local predx,predy               ;predikce x a uchov�n� predikce y
;        local izpet,iprechod,sy,ozpet   ;diference p�i r�zn�ch podm�nk�ch
;        local odx,ody                   ;si bude ukazovat jinam...
;              ;iofs a oofs jsou si a di
;              ;ox a oy budou cx
;        local vbit:byte                 ;zpracov�van� videostr�nka
;              ;b pixel bude v al...
;              ;vram bude v es

        pusha            ;ulo��me v�echny registry
        push ds es

        mov ax,px1       ;���ka ---> sou�adnice
        dec ax
        add px2,ax
        mov ax,py1
        dec ax
        add py2,ax

        mov ax,x         ;o�ez�n� partu na p�esn� obr�zek
        cmp px1,ax
        jnl _neorezvlevo
        mov px1,ax
_neorezvlevo:
        mov ax,y
        cmp py1,ax
        jnl _neoreznahore
        mov py1,ax
_neoreznahore:
        mov ax,x
        add ax,zdx
        dec ax
        cmp px2,ax
        jng _neorezvpravo
        mov px2,ax
_neorezvpravo:
        mov ax,y
        add ax,zdy
        dec ax
        cmp py2,ax
        jng _neorezdole
        mov py2,ax
_neorezdole:
        mov ax,px1              ;kontrola partu
        cmp px2,ax
        jnl _nekonec1
_konec1:
        jmp _konec
_nekonec1:
        mov ax,py1
        cmp py2,ax
        jl _konec1

        mov ax,0a000h           ;v�stup do videoram
        mov es,ax
        mov di,ds:word ptr activeaddrpage
        mov ds,ss:word ptr obr+2   ;vstup z obr�zku
        mov si,ss:word ptr obr  ;nastav d�lku a ���ku obr�zku
        lodsw
        mov odx,ax
        lodsw
        mov ody,ax              ;nyn� je offset posunut o 4

        mov ax,px1              ;zji�t�n� po�. sou�. a predikce
        sub ax,x
        imul odx
        idiv zdx
        mov ox1,ax              ;po�. sou� x
        mov predx,dx            ;predikce x
        mov ax,py1
        sub ax,y
        imul ody
        idiv zdy
        mov oy1,ax              ;po�. sou� y
        mov predy,dx            ;predikce y
        mov ax,py2
        sub ax,y
        imul ody
        idiv zdy
        mov oy2,ax              ;konc. sou� y

        mov ax,ody
        test mirror,1           ;zrcadlen� podle osy x?
        jz _nezrcadlix
        neg ax                  ;nastav� iprechod
        mov iprechod,ax
        mov ax,ox1              ;p�evr�t� za��tek
        neg ax
        dec ax
        add ax,odx
        mov ox1,ax
        jmp short _ponezrcadlenix
_nezrcadlix:
        mov iprechod,ax
_ponezrcadlenix:
        test mirror,2           ;zrcadlen� podle osy y?
        jz _nezrcadliy
        mov sy,-1
        mov ax,oy1              ;p�evr�t� za��tek
        neg ax
        dec ax
        add ax,ody
        mov oy1,ax
        mov ax,oy2              ;p�evr�t� konec
        neg ax
        dec ax
        add ax,ody
        mov oy2,ax
        jmp short _ponezrcadleniy
_nezrcadliy:
        mov sy,1
_ponezrcadleniy:

        mov ax,px1              ;zp�tky sou�adnice na ���ku
        dec ax
        sub px2,ax
        mov ax,py1
        dec ax
        sub py2,ax
        mov ax,oy1              ;nastav� �tec� index vracen� se
        sub ax,oy2
        mov izpet,ax
        mov ax,80               ;nastav� z�pisov� index vracen� se
        mov bx,py2
        neg bx
        inc bx
        mul bx
        mov ozpet,ax

        ;si a di je nastaveno na po��tek struktur, nyn� u� je jenom posuneme
        mov ax,ox1              ;v�po�et �tec� adresy
        mul ody
        add ax,oy1
        add si,ax
        mov ax,80               ;v�po�et z�pisov� adresy
        mul py1
        mov bx,px1
        shr bx,2
        add ax,bx
        add di,ax

        mov ax,px1              ;nastaven� bitov� roviny
        and al,3
        mov vbit,al
        mov cx,px2              ;nastaven� po��tadla sloupc�

        ;d�me tento loop, proto�e m�me jistotu, �e aspo� jednou prob�hne
        ;u po��tadla ��dk� je cyklus s podm�nkou uprost�ed
_dalsisloupec:                  ;zde za��n� vn�j�� cyklus podle X
        push cx                 ;ulo� si po��tadlo sloupc�

        mov cl,vbit             ;nastaven� dan� bitov� roviny
        mov ah,1
        shl ah,cl
        mov dx,3c4h
        mov al,2
        out dx,al
        inc dx
        mov al,ah
        out dx,al

        mov bx,predy            ;nastaven� star� predikce
        mov cx,py2              ;nastaven� po��tadla ��dk�

_dalsiradek:                    ;zde za��n� vnit�n� cyklus podle y
        mov al,byte ptr ds:[si] ;na�ten� bodu
        cmp al,byte ptr maska   ;porovnat barvy
        jne _zapisbodu
        mov al,byte ptr jemaska ;stejn� ---> zjistit, zda se m� br�t maska
        or al,al
        jnz _nezapisbodu
_zapisbodu:
        mov byte ptr es:[di],al ;z�pis do videoram
_nezapisbodu:

        dec cx                  ;zapsali jsme ji� cel� sloupec?
        jz _konecsloupce
        add di,80d              ;p�idej ��dek do videoram

        add bx,ody              ;provedeme line�rn� algoritmus
_preskocdalsiradek:
        cmp bx,zdy              ;d� se je�t� p�esko�it?
        jl _dalsiradek          ;ne ---> provedeme dal�� pr�chod cyklem
        sub bx,zdy              ;ano ---> ode�ti a zkus znovu
        add si,sy
        jmp short _preskocdalsiradek

_konecsloupce:
        add si,izpet            ;zp�tky na za��tek sloupce
        mov ax,predx            ;provedeme line�rn� algoritmus
        add ax,odx
_preskocdalsisloupec:
        cmp ax,zdx              ;d� se je�t� p�esko�it?
        jl _nepreskocdalsisloupec
        sub ax,zdx
        add si,iprechod
        jmp short _preskocdalsisloupec

_nepreskocdalsisloupec:
        mov predx,ax            ;zaznamen�me zp�t predikci
        add di,ozpet            ;sko��me ve videoram zp�t po sloupci
        inc vbit
        cmp vbit,4              ;pod�vej se na bitov� roviny
        jne _nerolujbitplan
        mov vbit,0
        inc di
_nerolujbitplan:
        pop cx                  ;obnov�me star� po��tadlo
        loop _dalsisloupec      ;mo�n� sko� na dal�� sloupec

_konec:
        ;se z�sobn�kem se pracuje jen v 1 m�st� na uchov�n� po��tadla x
        ;jinak jsme celkem nic neprovedli, klidn� se m��eme ukon�it
        pop es ds
        popa
        ret

PutImageMaskMirrorZoomPart endp

TestImageMaskMirrorZoom proc pascal
        arg x,y,obr:word:2,maska:byte,mirror:byte, zdx,zdy, px,py

        push ds si bx cx dx

        mov si,ss:word ptr obr
        mov ds,ss:word ptr obr+2

        xor al,al                     ;nen� tam obr�zek
        mov bx,x                      ;kontrola v��ezu x
        cmp px,bx
        jl konec_testu
        add bx,zdx
        cmp px,bx
        jge konec_testu
        mov bx,y                      ;kontrola v��ezu y
        cmp py,bx
        jl konec_testu
        add bx,zdy
        cmp py,bx
        jge konec_testu

        mov ax,py                     ;v�po�et sou�adnice v obr�zku (Y)
        sub ax,y
        imul word ptr ds:[si+2]
        idiv zdy
        mov cx,ax                     ;ulo�it
        mov ax,px                     ;v�po�et sou�adnice v obr�zku (X)
        sub ax,x
        imul word ptr ds:[si]
        idiv zdx

        test mirror,1                 ;p�evr�tit, je-li zrcadlo X
        jz nezrcadli_testx
        neg ax
        add ax,word ptr ds:[si]
        dec ax
nezrcadli_testx:
        test mirror,2                 ;p�evr�tit, je-li zrcadlo Y
        jz nezrcadli_testy
        neg cx
        add cx,word ptr ds:[si+2]
        dec cx
nezrcadli_testy:

        mul word ptr ds:[si+2]        ;v�po�et offsetu
        add ax,cx
        add ax,4
        mov bx,ax

        xor al,al
        mov ah,byte ptr ds:[si+bx]    ;porovn�me ��st obr�zku
        cmp ah,maska
        je konec_testu
        mov al,1

konec_testu:
        pop dx cx bx si ds
        ret
TestImageMaskMirrorZoom endp

readsmallscreen proc
                arg obr:dataptr

                push ds es si di ax bx cx dx

                mov di,ss:word ptr obr
                mov es,ss:word ptr obr+2
                mov ax,80                       ;savne sou�adnice obr�zku
                stosw
                mov ax,50
                stosw

                mov ax,0a000h
                mov ds,ax
                xor si,si

                mov ax,4                ;p�epne do 0. bitov� roviny
                mov dx,3ceh
                out dx,al
                inc dx
                mov al,ah
                out dx,al

                mov cx,80d              ;po�et sloupc�
readsmall_sloupec:
                mov dx,cx
                mov cx,50d              ;po�et ��dk�
readsmall_znak:
                movsb
                add si,4*80-1
                loop readsmall_znak     ;zkop�ruj v�echno
                mov cx,dx
                add si,-200*80+1        ;dal�� sloupec
                loop readsmall_sloupec

                pop dx cx bx ax di si es ds

                ret
readsmallscreen endp

R db 102                        ;empirick� n�sobn� hodnoty
G db 90                         ;na��st z literatury!!!!!
B db 63
Delit db 255                    ;ne 256, aby tam bylo 0..255 <===> 0..1

Conv db 256 dup (1)             ;-)

remappal  proc
          arg pal:dataptr

          push es ds si di ax cx dx

          mov si,ss:word ptr pal
          mov ds,ss:word ptr pal+2
          mov di,si
          push ds
          pop es
          mov cx,256
remap1barvy:
          lodsb                         ;R
          mul cs:byte ptr R
          div cs:byte ptr Delit
          mov dl,al
          lodsb                         ;G
          mul cs:byte ptr G
          div cs:byte ptr Delit
          add dl,al
          lodsb                         ;B
          mul cs:byte ptr B
          div cs:byte ptr Delit
          add al,dl

          stosb                         ;ulo� odst�n 0..255
          stosb
          stosb
          loop remap1barvy

          pop dx cx ax di si ds es

          ret
remappal endp

barva2sed proc
          arg obr:dataptr, pal:dataptr

          push ds es si di ax bx cx dx

          mov si,ss:word ptr pal
          mov ds,ss:word ptr pal+2
          mov di,offset Conv
          push cs
          pop es
          mov cx,256
konv1barvy:
          lodsb                         ;R
          mul cs:byte ptr R
          div cs:byte ptr Delit
          mov dl,al
          lodsb                         ;G
          mul cs:byte ptr G
          div cs:byte ptr Delit
          add dl,al
          lodsb                         ;B
          mul cs:byte ptr B
          div cs:byte ptr Delit
          add al,dl

          stosb                         ;ulo� si odst�n 0..255
          loop konv1barvy
          mov di,offset conv

          mov si,ss:word ptr obr
          mov ds,ss:word ptr obr+2
          lodsw                         ;v�po�et, kolik je to bajtu
          mov bx,ax
          lodsw
          mul bx
          mov cx,ax

          xor bh,bh
dalsibod:
          lodsb                 ;�ti barvu
          mov bl,al             ;p�eve� na index odst�nu �edi
          mov al,byte ptr es:[di+bx]    ;p�eve� na odst�n
          mov byte ptr ds:[si-1],al     ;savni
          loop dalsibod

          pop dx cx bx ax di si es ds

          ret
barva2sed endp

zmenapalety proc
                arg pal:dataptr,fazi,dif:dataptr,pred:dataptr
                ;pal1/2 je ukazatel na pole bajtu
                ;dif/pred je ukazatel na pole integeru

                push ds es si di ax bx cx dx

                mov si,ss:word ptr dif
                mov ds,ss:word ptr dif+2
                mov di,ss:word ptr pred
                mov es,ss:word ptr pred+2

                mov cx,768
                xor bx,bx
zmena1slozky:
                mov dx,word ptr ds:[si+bx]    ;vezmi diferenci
                mov ax,word ptr es:[di+bx]    ;vezmi predikci
                push es di                    ;vezmi paletu
                mov di,ss:word ptr pal
                mov es,ss:word ptr pal+2
                shr bx,1
                add di,bx
                shl bx,1
                cmp dx,0
                js zaporna_diference

                add ax,dx                     ;p�i�ti diferenci
posunslozkynahoru:
                cmp ax,ss:word ptr fazi
                jl konecposunu
                inc byte ptr es:[di]
                sub ax,ss:word ptr fazi
                jmp posunslozkynahoru

zaporna_diference:
                sub ax,dx                     ;ode�ti diferenci
posunslozkydolu:
                cmp ax,ss:word ptr fazi
                jl konecposunu
                dec byte ptr es:[di]
                sub ax,ss:word ptr fazi
                jmp posunslozkydolu

konecposunu:
                pop di es                     ;obnov predikci
                mov es:word ptr [di+bx],ax    ;ulo� jej� novou hodnotu
                add bx,2
                loop zmena1slozky

                pop dx cx bx ax di si es ds

                ret
zmenapalety endp

end

;dosud stra�n� probl�my s p�ed�n�m parametr�
;pak alg. nefachal, ale zjistil jsem, �e to je pouze tehdy, zoomuji-li podle
;x, jinak V�ECHNO funguje; mal� test ---> zapomn�l jsem SAVnout predikci
;a u� to hned napodruh� funguje!
;chyba v activeaddrpage nebyla v linkeru, ale v zapomenut� `word ptr'
;chyba faru nev�m pro� je, mus� b�t model large a nesm� b�t uvedeno far
;v pascalu v�ak far b�t uveden m��e i nemus�
;a u� to funguje jak dovezen� do put.pas, tak i do graph256.pas

;Luk��i: moje rutina je krat��, rychlej��, elegantn�j��, pochopiteln�j��,
;        chyt�ej��, zvl�d� v�ce mo�nost�, m� �plnou opravu chyb a je
;        bez chyby!

;get4: fach� �PLN� na 1. pokus!

;remap: fach� �PLN� na 1. pokus!
;p�ekl�d� dob�e a� do 255, ale na tomto obr�zku to zrovna nen� moc vid�t

;chpal: fachalo na asi 3. pokus, p�r serepeti�ek
;init a done procedury jsou v�ak sst�le v Pascalu
