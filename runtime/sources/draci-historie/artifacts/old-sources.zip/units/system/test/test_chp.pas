{pr�b��n� prolnut� 2 palet na N f�z�}
program testzmenypalety;
uses crt,graph256,graform;

{type pintegerarray=^tintegerarray;
     tintegerarray=array[0..767]of integer;}

const pocetfazi=32;

(*
procedure zmenapalety(
  pal:ppalette;
  N:integer;
  dif,pred:pintegerarray);
var i:integer;
begin
  for i:=0 to 767 do
    if dif^[i]>0 then begin {kladn� zm�na}
      inc(pred^[i],dif^[i]);
      while pred^[i]>=N do begin
        inc(pal^[i]);
        dec(pred^[i],N);
      end;
    end else begin
      dec(pred^[i],dif^[i]);
      while pred^[i]>=N do begin
        dec(pal^[i]);
        dec(pred^[i],N);
      end;
    end;
end;
*)

(*
{$f+}
procedure zmenapalety(
  pal:ppalette;
  N:integer;
  dif,pred:pintegerarray);
  external;
  {$l chpal.obj}

procedure remappal(
  pal:pointer);
  external;
  {$l remap.obj}
{�te je z graph256, v�. initu a done}
{$f-}
*)


var obr,pal1:pointer;
    pal2,pompal:ppalette;
    i:integer;
    fi:file;
    dif,pred:pintegerarray;
begin
  initgraph;
  lastline:=200;
  setactivepage(0);

  loadimage(obr,pal1,'e:\oneweek\bobr26.lbm');
  setpalette(pal1);
  putimage(0,0,obr);

  getmem(pal2,768);
  getmem(pompal,768);
{  assign(fi,'c:\pascal\animace\datas\stand2.pal');
  reset(fi,1);
  blockread(fi,pal2^,768);
  close(fi);}
{  for i:=0 to 767 do
    if i>=384 then
      pal2^[i]:=ppalette(pal1)^[i]
    else
      pal2^[i]:=i div 3;}
{  for i:=0 to 767 do
    pal2^[i]:=0;}
(*  for i:=0 to 767 do begin {pozvoln� p�echod k �ed�}
    pal2^[i]:=ppalette(pal1)^[i];
    pompal^[i]:=pal2^[i]; {mus� b�t na po�. stejn� jako pal1!}
  end;
  remappal(pal2);*)
  for i:=0 to 767 do begin
    pal2^[i]:= 63;
    pompal^[i]:=ppalette(pal1)^[i]; {mus� b�t na po�. stejn� jako pal1!}
  end;
{pal1 - vychozi, pal2 - konecny stav}
{pompal - na pocatku jako vychozi. Nemuzu pracovat rovnou s pal1, protoze ji
 to znici}

  repeat
    initzmenapalety(pal1,pal2,dif,pred); {C->M}
    for i:=1 to pocetfazi do begin
      zmenapalety(pompal,pocetfazi,dif,pred);
      setpalette(pompal);
    end;
    donezmenapalety(dif,pred);
    delay(1000);

    initzmenapalety(pal2,pal1,dif,pred); {M->C}
    {pal1 a pal2 uz nebudou potreba
     pompal^ MUSIS nastavit na pal1^ a pak uz volas jen toto
     dif a pred jsou JEHO pomocna pole, ktera se init/donem inicializuji}
    for i:=1 to pocetfazi do begin
      zmenapalety(pompal,pocetfazi,dif,pred);
      setpalette(pompal);
    end;
    donezmenapalety(dif,pred);
    delay(1000);
  until keypressed;
  readkey;

  freemem(pompal,768);
  freemem(pal1,768);
  freemem(pal2,768);
  disposeimage(obr);

  closegraph;
end.

{v podstat� fachalo v Pascalu na 1. pokus, ale p�i testov�n� se stand.pal
 jsem tomu necht�l v��it. Opravdu, ani p�i 10.000(!) f�z�ch to nep�sob�
 plynule. Sice se ka�d� barva plynule opravdu m�n�, ale to �asto jenom
 o predikci a kdy� nastane skokov� zm�na, je to u ka�d� barvy v jinou chv�li
 a p�sob� to rozhrkan�. Ale postupn� to opravdu je.

 p�echod do n�hodn� �B je dobr�, ale p�echod do odpov�daj�c� �B palet�
 je geni�ln� efektn�!}
