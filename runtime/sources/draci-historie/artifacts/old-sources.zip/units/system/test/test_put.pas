program TestPut;
uses crt,graph256;

procedure PutMaskImageMirrorZoomPart1(
  x,y:integer;
  obr:pbytearray;
  maska:integer;
  mirror:byte;
  zdx,zdy:integer;
  px1,py1,px2,py2:integer);
{�pln� verze, ale PO��D s v�po�tem offsetu}
var ox1,oy1,ox2,oy2:integer; {sou�adnice v obr�zku}
    predx,predy,preduchov:integer; {predikce}
    sx,sy:integer; {p�id�van� sou�adnice}
    dx,dy:integer; {d�lka neZOOMovan�ho obr�zku}
    ix,iy,ox,oy:integer; {indexov� sou�adnice IN,OUT}
    b:byte; {zpracov�van� pixel}
begin
  inc(px2,px1-1); {p�evod d�lek na sou�adnice}
  inc(py2,py1-1);
  if px1<x then px1:=x; {1. o��znut� part sou�adnic}
  if py1<y then py1:=y;
  if px2>x+zdx-1 then px2:=x+zdx-1;
  if py2>y+zdy-1 then py2:=y+zdy-1;
  if (px2<px1)or(py2<py1) then exit; {��dn� obr�zek}
  dx:=obr^[0]+obr^[1] shl 8; {nastav si d�lku obr�zku}
  dy:=obr^[2]+obr^[3] shl 8;
  ox1:=(px1-x)*dx div zdx; {nastav� startovn� sou�adnice v obr�zku}
  oy1:=(py1-y)*dy div zdy; {minim�ln� 0 (jako v C)}
  ox2:=(px2-x)*dx div zdx; {nastav� koncov� sou�adnice v obr�zku}
  oy2:=(py2-y)*dy div zdy; {maxim�ln� delka-1 (jako v C)}
  predx:=(px1-x)*dx mod zdx; {a startovn� predikci}
  predy:=(py1-y)*dy mod zdy;
  if mirror and 1<>0 then begin {nastaven� zrcadlen�}
    sx:=-1;
    ox1:=dx-ox1-1;
    ox2:=dx-ox2-1;
  end else
    sx:=1;
  if mirror and 2<>0 then begin
    sy:=-1;
    oy1:=dy-oy1-1;
    oy2:=dy-oy2-1;
  end else
    sy:=1;

  preduchov:=predy; {predikce x je nastavena}
  ix:=ox1;
  ox:=px1;
  while ox<=px2 do begin
    predy:=preduchov;
    iy:=oy1;
    oy:=py1;
    while oy<=py2 do begin
      b:=obr^[4+ix*dy+iy];
      if (maska and $ff<>b)or(maska shr 8=0) then
        putpixel(ox,oy,b);
      inc(oy);
      inc(predy,dy); {zv���me predikci}
      while predy>=zdy do begin
        dec(predy,zdy);
        inc(iy,sy);
      end;
    end;
    inc(ox);
    inc(predx,dx); {zv���me predikci}
    while predx>=zdx do begin
      dec(predx,zdx);
      inc(ix,sx);
    end;
  end;
end;

procedure PutMaskImageMirrorZoomPart2(
  x,y:integer;
  obr:pbytearray;
  maska:integer;
  mirror:byte;
  zdx,zdy:integer;
  px1,py1,px2,py2:integer);
{�pln� verze, offset v obr�zku se zvy�uje, ale vol� se po��d PutPixel}
var ox1,oy1,ox2,oy2:integer; {sou�adnice v obr�zku}
    predx,predy,preduchov:integer; {predikce}
    zpet,prechod,sy:integer; {p�id�van� sou�adnice}
    dx,dy:integer; {d�lka neZOOMovan�ho obr�zku}
    iofs,ox,oy:integer; {indexov� sou�adnice IN,OUT}
    b:byte; {zpracov�van� pixel}
begin
  inc(px2,px1-1); {p�evod d�lek na sou�adnice}
  inc(py2,py1-1);
  if px1<x then px1:=x; {1. o��znut� part sou�adnic}
  if py1<y then py1:=y;
  if px2>x+zdx-1 then px2:=x+zdx-1;
  if py2>y+zdy-1 then py2:=y+zdy-1;
  if (px2<px1)or(py2<py1) then exit; {��dn� obr�zek}
  dx:=obr^[0]+obr^[1] shl 8; {nastav si d�lku obr�zku}
  dy:=obr^[2]+obr^[3] shl 8;
  ox1:=(px1-x)*dx div zdx; {nastav� startovn� sou�adnice v obr�zku}
  oy1:=(py1-y)*dy div zdy; {minim�ln� 0 (jako v C)}
  ox2:=(px2-x)*dx div zdx; {nastav� koncov� sou�adnice v obr�zku}
  oy2:=(py2-y)*dy div zdy; {maxim�ln� delka-1 (jako v C)}
  predx:=(px1-x)*dx mod zdx; {a startovn� predikci}
  predy:=(py1-y)*dy mod zdy;
  if mirror and 1<>0 then begin {nastaven� zrcadlen�}
    prechod:=-dy; {p�echod na dal�� sloupec}
    ox1:=dx-ox1-1;
    ox2:=dx-ox2-1;
  end else begin
    prechod:=dy;
  end;
  if mirror and 2<>0 then begin
    sy:=-1;
    oy1:=dy-oy1-1;
    oy2:=dy-oy2-1;
  end else begin
    sy:=1;
  end;
  zpet:=oy1-oy2; {vr�cen� se zp�t na za��tek sloupce}

  preduchov:=predy; {predikce x je nastavena}
  iofs:=4+ox1*dy+oy1;
  ox:=px1;
  while ox<=px2 do begin
    predy:=preduchov;
    oy:=py1;
    repeat
      b:=obr^[iofs];
      if (maska and $ff<>b)or(maska shr 8=0) then
        putpixel(ox,oy,b);
      inc(oy);
      if oy>py2 then break; {nutno zde, aby se p��p. nezv��il iofs}
      inc(predy,dy); {zv���me predikci}
      while predy>=zdy do begin
        dec(predy,zdy);
        inc(iofs,sy);
      end;
    until false;
    inc(iofs,zpet); {na za��tek tohoto ��dku}
    inc(ox);
    inc(predx,dx); {zv���me predikci}
    while predx>=zdx do begin
      dec(predx,zdx);
      inc(iofs,prechod); {p�echod na dal�� sloupec}
    end;
  end;
end;

procedure prepnibitmapu(cis:byte); assembler;
asm
  mov     cl, cis
  mov     ah, 1
  shl     ah, cl
  mov     dx, 3C4h
  mov     al, 2
  out     dx, al
  inc     dx
  mov     al, ah
  out     dx, al
end;

procedure PutMaskImageMirrorZoomPart3(
  x,y:integer;
  obr:pbytearray;
  maska:integer;
  mirror:byte;
  zdx,zdy:integer;
  px1,py1,px2,py2:integer);
{�pln� verze, offset v obr�zku se zvy�uje, p�ep�naj� se ru�n� bitov� roviny
 a zapisuje se bod p��mo}
var ox1,oy1,ox2,oy2:integer; {sou�adnice v obr�zku}
    predx,predy,preduchov:integer; {predikce}
    izpet,iprechod,sy,ozpet:integer; {p�id�van� sou�adnice}
    dx,dy:integer; {d�lka neZOOMovan�ho obr�zku}
    iofs,oofs,ox,oy:integer; {indexov� sou�adnice IN,OUT}
    vbit,b:byte; {��slo bitmapy, zpracov�van� pixel}
    vram:array[0..64000]of byte absolute $a000:0;
begin
  inc(px2,px1-1); {p�evod d�lek na sou�adnice}
  inc(py2,py1-1);
  if px1<x then px1:=x; {1. o��znut� part sou�adnic}
  if py1<y then py1:=y;
  if px2>x+zdx-1 then px2:=x+zdx-1;
  if py2>y+zdy-1 then py2:=y+zdy-1;
  if (px2<px1)or(py2<py1) then exit; {��dn� obr�zek}
  dx:=obr^[0]+obr^[1] shl 8; {nastav si d�lku obr�zku}
  dy:=obr^[2]+obr^[3] shl 8;
  ox1:=(px1-x)*dx div zdx; {nastav� startovn� sou�adnice v obr�zku}
  oy1:=(py1-y)*dy div zdy; {minim�ln� 0 (jako v C)}
  ox2:=(px2-x)*dx div zdx; {nastav� koncov� sou�adnice v obr�zku}
  oy2:=(py2-y)*dy div zdy; {maxim�ln� delka-1 (jako v C)}
  predx:=(px1-x)*dx mod zdx; {a startovn� predikci}
  predy:=(py1-y)*dy mod zdy;
  if mirror and 1<>0 then begin {nastaven� zrcadlen�}
    iprechod:=-dy; {p�echod na dal�� sloupec}
    ox1:=dx-ox1-1;
    ox2:=dx-ox2-1;
  end else begin
    iprechod:=dy;
  end;
  if mirror and 2<>0 then begin
    sy:=-1;
    oy1:=dy-oy1-1;
    oy2:=dy-oy2-1;
  end else begin
    sy:=1;
  end;
  dec(px2,px1-1); {p�evod sou�adnic zp�tky na d�lky}
  dec(py2,py1-1);
  izpet:=oy1-oy2; {vr�cen� se zp�t na za��tek sloupce}
  ozpet:=(1-py2)*80; {vr�cen� se zp�t ve videoram}

  preduchov:=predy; {predikce x je nastavena}
  iofs:=4+ox1*dy+oy1;
  oofs:=px1 shr 2+py1*80;
  vbit:=px1 and $3;
  ox:=0;
  while ox<px2 do begin
    prepnibitmapu(vbit);
    predy:=preduchov;
    oy:=0;
    repeat
      b:=obr^[iofs];
      if (maska and $ff<>b)or(maska shr 8=0) then
        vram[oofs]:=b;
      inc(oy);
      if oy>=py2 then break; {nutno zde, aby se p��p. nezv��il iofs}
      inc(oofs,80);
      inc(predy,dy); {zv���me predikci}
      while predy>=zdy do begin
        dec(predy,zdy);
        inc(iofs,sy);
      end;
    until false;
    inc(iofs,izpet); {na za��tek tohoto ��dku}
    inc(predx,dx); {zv���me predikci}
    while predx>=zdx do begin
      dec(predx,zdx);
      inc(iofs,iprechod); {p�echod na dal�� sloupec}
    end;
    inc(ox);
    inc(oofs,ozpet);
    inc(vbit);
    if vbit=4 then begin
      vbit:=0;
      inc(oofs);
    end;
  end;
end;

procedure loadonlygcfimage(var p:pwordarray; soub:string);
var fi:file;
    rozm:array[0..1]of integer;
    del:word;
begin
  assign(fi,soub); reset(fi,1);
  blockread(fi,rozm,4);{na�te x a y}
  del:=word(rozm[0])*rozm[1];
  getmem(p,del+4);
  p^[0]:=rozm[0];
  p^[1]:=rozm[1];
  blockread(fi,p^[2],del);
  close(fi);
end;

(*
{$f+}
procedure PutImageMaskMirrorZoomPart(
  x,y:integer;
  obr:pbytearray;
  maska:byte;
  jemaska:boolean;
  mirror:byte;
  zdx,zdy:integer;
  px1,py1,px2,py2:integer);
  external;
function TestImageMaskMirrorZoom(
  x,y:integer;
  obr:pbytearray;
  mask:byte;
  mirror:byte;
  zdx,zdy:integer;
  px,py:integer):boolean;
  external;
  {$l put.obj}
{�te z graph256}
{$f-}
*)

function TestMaskImageMirrorZoom1(
  x,y:integer;
  obr:pbytearray;
  mask:byte;
  mirror:byte;
  zdx,zdy:integer;
  px,py:integer):boolean;
{vr�t�, zda je na dan�m m�st� maska}
var ox,oy:integer; {sou�adnice v obr�zku}
    dx,dy:integer; {d�lka neZOOMovan�ho obr�zku}
begin
  TestMaskImageMirrorZoom1:=false;
  if (px<x)or(py<y)or(px>=x+zdx)or(py>=y+zdy) then exit;
  dx:=obr^[0]+obr^[1] shl 8; {nastav si d�lku obr�zku}
  dy:=obr^[2]+obr^[3] shl 8;
  ox:=(px-x)*dx div zdx; {nastav� startovn� sou�adnice v obr�zku}
  oy:=(py-y)*dy div zdy; {minim�ln� 0 (jako v C)}
  if mirror and 1<>0 then {nastaven� zrcadlen�}
    ox:=dx-ox-1;
  if mirror and 2<>0 then
    oy:=dy-oy-1;
  TestMaskImageMirrorZoom1:=obr^[4+ox*dy+oy]<>mask;
end;

var obr:pbytearray;
    x,y:integer;
begin
{  initgraph;
  activeaddrpage:=0;
  loadonlygcfimage(pwordarray(obr),'c:\pascal\animace\datas\mouse.gcf');}
  if not sti(
    'c:\pascal\animace\datas\mouse.gcf',
    'c:\pascal\animace\datas\stand2.pal',
    'c:\pascal\animace\datas\stand2.fon') then
    halt(1);
  mouseon(0,0,mouseimage);
  mouseswitchoff;
  obr:=mouseimage;
(*  putimage(100,100,obr);
  for x:=0 to 100 do
    for y:=0 to 100 do begin
      putmaskimagemirrorzoompart(
        0,0,
        obr,
        255,
        false,
        3,
        60,64,
        x,y,20,3);
{      readkey;}
    end;
  readkey;
  putmaskimagemirrorzoompart(
    0,0,
    obr,
    255,
    true,
    0,
    60,64,
    0,0,320,200); {O.K.!}
  readkey;*)
  repeat
    putimagemaskmirrorzoompart( {my�i�ka postupn� odkryje cel� obraz}
      0,0,
      obr,
      255,
      true,
      2,
      320,200,
      mousex,mousey,100,10);
  until keypressed;
  readkey;
  for y:=0 to 199 do
    for x:=0 to 319 do
      if TestImageMaskMirrorZoom(
        50,50,
        obr,
        255,
        0,
        120,100,
        x,y) then
          putpixel(x,y,7);
  readkey;

{  closegraph;}
  ste;
end.

{log: naps�no a drobn� chyba v p�ehozen� 1 sou�adnice a nekontrolov�n�
      p�ete�en� a fach� na 1. pokus ve v�ech p��padech! (v�. zoomu&partu,
      masek, mirroru...)
      pak chybi�ka p�i v�po�tu indexu do obr�zk� (ob�as p�eteklo)
      pak chybi�ka ---"--- do videram (jedni�kov� probl�m)
        !done!}