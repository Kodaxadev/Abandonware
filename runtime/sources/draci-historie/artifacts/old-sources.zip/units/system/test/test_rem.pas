program remapovanipalety;
uses graph256,graform;
var obr,pal:pointer;
    i:byte;

(*
{$f+}
procedure barva2sed(
  obr,pal:pointer);
  external;
procedure remappal(
  pal:pointer);
  external;
  {$l remap.obj}
{�te je z graph256}
{$f-}
*)

begin
  initgraph;
  loadimage(obr,pal,'c:\pascal\animace\datas\sfoto.bmp');
  lastline:=200;
  setactivepage(0);
  setvisualpage(0);
  setpalette(pal);
  putimage(0,0,obr);
  barva2sed(obr,pal);          {p�eveden� obr�zku na 0..255 stup�� �edi}
  for i:=0 to 255 do begin      {nastaven� standardn� palety �edi}
    pbytearray(pal)^[i*3]:=i;
    pbytearray(pal)^[i*3+1]:=i;
    pbytearray(pal)^[i*3+2]:=i;
  end;
(*  remappal(pal); {remapov�n� palety na �&B}*)
  setactivepage(1);
  putimage(0,0,obr);
  readln;
  setpalette(pal);
  setvisualpage(1);
  readln;
  disposeimage(obr);
  freemem(pal,768);
  closegraph;
end.
